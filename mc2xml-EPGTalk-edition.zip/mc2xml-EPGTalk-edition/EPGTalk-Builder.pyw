#!/usr/bin/env python3
"""EPGTalk Guide Builder - a window for mc2xml (EPGTalk edition)
Made by aCiDjEsUs - https://epgtalk.com

Pick your TV providers, tick the channels you want, press Build: you get one XMLTV
guide file for your IPTV app. Works on Windows, Linux and Mac (Python 3 + Tkinter).

  EPGTalk-Builder.pyw              open the window
  EPGTalk-Builder.pyw --run        build the guide without a window (used by the daily
                                   schedule; writes builder.log next to this file)

Everything is kept in this folder: builder.json (your settings), one .dat/.chl/.ren
set per provider (the same files mc2xml uses), sd.login if you use Schedules Direct,
and builder.log. The guide itself is made by mc2xml.py, which must sit next to this file.
"""

import collections
import datetime as dt
import gzip
import html
import importlib.util
import json
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser

# FROZEN = the Windows .exe version (Python is built in, no install needed). It runs the engine as
# mc2xml.exe next to it; the normal version runs mc2xml.py with the Python that started it.
FROZEN = bool(getattr(sys, "frozen", False))
HERE = os.path.dirname(os.path.abspath(sys.executable if FROZEN else __file__))
ENGINE = os.path.join(HERE, "mc2xml.exe" if FROZEN else "mc2xml.py")
IS_WIN = sys.platform.startswith("win")
APP = "EPGTalk Guide Builder"
CREDIT = "made by aCiDjEsUs \u00b7 EPGTalk.com"
TASK = "EPGTalk Guide Builder"           # Windows scheduled task name
CRON_MARK = "# EPGTalk-Guide-Builder"    # marker on our crontab line

# Zip version: everything is kept next to the program. Installed version (.deb / Setup.exe, marked by
# an ".installed" file, or a folder you can't write to): settings and providers go to the user's own
# settings folder, and the guide file to an easy-to-find "EPGTalk Guide" folder in their home.
INSTALLED = os.path.exists(os.path.join(HERE, ".installed")) or not os.access(HERE, os.W_OK)


def _data_dir():
    if os.environ.get("EPGTALK_DATA"):                     # NAS / Docker version: everything in one folder (/config)
        return os.environ["EPGTALK_DATA"]
    if not INSTALLED:
        return HERE
    if IS_WIN:
        return os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), APP)
    if sys.platform == "darwin":
        return os.path.expanduser("~/Library/Application Support/" + APP)
    return os.path.join(os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share"), "epgtalk-builder")


DATA = _data_dir()
GUIDE_DIR = DATA if not INSTALLED or os.environ.get("EPGTALK_DATA") else os.path.join(os.path.expanduser("~"), *(["Documents"] if IS_WIN else []), "EPGTalk Guide")
os.makedirs(DATA, exist_ok=True)
PROFILE = os.path.join(DATA, "builder.json")
LOGIN = os.path.join(DATA, "sd.login")
LOGFILE = os.path.join(DATA, "builder.log")

RAW = "https://raw.githubusercontent.com/acidjesuz/EPGTalk/master/"
EXTRAS = [  # (key, label, file) - ready-made EPGTalk guides that can be added to yours
    ("sports", "EPGTalk Sports: a channel for every team (small)", "Sports_guide.xml.gz"),
    ("freetv", "EPGTalk Free TV: Pluto, Samsung TV Plus, Plex, Tubi (about 7 MB)", "FreeTV_guide.xml.gz"),
    ("uslocal", "EPGTalk US Local: 140+ local markets (about 2 MB)", "US_local_guide.xml.gz"),
    ("combined", "EPGTalk Combined: US + UK + Canada + Mexico, 48 h (about 5 MB)", "guide.xml.gz"),
]
GN_COUNTRIES = [("us", "United States"), ("ca", "Canada"), ("mx", "Mexico")]
SD_COUNTRIES = [("us", "United States"), ("ca", "Canada"), ("mx", "Mexico"), ("gb", "United Kingdom"),
                ("ie", "Ireland"), ("de", "Germany"), ("fr", "France"), ("es", "Spain"), ("it", "Italy"),
                ("nl", "Netherlands"), ("pl", "Poland"), ("au", "Australia"), ("nz", "New Zealand"),
                ("br", "Brazil"), ("ar", "Argentina"), ("co", "Colombia"), ("cl", "Chile"), ("pe", "Peru"),
                ("pr", "Puerto Rico")]

DEFAULTS = {"version": 1, "lineups": [], "output": "guide.xml", "gzip": True, "days": 7, "utf8": True,
            "utc": False, "name_first": True, "net_names": True, "tag_new": False, "tag_live": False, "extras": [],
            "schedule_time": "04:30", "text": 1.0, "next_id": 1}


# --------------------------------------------------------------------------- #
# Engine, profile, small helpers
# --------------------------------------------------------------------------- #

_engine = None


def engine():
    """mc2xml.py loaded as a module (for searching providers and channel lists)."""
    global _engine
    if _engine is None:
        if FROZEN:
            import mc2xml as m                # built into the .exe
        else:
            if not os.path.exists(ENGINE):
                raise RuntimeError("mc2xml.py was not found next to this program (%s)" % HERE)
            spec = importlib.util.spec_from_file_location("mc2xml_engine", ENGINE)
            m = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(m)
        m.log = lambda label, msg: None       # the window shows its own messages
        _engine = m
    return _engine


def load_profile():
    p = dict(DEFAULTS)
    try:
        with open(PROFILE, encoding="utf-8") as f:
            p.update(json.load(f))
    except (OSError, ValueError):
        pass
    return p


def save_profile(p):
    tmp = PROFILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(p, f, indent=1, ensure_ascii=False)
    os.replace(tmp, PROFILE)


def data(name):
    return os.path.join(DATA, name)


def here(name):
    return os.path.join(HERE, name)


def out_path(p):
    o = p.get("output") or "guide.xml"
    return o if os.path.isabs(o) else os.path.join(GUIDE_DIR, o)


def count_lines(path):
    try:
        with open(path, encoding="utf-8-sig", errors="replace") as f:
            return sum(1 for l in f if l.strip() and not l.lstrip().startswith("#"))
    except OSError:
        return None


def read_dat(path):
    """(json dict or None, legacy name or None) for a .dat file."""
    try:
        return engine().load_dat(path)
    except Exception:
        return None, None


def write_dat(path, lu):
    engine().save_dat(path, lu)             # keeps an original mc2xml .dat as .orig


def has_login():
    try:
        with open(LOGIN, encoding="utf-8") as f:
            return ":" in f.read()
    except OSError:
        return False


def save_login(user, pw):
    with open(LOGIN, "w", encoding="utf-8") as f:
        f.write("%s:%s\n" % (user.strip(), pw))
    try:
        os.chmod(LOGIN, 0o600)
    except OSError:
        pass


def login_user():
    try:
        with open(LOGIN, encoding="utf-8") as f:
            return f.read().split(":", 1)[0].strip()
    except OSError:
        return ""


def python_for_tasks():
    """The Python to use for scheduled runs (pythonw on Windows: no black window)."""
    exe = sys.executable or "python3"
    if IS_WIN:
        w = os.path.join(os.path.dirname(exe), "pythonw.exe")
        if os.path.exists(w):
            return w
    return exe


def open_path(path):
    try:
        if IS_WIN:
            os.startfile(path)                                  # noqa
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception:
        pass


def open_in_browser(path):
    """Open a local page (the guides) in the web browser. Asking the system to 'open the .html file'
    isn't reliable: some programs (balenaEtcher, editors...) take over .html files."""
    import pathlib
    url = pathlib.Path(path).resolve().as_uri()
    if not IS_WIN and sys.platform != "darwin":
        for cmd in ("x-www-browser", "sensible-browser", "google-chrome", "google-chrome-stable", "firefox",
                    "chromium", "chromium-browser", "brave-browser", "microsoft-edge", "vivaldi", "opera"):
            if shutil.which(cmd):
                try:
                    subprocess.Popen([cmd, url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
                    return
                except OSError:
                    continue
    try:
        if webbrowser.open(url):
            return
    except Exception:
        pass
    open_path(path)


def lineup_files(lid):
    return data(lid + ".dat"), data(lid + ".chl"), data(lid + ".ren")


def tweak_file(lid):
    """Your own channel numbers and time shifts for one provider (JSON, read by mc2xml --tweaks)."""
    return data(lid + ".twk")


def read_tweaks(path):
    try:
        with open(path, encoding="utf-8") as f:
            return {str(k).upper(): v for k, v in json.load(f).items() if isinstance(v, dict)}
    except (OSError, ValueError):
        return {}


# --------------------------------------------------------------------------- #
# Providers and channel lists (online)
# --------------------------------------------------------------------------- #

def gn_providers(cc, postal):
    e = engine()
    a = e.parse_args(["-c", cc, "-g", postal])
    g = e.Gracenote(e.Http(), a, e.COUNTRIES.get(cc, cc.upper()))
    return g.providers()                                        # [(name, lineup dict)]


def sd_client(cc, postal=""):
    e = engine()
    if not has_login():
        raise RuntimeError("Enter your Schedules Direct login on the Settings tab first.")
    a = e.parse_args(["-J", "@" + LOGIN, "-c", cc, "-g", postal])
    sd = e.SchedulesDirect(e.Http(), a, e.COUNTRIES.get(cc, cc.upper()))
    sd.login()
    return sd


def sd_lineups(cc, postal):
    """[(name, lineup dict, on_account)] - lineups on the account first, then the zip code search."""
    sd = sd_client(cc, postal)
    out, seen = [], set()
    for name, d in sd.account_options():
        out.append((name, d, True))
        seen.add(d["lineup"])
    if postal:
        for name, d in sd.headends():
            if d["lineup"] not in seen:
                out.append((name, d, False))
                seen.add(d["lineup"])
    return out, sd


class ProviderRemoved(RuntimeError):
    """The user chose "Remove this provider" instead of picking a lineup."""


def resolve_legacy(item, ask_pick):
    """An imported original mc2xml .dat: find its lineup (like mc2xml does) and save it in the
    new format. ask_pick(options, name, mine) is called if it can't be matched by name; mine = the
    positions of the lineups on the Schedules Direct account (None for free listings). It returns a
    lineup, None (cancel) or "remove"."""
    e = engine()
    dat, chl, ren = lineup_files(item["id"])
    d, legacy = read_dat(dat)
    if d:
        return d
    name = legacy or item.get("name", "")
    mine = None
    if item["source"] == "gracenote":
        if not item.get("postal"):
            raise RuntimeError("This lineup needs a zip / postal code (Lineups tab → Edit).")
        opts = gn_providers(item["country"], item["postal"])
        lu = e.match_lineup(opts, name)
    else:
        lst, sd = sd_lineups(item["country"], item.get("postal", ""))
        lu = e.match_lineup([(n, d) for n, d, on in lst if on], name)
        opts = [(n + ("  (" + T("on your account") + ")" if on else ""), d) for n, d, on in lst]
        mine = [k for k, (n, d, on) in enumerate(lst) if on]
    if not lu:
        lu = ask_pick(opts, name, mine)
        if lu == "remove":
            raise ProviderRemoved(T("Removed."))
        if not lu:
            raise RuntimeError(T("No lineup chosen."))
    write_dat(dat, lu)
    return lu


def channel_rows(item, lu, confirm_add):
    """[{num, cs, name, cid, sid}] for every channel in the lineup."""
    rows = []
    if item["source"] == "gracenote":
        e = engine()
        a = e.parse_args(["-c", item["country"], "-g", lu.get("postal") or item.get("postal", "")])
        g = e.Gracenote(e.Http(), a, lu.get("country") or "USA")
        old = os.getcwd()
        os.chdir(DATA)                                          # mc2xml keeps its cache here
        try:
            d = g.chunk(lu, int(time.time()) // e.CHUNK * e.CHUNK)
        finally:
            os.chdir(old)
        for c in d.get("channels", []):
            num = c.get("channelNo") or ""
            rows.append({"num": num, "cs": c.get("callSign") or "", "name": c.get("affiliateName") or "",
                         "cid": "I%s.%s.gracenote.com" % (num, c.get("channelId")), "sid": str(c.get("channelId") or ""),
                         "logo": logo_url((c.get("thumbnail") or "").split("?")[0])})
    else:
        sd = sd_client(item["country"], item.get("postal", ""))
        lid = lu["lineup"]
        if lid not in sd.account_lineups:
            if not confirm_add(lid):
                raise RuntimeError("Not added.")
            r = sd.call("/lineups/" + lid, method="PUT")
            if r.get("code", 0) != 0:
                raise RuntimeError("Schedules Direct: %s" % r.get("message", r))
        m = sd.call("/lineups/" + lid)
        stations = {s["stationID"]: s for s in m.get("stations", [])}
        seen = set()
        for e2 in m.get("map", []):
            sid = e2["stationID"]
            num = e2.get("channel") or e2.get("virtualChannel")
            if not num and e2.get("atscMajor") is not None:
                num = "%s.%s" % (e2["atscMajor"], e2.get("atscMinor", 0))
            if not num:
                num = str(e2.get("uhfVhf") or e2.get("logicalChannelNumber") or "")
            num = num.lstrip("0") or num
            cid = "I%s.%s.schedulesdirect.org" % (num, sid)
            if cid in seen:
                continue
            seen.add(cid)
            st = stations.get(sid, {})
            try:
                lg = engine().pick_logo(st)[0]
            except Exception:
                lg = None
            rows.append({"num": num, "cs": st.get("callsign") or "", "name": st.get("name") or st.get("affiliate") or "",
                         "cid": cid, "sid": str(sid), "logo": logo_url(lg)})

    def numkey(r):
        parts = re.findall(r"\d+", r["num"])
        return ([int(x) for x in parts] or [10 ** 9], r["cs"])
    rows.sort(key=numkey)
    return rows


def row_keys(r):
    return {k.upper() for k in (r["cs"], r["num"], r["cid"], r["sid"]) if k}


def read_chl(path):
    keys = set()
    try:
        with open(path, encoding="utf-8-sig", errors="replace") as f:
            for l in f:
                l = re.sub("[﻿​‌‍ ]", "", l).strip()
                if l and not l.startswith("#"):
                    keys.add(l.upper())
    except OSError:
        return None                                             # no file = every channel
    return keys


def read_ren(path):
    ren = {}
    try:
        with open(path, encoding="utf-8-sig", errors="replace") as f:
            for l in f:
                l = l.strip()
                if l and not l.startswith("#") and ":" in l:
                    k, v = l.split(":", 1)
                    ren.setdefault(k.strip().upper(), v.strip())
    except OSError:
        pass
    return ren


def save_channel_files(rows, checked, renames, chl, ren, tweaks=None, twk=None):
    """checked: set of row indexes. Writes a call sign where it is unique in the lineup,
    otherwise the channel number, otherwise the full channel id."""
    cs_n, num_n = {}, {}
    for r in rows:
        if r["cs"]:
            cs_n[r["cs"].upper()] = cs_n.get(r["cs"].upper(), 0) + 1
        if r["num"]:
            num_n[r["num"].upper()] = num_n.get(r["num"].upper(), 0) + 1

    def key(r):
        if r["cs"] and cs_n[r["cs"].upper()] == 1:
            return r["cs"]
        if r["num"] and num_n[r["num"].upper()] == 1:
            return r["num"]
        return r["cid"]

    head = "# Made with %s (%s) - one channel per line\n" % (APP, CREDIT)
    with open(chl, "w", encoding="utf-8") as f:
        f.write(head)
        for i, r in enumerate(rows):
            if i in checked:
                f.write(key(r) + "\n")
    with open(ren, "w", encoding="utf-8") as f:
        f.write("# Made with %s (%s) - KEY:New name\n" % (APP, CREDIT))
        for i, r in enumerate(rows):
            nm = (renames.get(i) or "").strip()
            if nm:
                f.write("%s:%s\n" % (key(r), nm))
    if twk:
        out = {}
        for i, t in (tweaks or {}).items():
            t = {k: v for k, v in t.items() if v not in (None, "", 0, 0.0)}
            if t:
                out[key(rows[i])] = t
        if out:
            with open(twk, "w", encoding="utf-8") as f:
                json.dump(out, f, indent=1)
        else:
            try:
                os.remove(twk)
            except OSError:
                pass


# --------------------------------------------------------------------------- #
# Building the guide (used by the window and by --run)
# --------------------------------------------------------------------------- #

# --------------------------------------------------------------------------- #
# Playlist matcher: gives the channels in an IPTV playlist (.m3u) their guide IDs
# --------------------------------------------------------------------------- #
# Privacy: a playlist's links usually hold the IPTV login. Playlists are only read and
# written on this computer; their links and web address are never logged or shown.

M3U_ATTR = re.compile(r'([\w-]+)="([^"]*)"')
VOD_URL = re.compile(r"\.(mp4|mkv|avi|mov|m4v|wmv|flv|mpg|mpeg|webm)(\?|$)|/(movie|movies|series|vod)/", re.I)
NOISE = re.compile(r"\b(hd|fhd|uhd|sd|hq|4k|8k|hevc|h\.?265|h\.?264|1080[pi]?|720p|2160p|50fps|60fps|backup|alt|"
                   r"east|feed|raw|vip)\b")
COUNTRY_TAGS = set("us usa uk gb ca can mx mex es ar co cl pe ve br pt fr de it nl be pl in au nz ie latam lat sv gt hn cr pa "
                   "do pr ec bo py uy ni cu ph za tr gr ru se no dk fi ch at il ae sa eg ma pk bd jp kr cn hk tw".split())
CALLSIGN_SFX = re.compile(r"^([KW][A-Z]{2,3})-?(?:DT|LD|CD)\d*$")       # WJBKDT, WDIV-DT, WMNTCD2


def callsigns_in(name, guide):
    """Call signs written as call signs: "FOX (WJBK)", "WJBKDT", or the whole name "WJBK". Plain words like
    "Wild" or "World" never count. In a playlist the word must be in capitals (WJBK, not Wjbk)."""
    out = set(re.findall(r"\(([KW][A-Z]{2,3})\)", name))
    for t in re.findall(r"[A-Za-z0-9-]+", name):
        m = CALLSIGN_SFX.match(t)
        if m:
            out.add(m.group(1))
        elif not guide and re.fullmatch(r"[KW][A-Z]{3}", t):
            out.add(t)
    if re.fullmatch(r"\s*[KW][A-Z]{2,3}\s*", name):
        out.add(name.strip())
    return out


def m3u_read(src):
    """Reads a playlist from a file or a web address. Returns its text."""
    if re.match(r"https?://", src or ""):
        req = urllib.request.Request(src, headers={"User-Agent": "EPGTalk-Guide-Builder"})
        with urllib.request.urlopen(req, timeout=120) as r:
            raw = r.read()
    else:
        with open(src, "rb") as f:
            raw = f.read()
    if raw[:2] == b"\x1f\x8b":
        raw = gzip.decompress(raw)
    txt = raw.decode("utf-8-sig", errors="replace")
    if "#EXTINF" not in txt[:200000]:
        raise RuntimeError(T("this is not an IPTV playlist (.m3u)"))
    return txt


def m3u_parse(txt):
    """[{dur, attrs (list of pairs), title, extra (lines), url}] in playlist order."""
    out, cur = [], None
    for line in txt.splitlines():
        l = line.strip()
        if not l:
            continue
        if l.startswith("#EXTINF"):
            head, _, title = l.partition(",")
            if '"' in title and head.count('"') % 2:          # a comma inside an attribute value
                m = re.match(r'(#EXTINF[^,]*?(?:"[^"]*"[^,"]*)*),(.*)$', l)
                if m:
                    head, title = m.group(1), m.group(2)
            dur = re.match(r"#EXTINF:\s*(-?\d+(?:\.\d+)?)", head)
            cur = {"dur": dur.group(1) if dur else "-1", "attrs": M3U_ATTR.findall(head), "title": title.strip(), "extra": [], "url": ""}
        elif l.startswith("#EXTM3U"):
            continue
        elif l.startswith("#"):
            if cur is not None:
                cur["extra"].append(l)
        elif cur is not None:
            cur["url"] = l
            out.append(cur)
            cur = None
    return out


def m3u_attr(e, name):
    for k, v in e["attrs"]:
        if k.lower() == name:
            return v
    return ""


def m3u_is_live(e):
    return not VOD_URL.search(e.get("url", ""))


def ch_norm(s):
    s = (s or "").lower().replace("&", " and ")
    m = re.match(r"^\s*([a-z]{2,5})\s*[:|\-]\s*", s)           # "US: ", "USA | ", "MX - " - but not "NBA: " or "LMB: "
    if m and m.group(1) in COUNTRY_TAGS:
        s = " " + s[m.end():]
    s = re.sub(r"[\[(][^\])]*[\])]", " ", s)                    # (backup), [HD]
    s = re.sub(r"[^a-z0-9+]+", " ", s)
    s = NOISE.sub(" ", s)
    return " ".join(s.split())


def m3u_key(e):
    """What a playlist channel is remembered by (its links change, its name doesn't)."""
    return ch_norm(m3u_attr(e, "tvg-name") or e["title"]) or e["title"].lower()


def guide_index(path):
    """Reads the channels of a built guide: {id: {names, icon, num, label}} plus lookup tables."""
    e = engine()
    chans, _ = e.read_include(path)
    idx = {"ch": {}, "key": {}, "cs": {}, "tok": {}}
    for cid, x in chans:
        names = [html.unescape(n) for n in re.findall(r"<display-name>(.*?)</display-name>", x)]
        icon = re.search(r'<icon src="([^"]+)"', x)
        num = next((n for n in names if re.fullmatch(r"\d+(\.\d+)?", n)), "")
        words = [n for n in names if not re.fullmatch(r"\d+(\.\d+)?", n) and not re.match(r"\d+(\.\d+)? ", n)]
        label = next((n for n in words if " " in n.strip() or "(" in n), words[0] if words else (names[0] if names else cid))
        idx["ch"][cid] = {"names": names, "icon": html.unescape(icon.group(1)) if icon else "", "num": num, "label": label}
        keys = set()
        for n in names + [cid.split(".")[0]]:
            k = ch_norm(n)
            if k and not re.fullmatch(r"[\d. ]+", k) and not re.fullmatch(r"i\d+", k):     # (I2 = a lineup's id, not a name)
                keys.add(k)
                keys.add(re.sub(r"^\d+(\.\d+)? ", "", k))         # "2 my local fox" -> "my local fox"
        for n in names:
            for c_ in callsigns_in(n, True):
                idx["cs"].setdefault(c_, [])
                if cid not in idx["cs"][c_]:
                    idx["cs"][c_].append(cid)
        for k in keys:
            if k:
                idx["key"].setdefault(k, [])
                if cid not in idx["key"][k]:
                    idx["key"][k].append(cid)
                for t in k.split():
                    if len(t) > 1:
                        idx["tok"].setdefault(t, set()).add(k)
    return idx


def m3u_best(idx, ids, k):
    """Several guide channels share a name (e.g. a US and a Latin American feed): take the one whose
    own name is closest - the main name equal to it wins over a name that is only one of its extras."""
    if len(ids) == 1:
        return ids[0]

    def rank(cid):
        ch = idx["ch"][cid]
        main = ch_norm(ch["label"])
        return (0 if main == k else 1 if k in main.split() or main.startswith(k) else 2, len(ch["names"]))
    return min(ids, key=rank)


def m3u_match(e, idx):
    """(guide id or '', 'ok' | 'check' | 'none') for one playlist channel."""
    import difflib
    tid = m3u_attr(e, "tvg-id")
    if tid and tid in idx["ch"]:
        return tid, "ok"
    raw = m3u_attr(e, "tvg-name") or e["title"]
    for c_ in callsigns_in(raw, False):                        # a call sign: WJBK, WDIV-DT
        if len(idx["cs"].get(c_, [])) == 1:
            return idx["cs"][c_][0], "ok"
    k = ch_norm(raw)
    if not k:
        return "", "none"
    if k in idx["key"]:
        return m3u_best(idx, idx["key"][k], k), "ok"
    cands = set()
    for t in k.split():
        ks = idx["tok"].get(t)
        if ks and len(ks) <= 60:                                  # skip common words like "tv" or "news"
            cands |= ks
    best, score = None, 0.0
    sm = difflib.SequenceMatcher(None)
    sm.set_seq2(k)
    nums = set(re.findall(r"\d+", k))
    shorts = {t for t in k.split() if t.isalpha() and len(t) <= 4}   # NFL, ABC, ESPN, TLC: must be in both
    for c in cands:
        ct = set(c.split())
        if set(re.findall(r"\d+", c)) != nums or not shorts <= ct:
            continue                                              # Canal 6 is not Canal 14, NFL is not NHL
        sm.set_seq1(c)
        if sm.real_quick_ratio() < 0.75 or sm.quick_ratio() < 0.75:
            continue
        r = sm.ratio()
        if r > score:
            best, score = c, r
    if best and score >= 0.94:
        return m3u_best(idx, idx["key"][best], best), "ok"
    if best and score >= 0.78:
        return m3u_best(idx, idx["key"][best], best), "check"
    return "", "none"


def m3u_line(e, gid, ch, chno):
    attrs = [(k, v) for k, v in e["attrs"] if k.lower() not in ("tvg-id",) and not (chno and k.lower() == "tvg-chno")]
    if gid:
        attrs.insert(0, ("tvg-id", gid))
        if ch and ch.get("icon") and not m3u_attr(e, "tvg-logo"):
            attrs.append(("tvg-logo", ch["icon"]))
        if chno and ch and ch.get("num"):
            attrs.append(("tvg-chno", ch["num"]))
    a = "".join(' %s="%s"' % (k, v.replace('"', "'")) for k, v in attrs)
    return "#EXTINF:%s%s,%s" % (e["dur"], a, e["title"])


def m3u_results(entries, idx, picks):
    """[(entry, guide id, status)] for the live channels; picks = your own choices {key: id or '-'}."""
    res = []
    for e in entries:
        if not m3u_is_live(e):
            continue
        pk = picks.get(m3u_key(e))
        if pk == "-":
            res.append((e, "", "none"))
        elif pk and pk in idx["ch"]:
            res.append((e, pk, "ok"))
        else:
            gid, st = m3u_match(e, idx)
            res.append((e, gid, st))
    return res


def m3u_write(path, entries, res, idx, chno=False):
    """Writes the fixed playlist: guide IDs (and logos) for matched channels; everything else unchanged.
    Suggestions you haven't confirmed are left without a guide ID."""
    by_e = {id(e): (gid, st) for e, gid, st in res}
    L = ['#EXTM3U x-tvg-url=""']
    n = 0
    for e in entries:
        gid, st = by_e.get(id(e), ("", "none"))
        gid = gid if st == "ok" else ""
        n += bool(gid)
        L.append(m3u_line(e, gid, idx["ch"].get(gid), chno))
        L.extend(e["extra"])
        L.append(e["url"])
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(L) + "\n")
    os.replace(tmp, path)
    return n


def playlist_out(p):
    pl = p.get("playlist") or {}
    return pl.get("out") or os.path.join(os.path.dirname(out_path(p)), "playlist-epgtalk.m3u")


def playlist_refresh(p, say=None):
    """Makes the fixed playlist again from its source and the new guide (each build)."""
    pl = p.get("playlist") or {}
    if not pl.get("src") or not pl.get("auto", True):
        return None
    entries = m3u_parse(m3u_read(pl["src"]))
    idx = guide_index(out_path(p))
    res = m3u_results(entries, idx, pl.get("picks", {}))
    n = m3u_write(playlist_out(p), entries, res, idx, pl.get("chno", False))
    if say:
        say("✔ " + T("Playlist updated: %d of %d live channels have a guide") % (n, len(res)), "ok")
    return n


def fetch_guide(url, max_age=3 * 3600):
    """Downloads an XMLTV guide (.xml or .xml.gz) from a web address into the cache; kept 3 hours."""
    import hashlib
    dst = data("_more_%s.xml" % hashlib.sha1(url.encode("utf-8")).hexdigest()[:12])
    if os.path.exists(dst) and time.time() - os.path.getmtime(dst) < max_age:
        return dst
    req = urllib.request.Request(url, headers={"User-Agent": "EPGTalk-Guide-Builder"})
    with urllib.request.urlopen(req, timeout=120) as r:
        raw = r.read()
    if raw[:2] == b"\x1f\x8b":
        raw = gzip.decompress(raw)
    if b"<tv" not in raw[:5000]:
        raise RuntimeError(T("this address is not an XMLTV guide"))
    with open(dst + ".tmp", "wb") as f:
        f.write(raw)
    os.replace(dst + ".tmp", dst)
    return dst


# --------------------------------------------------------------------------- #
# Picking channels from a ready-made guide (EPGTalk Sports, Free TV ... or any XMLTV address)
# --------------------------------------------------------------------------- #

PICK_SPORTS = {"nfl": "NFL", "nba": "NBA", "mlb": "MLB", "nhl": "NHL", "mls": "MLS", "wnba": "WNBA", "ncaaf": "NCAA Football",
               "ncaam": "NCAA Basketball", "intl": "International", "epl": "Premier League", "laliga": "LaLiga",
               "seriea": "Serie A", "ligamx": "Liga MX", "bundesliga": "Bundesliga", "ligue1": "Ligue 1",
               "slots": "Game slots", "sports": "More sports"}
PICK_SOCCER = ("International", "Premier League", "LaLiga", "Serie A", "Liga MX", "Bundesliga", "Ligue 1")
PICK_SERVICES = {"samsungtvplus": "Samsung TV Plus", "plex": "Plex", "tubi": "Tubi", "plutotv": "Pluto TV"}
PICK_NETWORKS = {"ABC", "NBC", "CBS", "FOX", "PBS", "CW", "ION", "TELEMUNDO", "UNIVISION", "MYNETWORKTV", "MNTV", "UNIMAS"}


def pick_key_extra(k):
    return "x_" + k


def pick_key_more(url):
    import hashlib
    return "m_" + hashlib.sha1(url.encode("utf-8")).hexdigest()[:10]


def pick_files(key):
    return {x: data("%s.%s" % (key, x)) for x in ("chl", "ren", "twk", "known")}


def read_pick(key):
    """{"ids": set of picked channel ids or None (= every channel), "ren": {id: name}, "twk": {id: {num, shift}},
    "known": {id: name} (the channels the guide had when you picked), "auto": take new channels too}"""
    fs = pick_files(key)
    out = {"ids": None, "ren": {}, "twk": {}, "known": {}, "auto": True}
    try:
        with open(fs["chl"], encoding="utf-8") as fh:
            out["ids"] = {l.strip() for l in fh if l.strip() and not l.startswith("#")}
    except OSError:
        pass
    try:
        with open(fs["ren"], encoding="utf-8") as fh:
            for l in fh:
                if l.strip() and not l.startswith("#") and "\t" in l:
                    k, v = l.rstrip("\n").split("\t", 1)
                    out["ren"][k] = v
    except OSError:
        pass
    for k in ("twk", "known"):
        try:
            with open(fs[k], encoding="utf-8") as fh:
                d = json.load(fh)
            if k == "known":
                out["known"], out["auto"] = d.get("names", {}), bool(d.get("auto", out["ids"] is None))
            else:
                out["twk"] = {i: t for i, t in d.items() if isinstance(t, dict)}
        except (OSError, ValueError, AttributeError):
            pass
    return out


def save_pick(key, ids, ren, twk, known, auto):
    """ids None = every channel. Channel ids are kept exactly (XMLTV ids are case-sensitive)."""
    fs = pick_files(key)
    if ids is None:
        try:
            os.remove(fs["chl"])
        except OSError:
            pass
    else:
        with open(fs["chl"], "w", encoding="utf-8") as fh:
            fh.write("# Made with %s (%s) - one channel id per line\n" % (APP, CREDIT))
            fh.write("".join(i + "\n" for i in sorted(ids)))
    with open(fs["ren"], "w", encoding="utf-8") as fh:
        fh.write("# Made with %s (%s) - channel id<TAB>your name\n" % (APP, CREDIT))
        fh.write("".join("%s\t%s\n" % (i, n.replace("\t", " ").strip()) for i, n in sorted(ren.items()) if n.strip()))
    tw = {i: {k: v for k, v in t.items() if v not in (None, "", 0, 0.0)} for i, t in twk.items()}
    with open(fs["twk"], "w", encoding="utf-8") as fh:
        json.dump({i: t for i, t in tw.items() if t}, fh, indent=1)
    with open(fs["known"], "w", encoding="utf-8") as fh:
        json.dump({"auto": bool(auto), "names": known}, fh, ensure_ascii=False)


def forget_pick(key):
    for fn in pick_files(key).values():
        try:
            os.remove(fn)
        except OSError:
            pass


def has_pick(key):
    return any(os.path.exists(fn) for k, fn in pick_files(key).items() if k != "known")


def pick_summary(key):
    """(picked, total) - picked None = every channel; total None = not known yet."""
    pk = read_pick(key)
    total = len(pk["known"]) or None
    return (None if pk["ids"] is None else len(pk["ids"])), total


def pick_group(cid, names, key=""):
    """League / service / network of a channel, for the filters in the channel window."""
    end = cid.rsplit(".", 1)[-1].lower() if "." in cid else ""
    if end in PICK_SPORTS:
        return PICK_SPORTS[end]
    if end in PICK_SERVICES:
        return PICK_SERVICES[end]
    first = (names or [""])[0]
    m = re.search(r"\(([^()]+)\)\s*$", first)
    if m and len(m.group(1)) < 30:
        return m.group(1).strip()
    if key == "x_uslocal" or key.startswith("m_"):
        w = re.sub(r"^US\s*-\s*", "", first).split(" ")[0].upper()
        if w in PICK_NETWORKS:
            return "FOX" if w == "FOX" else w.title() if w in ("TELEMUNDO", "UNIVISION", "UNIMAS") else w
        if key == "x_uslocal":
            return "Other"
    return ""


def pick_fullname(names):
    """A friendlier second name ("Detroit Tigers" for "MLB - TIGERS", "Bloomberg TV" for "Bloomberg TV (Pluto TV)")."""
    main = (names or [""])[0]
    plain = re.sub(r"\s*\([^()]+\)\s*$", "", main)
    if plain != main:                                   # "Bloomberg TV (Pluto TV)" -> "Bloomberg TV"
        return plain
    for n in names[1:][::-1]:                           # a real name, not a number or a code like "PTVBLTV"
        if n and " " in n.strip() and not re.match(r"[\d.]+ ", n) and " - " not in n and n != main:
            return n
    return ""


def extra_file(key, max_age=3 * 3600):
    """The downloaded EPGTalk ready-made guide (kept 3 hours)."""
    fn = dict((k, x) for k, _, x in EXTRAS)[key]
    dst = data("_extra_%s.xml" % key)
    if not (os.path.exists(dst) and time.time() - os.path.getmtime(dst) < max_age):
        req = urllib.request.Request(RAW + fn, headers={"User-Agent": "EPGTalk-Guide-Builder"})
        with urllib.request.urlopen(req, timeout=120) as r:
            raw = r.read()
        with open(dst + ".tmp", "wb") as fh:
            fh.write(gzip.decompress(raw) if raw[:2] == b"\x1f\x8b" else raw)
        os.replace(dst + ".tmp", dst)
    return dst


def pick_source(key, p):
    """(file, title) of the full guide behind a pick key."""
    if key.startswith("x_"):
        k = key[2:]
        lbl = dict((a, b) for a, b, _ in EXTRAS)[k]
        return extra_file(k), T(lbl).split(":")[0]
    for g in p.get("more_guides", []):
        if pick_key_more(g.get("url", "")) == key:
            return fetch_guide(g["url"]), g.get("name") or guide_name(g["url"])
    raise RuntimeError(T("That guide isn't in your list any more."))


def pick_rows(path, key):
    """[{cid, name, full, group, logo, names, bytes}] for every channel of a guide, plus the guide's total size."""
    e = engine()
    chans, progs = e.read_include(path)
    size = collections.Counter()
    for cid, x in progs:
        size[cid] += len(x)
    rows, total = [], 0
    for cid, x in chans:
        names = [html.unescape(n) for n in re.findall(r"<display-name[^>]*>([^<]*)<", x)]
        lg = re.search(r'<icon src="([^"]+)"', x)
        b_ = size.get(cid, 0) + len(x)
        total += b_
        rows.append({"cid": cid, "name": names[0] if names else cid, "full": pick_fullname(names), "group": pick_group(cid, names, key),
                     "logo": html.unescape(lg.group(1)) if lg else None, "names": names, "bytes": b_})
    return rows, total


def trim_guide(src, key, out, name_first=True, write_output=None):
    """Writes only the picked channels of a guide (with your names, numbers and time shifts) to out.
    Returns (kept, total, [names of picked channels that aren't in the guide any more])."""
    e = engine()
    pk = read_pick(key)
    chans, progs = e.read_include(src)
    have = {cid for cid, _ in chans}
    keep = set()
    for cid, _ in chans:
        if pk["ids"] is None or cid in pk["ids"] or (pk["auto"] and cid not in pk["known"]):
            keep.add(cid)
    chan_xml = []
    for cid, x in chans:
        if cid not in keep:
            continue
        nm, tw = pk["ren"].get(cid), pk["twk"].get(cid) or {}
        num = str(tw.get("num") or "").strip()
        if nm or num:
            names = [html.unescape(n) for n in re.findall(r"<display-name[^>]*>([^<]*)<", x)]
            name = nm or (names[0] if names else cid)
            first = ([name, "%s %s" % (num, name), num] if name_first else ["%s %s" % (num, name), name, num]) if num else [name]
            new = []
            for n in first + names:
                if n and n not in new:
                    new.append(n)
            body = re.sub(r"\s*<display-name[^>]*>[^<]*</display-name>", "", x)
            head, _, rest = body.partition(">")
            x = head + ">" + "".join("\n\t\t<display-name>%s</display-name>" % html.escape(n, quote=False) for n in new) + rest
        chan_xml.append(x)
    prog_xml = []
    for cid, x in progs:
        if cid in keep:
            h = (pk["twk"].get(cid) or {}).get("shift")
            prog_xml.append(e.shift_times(x, float(h)) if h else x)
    (write_output or e.write_output)(out, APP, chan_xml, prog_xml, True)
    gone = [pk["known"].get(i, i) for i in sorted(pk["ids"] or ()) if i not in have]
    return len(chan_xml), len(chans), gone


def guide_name(url):
    """A short name for a guide address: the site and file name, never a login or token."""
    import urllib.parse
    u = urllib.parse.urlsplit(url)
    fn = os.path.basename(u.path) or u.hostname or url
    return "%s · %s" % (u.hostname or "", fn) if u.hostname else fn


def last_good(lid):
    """The last listings that built fine for one provider (used when it fails another day). The name carries
    a fingerprint of the provider's lineup, so listings kept for another lineup are never used by mistake."""
    import hashlib
    d, legacy = read_dat(lineup_files(lid)[0])
    ident = ((d or {}).get("lineup") or (d or {}).get("lineup_name") or legacy or "none")
    return data("_last_%s_%s.xml" % (lid, hashlib.sha1(str(ident).encode("utf-8")).hexdigest()[:10]))


def forget_last_good(lid):
    """Removes every kept copy of a provider's listings (when the provider is removed)."""
    for f in os.listdir(DATA):
        if f.startswith("_last_%s_" % lid) and f.endswith(".xml"):
            try:
                os.remove(os.path.join(DATA, f))
            except OSError:
                pass


def build(p, say, cancel=None, progress=None, procbox=None):
    """Builds every enabled lineup with mc2xml.py, adds the chosen EPGTalk guides and
    merges everything into one file. say(text, kind) shows a line ('info','ok','err','dim').
    Returns a summary dict."""
    e = engine()
    t0 = time.time()
    items = [x for x in p["lineups"] if x.get("enabled", True)]
    extras = [x for x in EXTRAS if x[0] in p.get("extras", [])]
    more = [g for g in p.get("more_guides", []) if g.get("url") and g.get("on", True)]
    steps = len(items) + len(extras) + len(more) + 1
    step = 0
    parts, ok, failed, notfound, stale = [], [], [], [], []
    env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8")
    max_age = max(6, int(p.get("days", 7)) * 24 - 6) * 3600      # older than that, its listings are mostly in the past

    def fallback(it):
        """Today's update didn't work for this provider: use its last good listings, if they're recent enough."""
        lg = last_good(it["id"])
        try:
            fresh = time.time() - os.path.getmtime(lg) < max_age
        except OSError:
            fresh = False
        if fresh:
            parts.append(lg)
            stale.append(it.get("name"))
            when = dt.datetime.fromtimestamp(os.path.getmtime(lg)).strftime("%Y-%m-%d %H:%M")
            say("⚠ %s: %s" % (it.get("name"), T("today's update didn't work, so its last good listings (%s) are used") %
                                nice_when(when, p)), "warn")
            return True
        failed.append(it.get("name"))
        return False
    flags = 0x08000000 if IS_WIN else 0                 # CREATE_NO_WINDOW

    def stopped():
        return cancel is not None and cancel.is_set()

    def picked_part(src, key, nm):
        """The guide as is, or only the channels you picked from it."""
        if not has_pick(key):
            return src
        out_ = data("_xpart_%s.xml" % key)
        kept, total, gone = trim_guide(src, key, out_, bool(p.get("name_first", True)))
        say("   " + T("%d of %d channels (your picks)") % (kept, total), "dim")
        if gone:
            say("⚠ %s: %s" % (nm, T("not in this guide any more: %s") % ", ".join(gone[:10])), "warn")
        return out_

    say("%s - %s" % (APP, CREDIT), "dim")
    if not items and not extras and not more:
        say(T("Nothing to build yet: add a TV provider first."), "err")
        return {"ok": False}
    for n, it in enumerate(items, 1):
        if stopped():
            break
        step += 1
        if progress:
            progress(step, steps, T("Provider %d of %d: %s") % (n, len(items), it.get("name", "")))
        dat, chl, ren = lineup_files(it["id"])
        part = data("_part%d.xml" % n)
        cmd = ([ENGINE] if FROZEN else [sys.executable, ENGINE]) + ["-c", it.get("country", "us"), "-D", dat, "-o", part,
               "-d", str(int(p.get("days", 7)) * 24), "-U"]
        if it.get("postal"):
            cmd += ["-g", it["postal"]]
        cmd += ["-C", chl, "-R", ren]          # missing file = all channels / no renames (never mc2xml.chl)
        if os.path.exists(tweak_file(it["id"])):
            cmd += ["--tweaks", tweak_file(it["id"])]
        if it["source"] == "sd":
            if not has_login():
                say("✖ %s: %s" % (it.get("name"), T("needs your Schedules Direct login (Settings)")), "err")
                fallback(it)
                continue
            cmd += ["-J", "@" + LOGIN]
        for flag, opt in (("-u", "utc"), ("-F", "name_first"), ("-a", "tag_new"), ("-A", "tag_live"), ("--network-names", "net_names")):
            if p.get(opt):
                cmd.append(flag)
        say("▶ %s" % it.get("name", it["id"]), "info")
        try:
            proc = subprocess.Popen(cmd, cwd=DATA, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                    stdin=subprocess.DEVNULL, env=env, creationflags=flags)
        except OSError as ex:
            say("✖ %s: %s" % (T("could not start the engine"), ex), "err")
            fallback(it)
            continue
        if procbox is not None:
            procbox[0] = proc
        for raw in proc.stdout:
            line = raw.decode("utf-8", "replace").rstrip()
            if not line:
                continue
            kind = "err" if line.startswith(("Error", "Traceback")) else "ok" if line.startswith("Completed") else \
                   "warn" if line.startswith(("Not found", "Warning")) else "dim"
            say("   " + line, kind)
            if line.startswith("Not found"):
                notfound.append((it.get("name"), line.split(":", 1)[-1].strip()))
        rc = proc.wait()
        if procbox is not None:
            procbox[0] = None
        if rc == 0 and os.path.exists(part):
            parts.append(part)
            ok.append(it.get("name"))
            try:
                shutil.copyfile(part, last_good(it["id"]) + ".tmp")
                os.replace(last_good(it["id"]) + ".tmp", last_good(it["id"]))
            except OSError:
                pass
        elif stopped():
            failed.append(it.get("name"))
        else:
            say("✖ %s %s" % (it.get("name"), T("did not finish (see the lines above)")), "err")
            fallback(it)

    for key, label, fn in extras:
        if stopped():
            break
        step += 1
        if progress:
            progress(step, steps, T("Adding %s") % T(label).split(":")[0])
        try:
            say("▶ %s" % T(label).split(":")[0], "info")
            dst = extra_file(key)
            parts.append(picked_part(dst, pick_key_extra(key), T(label).split(":")[0]))
            ok.append(T(label).split(":")[0])
            say("   " + T("added"), "ok")
        except Exception as ex:
            failed.append(T(label).split(":")[0])
            say("✖ %s: %s" % (T(label).split(":")[0], ex), "err")

    for g in more:
        if stopped():
            break
        step += 1
        nm = g.get("name") or T("Guide")
        if progress:
            progress(step, steps, T("Adding %s") % nm)
        try:
            dst = fetch_guide(g["url"])
            say("▶ %s" % nm, "info")
            parts.append(picked_part(dst, pick_key_more(g["url"]), nm))
            ok.append(nm)
            say("   " + T("added"), "ok")
        except Exception as ex:                        # the address itself is never logged (it may hold a login)
            failed.append(nm)
            say("✖ %s: %s" % (nm, ex), "err")

    if stopped():
        say(T("Stopped."), "err")
        return {"ok": False, "stopped": True}
    step += 1
    if progress:
        progress(step, steps, T("Putting it all together"))
    if not parts:
        say(T("Nothing was downloaded, so the guide was not changed."), "err")
        return {"ok": False, "failed": failed}

    chan_xml, prog_xml, ids = [], [], set()
    for path in parts:
        chans, progs = e.read_include(path)
        new = set()
        for cid, x in chans:
            if cid not in ids:
                chan_xml.append(x)
                new.add(cid)
        prog_xml += [x for cid, x in progs if cid in new]
        ids |= new
    out = out_path(p)
    os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
    size = e.write_output(out, APP, chan_xml, prog_xml, bool(p.get("utf8", True)))
    gz = None
    if p.get("gzip"):
        gz = out + ".gz" if not out.endswith(".gz") else out
        with open(out, "rb") as f, gzip.open(gz + ".tmp", "wb", compresslevel=8) as g:
            shutil.copyfileobj(f, g)
        os.replace(gz + ".tmp", gz)
    for path in parts:
        if os.path.basename(path).startswith(("_part", "_xpart")):
            try:
                os.remove(path)
            except OSError:
                pass
    if (p.get("playlist") or {}).get("src") and (p.get("playlist") or {}).get("auto", True):
        try:
            playlist_refresh(p, say)
        except Exception as ex:                       # never shows the playlist's address (it may hold a login)
            say("⚠ " + T("Your playlist was not updated: %s") % ex, "err")
    s = {"ok": True, "file": out, "gz": gz, "size": size, "channels": len(chan_xml), "programs": len(prog_xml),
         "okparts": ok, "failed": failed, "stale": stale, "notfound": notfound, "secs": int(time.time() - t0),
         "when": dt.datetime.now().strftime("%Y-%m-%d %H:%M")}
    say("✔ " + T("Guide ready: %s  (%d channels, %d shows, %.1f MB)") % (out, s["channels"], s["programs"], size / 1e6), "ok")
    if gz:
        say("✔ " + T("Also saved: %s") % gz, "ok")
    if stale:
        say("⚠ " + T("Kept the last good listings for: %s") % ", ".join(stale), "warn")
    if failed:
        say("⚠ " + T("Not included this time: %s") % ", ".join(failed), "err")
    return s


def headless():
    """--run: build without a window (daily schedule). Logs to builder.log."""
    p = load_profile()
    seq0 = int(p.get("change_n", 0))                    # changes saved while this runs are not in this guide
    set_lang(p.get("lang", "en"))
    lines = []

    def say(t, kind="info"):
        line = "[%s] %s" % (dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), t)
        lines.append(line)
        try:
            print(line, flush=True)
        except Exception:
            pass
    err = ""
    try:
        s = build(p, say)
    except Exception as ex:
        say("✖ %s" % ex, "err")
        s, err = {"ok": False}, str(ex)
    if not s.get("ok") and not err:
        eng = [l.split("Error", 1)[-1].lstrip(" .:") for l in lines if "Error ......." in l or "] Error" in l]
        bad = [l.split("] ", 1)[-1] for l in lines if "✖" in l]
        err = (eng[-1] if eng else bad[-1].replace("✖", "").strip() if bad else T("see the log"))[:200]
    try:
        old = []
        if os.path.exists(LOGFILE):
            with open(LOGFILE, encoding="utf-8", errors="replace") as f:
                old = f.read().splitlines()[-3000:]
        with open(LOGFILE, "w", encoding="utf-8") as f:
            f.write("\n".join(old + lines) + "\n")
    except OSError:
        pass
    p = load_profile()                                  # (re-read: the window may have changed things meanwhile)
    p["last_auto"] = {"when": dt.datetime.now().strftime("%Y-%m-%d %H:%M"), "ok": bool(s.get("ok")),
                      "failed": s.get("failed") or [], "stale": s.get("stale") or [], "error": err, "seen": False}
    if s.get("ok"):
        p["last_build"] = {k: s[k] for k in ("when", "channels", "programs", "size", "secs") if k in s}
        p["last_build"]["auto"] = True
        if int(p.get("change_n", 0)) == seq0:
            p["changed"] = False
    save_profile(p)
    return 0 if s.get("ok") else 1


# --------------------------------------------------------------------------- #
# Daily schedule (Windows Task Scheduler / cron)
# --------------------------------------------------------------------------- #

def run_command():
    """The command that builds without a window (daily schedule), as a list."""
    return [sys.executable] if FROZEN else [python_for_tasks(), os.path.abspath(__file__)]


def schedule_on(hhmm):
    if IS_WIN:
        tr = " ".join('"%s"' % x for x in run_command()) + " --run"
        r = subprocess.run(["schtasks", "/Create", "/F", "/SC", "DAILY", "/ST", hhmm, "/TN", TASK, "/TR", tr],
                           capture_output=True, text=True, creationflags=0x08000000)
        if r.returncode != 0:
            raise RuntimeError((r.stderr or r.stdout).strip() or "schtasks failed")
        return
    if not shutil.which("crontab"):
        raise RuntimeError("This computer has no 'crontab' command (install the 'cron' package).")
    hh, mm = hhmm.split(":")
    line = "%d %d * * * cd '%s' && %s --run >/dev/null 2>&1 %s" % (int(mm), int(hh), DATA, " ".join("'%s'" % x for x in run_command()), CRON_MARK)
    cur = subprocess.run(["crontab", "-l"], capture_output=True, text=True)
    keep = [l for l in (cur.stdout.splitlines() if cur.returncode == 0 else []) if CRON_MARK not in l]
    r = subprocess.run(["crontab", "-"], input="\n".join(keep + [line]) + "\n", capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(r.stderr.strip() or "crontab failed")


def schedule_off():
    if IS_WIN:
        subprocess.run(["schtasks", "/Delete", "/F", "/TN", TASK], capture_output=True, text=True, creationflags=0x08000000)
        return
    if not shutil.which("crontab"):
        return
    cur = subprocess.run(["crontab", "-l"], capture_output=True, text=True)
    if cur.returncode != 0:
        return
    keep = [l for l in cur.stdout.splitlines() if CRON_MARK not in l]
    subprocess.run(["crontab", "-"], input="\n".join(keep) + ("\n" if keep else ""), capture_output=True, text=True)


def schedule_status():
    """'HH:MM' if a daily build is set up, else None."""
    try:
        if IS_WIN:
            r = subprocess.run(["schtasks", "/Query", "/TN", TASK, "/FO", "LIST", "/V"], capture_output=True,
                               text=True, creationflags=0x08000000)
            if r.returncode != 0:
                return None
            m = re.search(r"Start Time:\s*(\d{1,2}:\d{2})", r.stdout)
            return m.group(1) if m else "on"
        if not shutil.which("crontab"):
            return None
        cur = subprocess.run(["crontab", "-l"], capture_output=True, text=True)
        for l in cur.stdout.splitlines():
            if CRON_MARK in l:
                mm, hh = l.split()[:2]
                return "%02d:%02d" % (int(hh), int(mm))
    except Exception:
        pass
    return None


# --------------------------------------------------------------------------- #
# The window
# --------------------------------------------------------------------------- #

# --------------------------------------------------------------------------- #
# Sharing the guide on the home network (TV boxes load it by address)
# --------------------------------------------------------------------------- #

VIRTUAL_IF = re.compile(r"^(lo|tun|tap|wg|nordlynx|nordtun|tailscale|zt|ztr|docker|br-|virbr|veth|lxcbr|lxdbr|vmnet|vboxnet|"
                        r"utun|ppp|ipsec|proton|mullvad|cni|flannel|podman|vnet)", re.I)


def is_home_ip(ip):
    """A private home-network address (not loopback, not Tailscale's 100.64/10, not link-local)."""
    try:
        a, b_ = (int(x) for x in ip.split(".")[:2])
    except ValueError:
        return False
    return a == 10 or (a == 192 and b_ == 168) or (a == 172 and 16 <= b_ <= 31)


def local_ipv4s():
    """[(connection name or "", address)] for the connections that are up. Linux: every connection with its
    name; elsewhere: the computer's addresses (no names)."""
    import socket
    out = []
    if sys.platform.startswith("linux"):
        try:
            import fcntl
            import struct
            sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            for _, name in socket.if_nameindex():
                nb = struct.pack("256s", name[:15].encode())
                try:
                    flags = struct.unpack("H", fcntl.ioctl(sk.fileno(), 0x8913, nb)[16:18])[0]      # SIOCGIFFLAGS
                    if not (flags & 0x1 and flags & 0x40):                                           # IFF_UP, IFF_RUNNING
                        continue
                    out.append((name, socket.inet_ntoa(fcntl.ioctl(sk.fileno(), 0x8915, nb)[20:24])))  # SIOCGIFADDR
                except OSError:
                    continue
            sk.close()
        except Exception:
            out = []
    if not out:
        try:
            for ip in {a[4][0] for a in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET)}:
                out.append(("", ip))
        except OSError:
            pass
    return out


class GuideServer:
    """A tiny web server that hands out ONLY the guide file(s) to devices on the home network,
    e.g. http://192.168.1.20:8765/guide.xml.gz for TiviMate. Runs while the window is open."""

    def __init__(self):
        self.httpd = None
        self.port = None

    def start(self, files, port=8765):
        import http.server
        import socketserver
        allowed = files if callable(files) else (lambda f=dict(files): f)   # "/guide.xml.gz" -> real path

        class H(http.server.BaseHTTPRequestHandler):
            def _send(self, head_only):
                path = allowed().get(self.path.split("?")[0])
                if not path or not os.path.exists(path):
                    self.send_error(404, "Not found")
                    return
                size = os.path.getsize(path)
                self.send_response(200)
                self.send_header("Content-Type", "application/gzip" if path.endswith(".gz") else
                                 "audio/x-mpegurl; charset=utf-8" if path.endswith(".m3u") else "application/xml; charset=utf-8")
                self.send_header("Content-Length", str(size))
                self.send_header("Cache-Control", "no-cache")
                self.end_headers()
                if not head_only:
                    try:
                        with open(path, "rb") as f:
                            shutil.copyfileobj(f, self.wfile)
                    except (BrokenPipeError, ConnectionResetError):
                        pass                                    # the TV box stopped downloading - fine

            def do_GET(self):
                self._send(False)

            def do_HEAD(self):
                self._send(True)

            def log_message(self, *a):
                pass

        class S(socketserver.ThreadingMixIn, http.server.HTTPServer):
            daemon_threads = True
            allow_reuse_address = True

            def handle_error(self, request, client_address):
                pass                                            # a dropped connection is not worth a message

        last = None
        for p in range(port, port + 10):
            try:
                self.httpd = S(("0.0.0.0", p), H)
                self.port = p
                break
            except OSError as e:
                last = e
        if not self.httpd:
            raise RuntimeError("no free network port (%s)" % last)
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def stop(self):
        if self.httpd:
            try:
                self.httpd.shutdown()
                self.httpd.server_close()
            except Exception:
                pass
        self.httpd = None

    @staticmethod
    def lan_ip():
        """This computer's address on the home network. With a VPN on, the usual trick (ask which address
        would reach a router) can give the VPN's address, which a TV box can't reach - so look at all the
        connections and skip VPN, Tailscale, Docker and virtual machine ones."""
        import socket
        try:
            s_ = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s_.connect(("192.168.1.1", 9))                    # no packet is sent; just picks a connection
            route = s_.getsockname()[0]
            s_.close()
        except OSError:
            route = "127.0.0.1"
        good = [ip for name, ip in local_ipv4s() if is_home_ip(ip) and not VIRTUAL_IF.match(name or "")]
        if route in good and (route.startswith("192.168.") or not any(ip.startswith("192.168.") for ip in good)):
            return route
        good.sort(key=lambda ip: 0 if ip.startswith("192.168.") else 1 if ip.startswith("10.") else 2)
        return good[0] if good else route


# --------------------------------------------------------------------------- #
# "Add to my apps menu" (Linux .desktop / Windows Start menu + desktop shortcut)
# --------------------------------------------------------------------------- #

def add_app_shortcut():
    me = os.path.abspath(__file__)
    if IS_WIN:
        ps = ("$w=New-Object -ComObject WScript.Shell;"
              "foreach($d in @([Environment]::GetFolderPath('Programs'),[Environment]::GetFolderPath('Desktop'))){"
              "$s=$w.CreateShortcut((Join-Path $d 'EPGTalk Guide Builder.lnk'));"
              "$s.TargetPath='%s';$s.Arguments='\"%s\"';$s.WorkingDirectory='%s';"
              "$s.Description='EPGTalk Guide Builder - made by aCiDjEsUs';$s.Save()}") % (
                  run_command()[0].replace("'", "''"), (me if not FROZEN else "").replace("'", "''"), DATA.replace("'", "''"))
        r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
                           capture_output=True, text=True, creationflags=0x08000000)
        if r.returncode != 0:
            raise RuntimeError((r.stderr or r.stdout).strip() or "PowerShell failed")
        return "Added to your Start menu and your desktop."
    import base64
    icon = data("epgtalk-icon.png")
    with open(icon, "wb") as f:
        f.write(base64.b64decode("".join(ICON_PNG)))
    entry = ("[Desktop Entry]\nType=Application\nName=EPGTalk Guide Builder\nComment=Build your own TV guide - made by aCiDjEsUs, EPGTalk.com\n"
             "Exec=python3 \"%s\"\nPath=%s\nIcon=%s\nTerminal=false\nCategories=AudioVideo;Video;TV;\n") % (me, DATA, icon)
    apps = os.path.expanduser("~/.local/share/applications")
    os.makedirs(apps, exist_ok=True)
    dst = os.path.join(apps, "epgtalk-builder.desktop")
    with open(dst, "w", encoding="utf-8") as f:
        f.write(entry)
    os.chmod(dst, 0o755)
    return "Added to your apps menu (search for “EPGTalk”)."


# --------------------------------------------------------------------------- #
# Language (English / Español), clock (12 / 24 hour), version
# --------------------------------------------------------------------------- #

VERSION = "1.4.0"
UPDATE_URL = "https://epgtalk.com/builder/version.json"    # optional; nothing happens until it exists
SETUP_URL = "https://epgtalk.com/setup.html?guide=builder"   # step by step for every TV app, with "your own guide" picked
NAS_URL = "https://epgtalk.com/builder/#nas"                   # the NAS / Docker version
LANG = "en"
ES = {}                                                     # filled in at the bottom of this file


def T(s):
    """Translate a piece of the window's text (Spanish when the user picked Español)."""
    return ES.get(s, s) if LANG == "es" else s


def set_lang(code):
    global LANG
    LANG = "es" if code == "es" else "en"


def clock(t, p):
    """9:45 PM (12-hour, default) or 21:45 (24-hour)."""
    if (p or {}).get("clock", "12") == "24":
        return t.strftime("%H:%M")
    h = t.hour % 12 or 12
    return "%d:%02d %s" % (h, t.minute, "AM" if t.hour < 12 else "PM")


def parse_time(s):
    """'4:30', '04:30', '4:30 PM', '4:30pm', '16:30' -> '16:30' (24-hour) or None."""
    m = re.fullmatch(r"\s*(\d{1,2})(?::(\d{2}))?\s*([AaPp])?\.?\s*[Mm]?\.?\s*", s or "")
    if not m:
        return None
    h, mi, ap = int(m.group(1)), int(m.group(2) or 0), (m.group(3) or "").lower()
    if mi > 59 or h > 23 or (ap and not 1 <= h <= 12):
        return None
    if ap == "p" and h != 12:
        h += 12
    if ap == "a" and h == 12:
        h = 0
    return "%02d:%02d" % (h, mi)


def nice_when(stamp, p):
    """'2026-10-06 21:45' -> 'today at 9:45 PM' / 'yesterday at …' / 'Oct 4 at …'."""
    try:
        t = dt.datetime.strptime(stamp[:16], "%Y-%m-%d %H:%M")
    except (ValueError, TypeError):
        return stamp or ""
    d = (dt.date.today() - t.date()).days
    day = T("today") if d == 0 else T("yesterday") if d == 1 else \
        ("%d %s" % (t.day, T(t.strftime("%b"))) if LANG == "es" else "%s %d" % (T(t.strftime("%b")), t.day))
    return T("%s at %s") % (day, clock(t, p))


def vtuple(v):
    return tuple(int(x) for x in re.findall(r"\d+", v or "0")[:3])


def update_plan(up):
    """How this copy can update itself: ('windows'|'linux', url, sha256), or None (then: open the web page).
    Only the installed versions update themselves, and only when the download comes with its checksum."""
    if not isinstance(up, dict):
        return None
    key = "windows" if IS_WIN else "linux" if sys.platform.startswith("linux") else None
    d = up.get(key) if key else None
    if not isinstance(d, dict) or not re.match(r"https://", d.get("url", "")) or not re.fullmatch(r"[0-9a-fA-F]{64}", d.get("sha256", "")):
        return None
    if key == "windows" and not (FROZEN and INSTALLED):
        return None
    if key == "linux" and not (INSTALLED and not FROZEN and shutil.which("dpkg") and os.path.isdir("/opt/epgtalk-builder")):
        return None
    return key, d["url"], d["sha256"].lower()


def update_download(url, sha, progress=None, cancel=None):
    """Downloads an update into the settings folder and checks it is exactly the published file."""
    import hashlib
    folder = data("update")
    os.makedirs(folder, exist_ok=True)
    dst = os.path.join(folder, os.path.basename(url.split("?")[0]) or "update")
    h = hashlib.sha256()
    req = urllib.request.Request(url, headers={"User-Agent": "EPGTalk-Guide-Builder/" + VERSION})
    with urllib.request.urlopen(req, timeout=60) as r, open(dst + ".part", "wb") as fh:
        total = int(r.headers.get("Content-Length") or 0)
        got = 0
        while True:
            if cancel is not None and cancel.is_set():
                raise RuntimeError(T("Stopped."))
            chunk = r.read(65536)
            if not chunk:
                break
            fh.write(chunk)
            h.update(chunk)
            got += len(chunk)
            if progress:
                progress(got, total)
    if h.hexdigest() != sha:
        os.remove(dst + ".part")
        raise RuntimeError(T("the download didn't match the published file, so it was not installed"))
    os.replace(dst + ".part", dst)
    return dst


def update_install(kind, path):
    """Starts the installer. Windows: the setup runs, then the app opens again by itself.
    Linux: the package is installed (your computer asks for your password), then the app opens again."""
    if kind == "windows":
        me = sys.executable
        cmd = 'start "" /wait "%s" /SILENT /SUPPRESSMSGBOXES /NORESTART /CURRENTUSER & start "" "%s"' % (path, me)
        subprocess.Popen(["cmd", "/c", cmd], creationflags=0x08000000 | 0x00000008, close_fds=True)   # no window, detached
        return "restart"
    tool = shutil.which("pkexec")
    if not tool:
        open_path(path)                                   # the software installer opens the package
        return "opened"
    r = subprocess.run([tool, "apt-get", "install", "-y", "--allow-downgrades", path], capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(T("the package was not installed (%s)") % ((r.stderr or r.stdout).strip().splitlines() or ["?"])[-1])
    subprocess.Popen(["sh", "-c", "sleep 2; exec epgtalk-builder"], start_new_session=True,
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return "restart"


def check_update(p, max_age=20 * 3600):
    """Looks at epgtalk.com for a newer version (at most every max_age seconds). Returns the info dict or None."""
    now = time.time()
    if not p.get("check_updates", True) or now - float(p.get("update_checked", 0)) < max_age:
        return p.get("update_info") if vtuple((p.get("update_info") or {}).get("version")) > vtuple(VERSION) else None
    p["update_checked"] = now
    info = None
    try:
        req = urllib.request.Request(UPDATE_URL, headers={"User-Agent": "EPGTalk-Guide-Builder/" + VERSION})
        with urllib.request.urlopen(req, timeout=10) as r:
            info = json.loads(r.read().decode("utf-8"))
    except Exception:
        info = None
    p["update_info"] = info if isinstance(info, dict) else None
    save_profile(p)
    v = (p.get("update_info") or {}).get("version")
    return p["update_info"] if v and vtuple(v) > vtuple(VERSION) else None


# --------------------------------------------------------------------------- #
# Drawn pictures for rounded buttons, tick boxes and tiles (pure Python PNG, no extras needed)
# --------------------------------------------------------------------------- #

def _png(w, h, rgba):
    import struct
    import zlib
    raw = b"".join(b"\x00" + bytes(rgba[y * w * 4:(y + 1) * w * 4]) for y in range(h))

    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)) +
            chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))


def _hex(c):
    c = c.lstrip("#")
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))


def _in_round(x, y, w, h, r):
    if r <= 0:
        return 0 <= x <= w and 0 <= y <= h
    cx = min(max(x, r), w - r)
    cy = min(max(y, r), h - r)
    return (x - cx) ** 2 + (y - cy) ** 2 <= r * r and 0 <= x <= w and 0 <= y <= h


def _seg_dist(px, py, ax, ay, bx, by):
    dx, dy = bx - ax, by - ay
    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / float(dx * dx + dy * dy or 1)))
    return ((px - ax - t * dx) ** 2 + (py - ay - t * dy) ** 2) ** 0.5


_SHAPES = {"done": None, "new": False}


def shape_png(w, h, r, fill, border=None, bw=1.0, mark=None, dot=None):
    """A rounded picture as base64 PNG. Drawing one takes a moment in pure Python, so each is kept
    in shapes.cache (next to the settings) and reused on the next start."""
    if _SHAPES["done"] is None:
        try:
            with open(data("shapes.cache"), encoding="utf-8") as fh:
                _SHAPES["done"] = json.load(fh)
        except (OSError, ValueError):
            _SHAPES["done"] = {}
    key = repr((w, h, r, fill, border, bw, mark, dot))
    if key not in _SHAPES["done"]:
        _SHAPES["done"][key] = _shape_png(w, h, r, fill, border, bw, mark, dot)
        _SHAPES["new"] = True
    return _SHAPES["done"][key]


def shapes_save():
    if _SHAPES["new"]:
        try:
            with open(data("shapes.cache"), "w", encoding="utf-8") as fh:
                json.dump(_SHAPES["done"], fh)
            _SHAPES["new"] = False
        except OSError:
            pass


def _shape_png(w, h, r, fill, border=None, bw=1.0, mark=None, dot=None):
    """A smooth rounded box (base64 PNG): fill colour, optional border, optional white tick mark
    (mark=[(x,y),...] line) or centre dot (dot=radius, white)."""
    import base64
    F, B = _hex(fill), _hex(border) if border else None
    W = (255, 255, 255)
    px = bytearray(w * h * 4)
    S = 4
    for y in range(h):
        for x in range(w):
            outer = inner = mk = 0
            for sy in range(S):
                for sx in range(S):
                    fx, fy = x + (sx + 0.5) / S, y + (sy + 0.5) / S
                    if _in_round(fx, fy, w, h, r):
                        outer += 1
                        if not B or _in_round(fx - bw, fy - bw, w - 2 * bw, h - 2 * bw, max(0, r - bw)):
                            inner += 1
                        if mark and any(_seg_dist(fx, fy, *mark[i], *mark[i + 1]) <= 1.25 for i in range(len(mark) - 1)):
                            mk += 1
                        elif dot and (fx - w / 2.0) ** 2 + (fy - h / 2.0) ** 2 <= dot * dot:
                            mk += 1
            if not outer:
                continue
            a = outer / float(S * S)
            cols = []
            if B:
                cols.append((B, outer - inner))
            cols.append((F, inner - mk))
            cols.append((W, mk))
            tot = float(sum(n for _, n in cols)) or 1.0
            c = [int(sum(col[i] * n for col, n in cols) / tot + 0.5) for i in range(3)]
            o = (y * w + x) * 4
            px[o:o + 4] = bytes((c[0], c[1], c[2], int(a * 255 + 0.5)))
    return base64.b64encode(_png(w, h, px)).decode()


# --------------------------------------------------------------------------- #
# Channel logos: downloaded once, kept in the settings folder ("logos"), shown everywhere
# --------------------------------------------------------------------------- #

def logo_url(u):
    """Normalise a Gracenote / Schedules Direct logo address."""
    if not u:
        return None
    u = u.strip()
    if u.startswith("//"):
        u = "https:" + u
    u = u.replace("zap2it.tmsimg.com", "zpmc.tmsimg.com")
    return u if u.startswith("http") else None


class Logos:
    """Small channel logos for the window. get(url) returns a ready PhotoImage or None (it then
    downloads in the background and calls on_ready(url) when it's there)."""

    BOX = (58, 32)

    def __init__(self, root, tile_png, on_ready):
        import concurrent.futures as cf
        import hashlib
        self.root, self.on_ready, self.hashlib = root, on_ready, hashlib
        self.dir = os.path.join(DATA, "logos")
        os.makedirs(self.dir, exist_ok=True)
        self.imgs, self.pending, self.failed = {}, set(), set()
        self.pool = cf.ThreadPoolExecutor(6)
        self.tile = tile_png
        self.q = queue.Queue()

    def path(self, url):
        return os.path.join(self.dir, self.hashlib.sha1(url.encode()).hexdigest()[:20] + ".png")

    def get(self, url):
        url = logo_url(url)
        if not url or url in self.failed:
            return None
        if url in self.imgs:
            return self.imgs[url]
        f = self.path(url)
        if os.path.exists(f) and os.path.getsize(f) > 0 and time.time() - os.path.getmtime(f) < 60 * 86400:
            img = self._load(f)
            if img is not None:
                self.imgs[url] = img
                return img
            self.failed.add(url)
            return None
        if url not in self.pending:
            self.pending.add(url)
            self.pool.submit(self._fetch, url, f)
        return None

    def _fetch(self, url, f):
        try:
            u = url + ("&" if "?" in url else "?") + "w=88" if "tmsimg.com" in url else url
            req = urllib.request.Request(u, headers={"User-Agent": "EPGTalk-Guide-Builder/" + VERSION})
            with urllib.request.urlopen(req, timeout=20) as r:
                raw = r.read()
            if raw[:8] != b"\x89PNG\r\n\x1a\n" and raw[:6] not in (b"GIF87a", b"GIF89a"):
                raise ValueError("not a PNG/GIF")
            with open(f + ".tmp", "wb") as fh:
                fh.write(raw)
            os.replace(f + ".tmp", f)
            self.q.put(("ok", url, f))
        except Exception:
            self.q.put(("fail", url, None))

    def poll(self):
        """Called from the window's timer: load finished downloads, tell the window."""
        done = []
        try:
            while True:
                done.append(self.q.get_nowait())
        except queue.Empty:
            pass
        for kind, url, f in done:
            self.pending.discard(url)
            img = self._load(f) if kind == "ok" else None
            if img is None:
                self.failed.add(url)
            else:
                self.imgs[url] = img
            self.on_ready(url)

    def _load(self, f):
        """The logo shrunk to fit BOX, sitting on a soft rounded tile. The finished small picture is kept
        next to the download, so later it loads at once (shrinking a big logo takes a moment)."""
        import tkinter as tk
        small = "%s.%s.png" % (f[:-4], self.hashlib.sha1(self.tile.encode()).hexdigest()[:6])
        try:
            if os.path.exists(small) and os.path.getmtime(small) >= os.path.getmtime(f):
                return tk.PhotoImage(master=self.root, file=small)
        except Exception:
            pass
        try:
            src = tk.PhotoImage(master=self.root, file=f)
        except Exception:
            return None
        bw, bh = self.BOX
        w, h = src.width(), src.height()
        k = max(1, -(-w // (bw - 6)), -(-h // (bh - 4)))
        if k > 1:
            src = src.subsample(k, k)
        tile = tk.PhotoImage(master=self.root, data=self.tile)
        x, y = (bw - src.width()) // 2, (bh - src.height()) // 2
        tile.tk.call(str(tile), "copy", str(src), "-to", max(0, x), max(0, y))
        try:
            tile.write(small + ".tmp", format="png")
            os.replace(small + ".tmp", small)
        except Exception:
            pass
        return tile


def guide_channels(path):
    """[(channel id, name, logo url)] and programmes from a guide file (for Home / What's on now)."""
    e = engine()
    chans, progs = e.read_include(path)
    out = []
    for cid, x in chans:
        m = re.search(r"<display-name[^>]*>([^<]*)<", x)
        lg = re.search(r'<icon src="([^"]+)"', x)
        out.append((cid, e.html.unescape(m.group(1)) if m else cid, e.html.unescape(lg.group(1)) if lg else None))
    return out, progs


def xml_time(s):
    try:
        t = dt.datetime(int(s[0:4]), int(s[4:6]), int(s[6:8]), int(s[8:10]), int(s[10:12]), int(s[12:14]))
        off = s[14:].strip()
        if off:
            sign = -1 if off[0] == "-" else 1
            return t.replace(tzinfo=dt.timezone(sign * dt.timedelta(hours=int(off[1:3]), minutes=int(off[3:5]))))
        return t.replace(tzinfo=dt.timezone.utc)
    except (ValueError, IndexError):
        return None


_GUIDE_MEMO = {}
_NOW_MEMO = {}
_NOW_LOCK = threading.Lock()                         # Home and What's on now may ask at the same time: one reads, the rest reuse it


def guide_compact(path):
    """(channels, [(channel id, start, stop, title)]) of a guide - read once, kept until the file changes."""
    st = os.stat(path)
    key = (path, st.st_mtime, st.st_size)
    if _GUIDE_MEMO.get("key") == key:
        return _GUIDE_MEMO["val"]
    # Read in small steps (each search stops at the next programme), so the window never waits on
    # one long search through a big guide file.
    with open(path, "rb") as fh:
        raw = fh.read()
    m = re.search(rb'encoding="([^"]+)"', raw[:200])
    txt = raw.decode(m.group(1).decode() if m else "utf-8", errors="replace")
    del raw
    cut = txt.find("<programme ")
    cut = len(txt) if cut < 0 else cut
    chans = []
    for m in re.finditer(r'<channel id="([^"]*)"(.*?)</channel>', txt[:cut], re.S):
        nm = re.search(r"<display-name[^>]*>([^<]*)<", m.group(2))
        lg = re.search(r'<icon src="([^"]+)"', m.group(2))
        chans.append((html.unescape(m.group(1)), html.unescape(nm.group(1)) if nm else m.group(1),
                      html.unescape(lg.group(1)) if lg else None))
    rp = re.compile(r'<programme\b([^>]*)>\s*(?:<title[^>]*>([^<]*)<)?')
    ra, rb_, rc = re.compile(r'start="([^"]+)"'), re.compile(r'stop="([^"]+)"'), re.compile(r'channel="([^"]*)"')
    out = []
    pos = cut
    while True:
        m = rp.search(txt, pos)
        if not m:
            break
        at = m.group(1)
        a_, b_, c_ = ra.search(at), rb_.search(at), rc.search(at)
        if a_ and b_ and c_:
            out.append((html.unescape(c_.group(1)), a_.group(1), b_.group(1), html.unescape(m.group(2) or "")))
        pos = m.end()
        if len(out) % 2000 == 0:
            time.sleep(0)                              # let the window draw
    _GUIDE_MEMO.clear()
    _GUIDE_MEMO.update(key=key, val=(chans, out))
    return chans, out


def guide_grid_data(path):
    """(channels, {channel id: [(start, stop, title, raw start)]}) for the TV guide grid, sorted by time."""
    chans, progs = guide_compact(path)
    if _GUIDE_MEMO.get("grid_key") == _GUIDE_MEMO.get("key") and "grid" in _GUIDE_MEMO:
        return chans, _GUIDE_MEMO["grid"]
    by = {}
    for cid, sa, sb, title in progs:
        a, b = xml_time(sa), xml_time(sb)
        if a and b and b > a:
            by.setdefault(cid, []).append((a, b, title, sa))
    for v in by.values():
        v.sort(key=lambda x: x[0])
    _GUIDE_MEMO.update(grid=by, grid_key=_GUIDE_MEMO.get("key"))
    return chans, by


def programme_details(path, cid, sa):
    """Everything the guide says about one show: title, episode, description, categories, new/live."""
    with open(path, "rb") as fh:
        raw = fh.read()
    m = re.search(rb'encoding="([^"]+)"', raw[:200])
    txt = raw.decode(m.group(1).decode() if m else "utf-8", errors="replace")
    needle = 'start="%s"' % sa
    i = txt.find(needle)
    while i >= 0:
        a = txt.rfind("<programme", 0, i)
        tag_end = txt.find(">", i)
        if a >= 0 and ('channel="%s"' % html.escape(cid, quote=True) in txt[a:tag_end] or 'channel="%s"' % cid in txt[a:tag_end]):
            z = txt.find("</programme>", tag_end)
            x = txt[a:z]

            def one(tag):
                m_ = re.search(r"<%s[^>]*>([^<]*)<" % tag, x)
                return html.unescape(m_.group(1)).strip() if m_ else ""
            ep = re.search(r'<episode-num system="onscreen">([^<]*)<', x)
            return {"title": one("title"), "sub": one("sub-title"), "desc": one("desc"),
                    "ep": html.unescape(ep.group(1)) if ep else "",
                    "cats": [html.unescape(c) for c in re.findall(r"<category[^>]*>([^<]*)<", x)][:4],
                    "new": "<new" in x, "live": "<live" in x, "rating": one("value")}
        i = txt.find(needle, i + 1)
    return {}


def on_now(path, limit=None):
    """[(name, logo, now title, start, stop, next title, next start)] for every channel, right now."""
    with _NOW_LOCK:
        st = os.stat(path)
        mk = (path, st.st_mtime, st.st_size, dt.datetime.now().strftime("%Y%m%d%H%M"), limit)
        if _NOW_MEMO.get("key") != mk:
            _NOW_MEMO.update(key=mk, val=_on_now(path, limit))
        return _NOW_MEMO["val"]


def _on_now(path, limit=None):
    chans, progs = guide_compact(path)
    now = dt.datetime.now(dt.timezone.utc)
    days = {(now + dt.timedelta(days=d)).strftime("%Y%m%d") for d in (-1, 0, 1, 2)}
    cur, nxt = {}, {}
    for cid, sa, sb, title in progs:
        if sa[:8] not in days:
            continue                                   # far from now: skip without reading the time
        a, b = xml_time(sa), xml_time(sb)
        if not a or not b:
            continue
        if a <= now < b:
            cur[cid] = (title, a, b)
        elif a >= now and (cid not in nxt or a < nxt[cid][1]):
            nxt[cid] = (title, a)
    rows = []
    for cid, name, logo in chans:
        c, n = cur.get(cid), nxt.get(cid)
        rows.append((name, logo, c[0] if c else None, c[1] if c else None, c[2] if c else None,
                     n[0] if n else None, n[1] if n else None))
        if limit and len(rows) >= limit:
            break
    return rows, len(progs)


# --------------------------------------------------------------------------- #
# Back up / restore settings (one .zip with providers, channels, names and settings)
# --------------------------------------------------------------------------- #

PICK_FILE = re.compile(r"(x_[a-z]+|m_[0-9a-f]{10})\.(chl|ren|twk|known)")


def backup_settings(dst, with_login=False):
    import zipfile
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("epgtalk-builder-backup.json", json.dumps({"app": APP, "version": VERSION,
                                                              "made": dt.datetime.now().strftime("%Y-%m-%d %H:%M")}))
        for f in sorted(os.listdir(DATA)):
            if f == "builder.json" and not with_login:
                pr = load_profile()
                if re.match(r"https?://", (pr.get("playlist") or {}).get("src", "")):
                    pr["playlist"]["src"] = ""                 # the playlist address usually holds the IPTV login
                z.writestr(f, json.dumps(pr, indent=1))
            elif f == "builder.json" or re.fullmatch(r"lineup\d+\.(dat|chl|ren|twk)(\.orig)?", f) or PICK_FILE.fullmatch(f) or \
                    (with_login and f == "sd.login"):
                z.write(os.path.join(DATA, f), f)


def restore_settings(src):
    """Replaces the providers / settings with a backup. The current ones are saved first.
    Returns the safety copy's path."""
    import zipfile
    with zipfile.ZipFile(src) as z:
        names = z.namelist()
        if "epgtalk-builder-backup.json" not in names or "builder.json" not in names:
            raise RuntimeError(T("This is not an EPGTalk Guide Builder backup."))
        safety = data("before-restore-%s.zip" % dt.datetime.now().strftime("%Y%m%d-%H%M%S"))
        backup_settings(safety, with_login=True)
        for f in os.listdir(DATA):
            if re.fullmatch(r"lineup\d+\.(dat|chl|ren|twk)(\.orig)?", f) or PICK_FILE.fullmatch(f):
                os.remove(os.path.join(DATA, f))
        for n in names:
            if n == "builder.json" or re.fullmatch(r"lineup\d+\.(dat|chl|ren|twk)(\.orig)?", n) or PICK_FILE.fullmatch(n) or n == "sd.login":
                with open(os.path.join(DATA, n), "wb") as fh:
                    fh.write(z.read(n))
    p = load_profile()
    o = p.get("output") or "guide.xml"
    if os.path.isabs(o) and not os.path.isdir(os.path.dirname(o)):
        p["output"] = "guide.xml"                    # the backup came from another computer
    for k in ("geometry", "window", "window_max"):    # the other computer's screen
        p.pop(k, None)
    p["changed"] = True
    save_profile(p)
    return safety


# --------------------------------------------------------------------------- #
# Move to my NAS: hand everything to the Guide Builder 2.0 running on a NAS / home server
# --------------------------------------------------------------------------- #

def nas_base(addr):
    """'192.168.1.50', 'nas.local:8765', 'http://x:8765/anything' -> 'http://192.168.1.50:8765'."""
    import urllib.parse
    a = (addr or "").strip()
    if not a:
        raise RuntimeError(T("Type your NAS address first."))
    if not re.match(r"https?://", a, re.I):
        a = "http://" + a
    u = urllib.parse.urlsplit(a)
    if not u.hostname:
        raise RuntimeError(T("That doesn't look like an address (for example 192.168.1.50:8765)."))
    host = "[%s]" % u.hostname if ":" in u.hostname else u.hostname
    return "%s://%s:%d" % (u.scheme.lower(), host, u.port or 8765)


def nas_call(base, path, body=None, cookie=None, timeout=20):
    """(answer, cookie it set) from the Guide Builder on the NAS."""
    import urllib.error
    raw = None if body is None else json.dumps(body).encode("utf-8")
    req = urllib.request.Request(base + path, data=raw, headers={"User-Agent": "EPGTalk-Guide-Builder/" + VERSION})
    if raw is not None:
        req.add_header("Content-Type", "application/json")
        req.add_header("X-EPGTalk", "1")
    if cookie:
        req.add_header("Cookie", cookie)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8") or "{}"), r.headers.get("Set-Cookie")
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode("utf-8")).get("error")
        except Exception:
            msg = None
        raise RuntimeError(msg or "HTTP %s" % e.code)


def nas_check(base):
    """(version, asks for a password) of the Guide Builder at that address."""
    try:
        v, _ = nas_call(base, "/api/ping", timeout=6)
        a, _ = nas_call(base, "/api/auth", timeout=6)
    except Exception:
        raise RuntimeError(T("No Guide Builder answered at %s. Is it running on your NAS, and is the address right?") % base)
    if not v.get("ok"):
        raise RuntimeError(T("No Guide Builder answered at %s. Is it running on your NAS, and is the address right?") % base)
    return v.get("version", "?"), bool(a.get("needed"))


def nas_move(base, password="", with_login=False, step=None):
    """Sends the providers, channels and settings to the NAS (like a backup + restore there) and starts
    a build on it. step(text) reports progress. Returns the NAS version."""
    import base64
    step = step or (lambda t: None)
    ver, needed = nas_check(base)
    cookie = None
    if needed:
        if not password:
            raise RuntimeError(T("Your NAS asks for a password — type it in the box."))
        _, sc = nas_call(base, "/api/login", {"password": password})
        cookie = (sc or "").split(";")[0] or None
    step(T("Packing up your providers and channels…"))
    tmp = data("move-to-nas.zip")
    try:
        backup_settings(tmp, with_login)
        with open(tmp, "rb") as fh:
            z = base64.b64encode(fh.read()).decode("ascii")
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass
    step(T("Sending them to your NAS…"))
    nas_call(base, "/api/restore", {"zip": z}, cookie, timeout=120)
    step(T("Building your guide on the NAS…"))
    nas_call(base, "/api/build", {}, cookie)
    return ver


# --------------------------------------------------------------------------- #
# The window
# --------------------------------------------------------------------------- #

THEMES = {
    "light": {"bg": "#f4f7fb", "card": "#ffffff", "border": "#e1e8f1", "text": "#17202e", "muted": "#5b6b80",
              "accent": "#0077b6", "accent_d": "#005f91", "border_strong": "#c3cfdd", "accent_soft": "#e3f3fc", "accent_text": "#005f91",
              "side": "#0d1726", "side_hi": "#16294a", "side_text": "#ffffff", "side_muted": "#9fb6d1", "side_dim": "#6f86a3",
              "ok": "#1d8a4e", "ok_soft": "#e4f6ec", "err": "#c0392b", "err_soft": "#fdecea", "warn": "#a15c00", "warn_soft": "#fff3df",
              "off": "#c9d4e3", "off_text": "#8b98aa", "log_bg": "#0d1726", "log_fg": "#d9ecff", "field": "#ffffff",
              "sel": "#d6ecfa", "tile_sd": "#ece9fb", "tile_sd_fg": "#534ab7", "tile_off": "#f1f3f6", "logo_tile": "#eef2f7",
              "stripe": "#f8fafd", "on_accent": "#ffffff", "nav_on": "#ffffff", "nav_icon_on": "#33bfff", "nav_ring": "#16294a",
              "tech": False},
    "dark": {"bg": "#0a0f1a", "card": "#0f1726", "border": "#1f2d44", "text": "#dbe6f5", "muted": "#7a8aa3",
             "accent": "#22d3ee", "accent_d": "#06b6d4", "border_strong": "#2c3f5e", "accent_soft": "#0b2a36", "accent_text": "#67e8f9",
             "side": "#060a12", "side_hi": "#0f1a2b", "side_text": "#e8f1ff", "side_muted": "#6f7f99", "side_dim": "#4f5d75",
             "ok": "#34d399", "ok_soft": "#0d2e24", "err": "#f87171", "err_soft": "#331a1f", "warn": "#fbbf24", "warn_soft": "#33290f",
             "off": "#26344d", "off_text": "#5d6b83", "log_bg": "#05080f", "log_fg": "#cfe8ff", "field": "#0b1322",
             "sel": "#12324a", "tile_sd": "#1e1b3a", "tile_sd_fg": "#b9b2f5", "tile_off": "#141d2e", "logo_tile": "#e9eef5",
             "stripe": "#0d1422", "on_accent": "#04121a", "nav_on": "#22d3ee", "nav_icon_on": "#22d3ee", "nav_ring": "#164e63",
             "tech": True},
}


INSTANCE = data("instance.json")                     # how to reach the open window (port + secret, this computer only)
TRAY_ICON = data("tray-icon.png")
AUTOSTART_LINUX = os.path.join(os.path.expanduser("~"), ".config", "autostart", "epgtalk-builder.desktop")
AUTOSTART_WIN = "EPGTalk Guide Builder"


def instance_send(cmd, timeout=2.0):
    """Sends a command (show, build, copy, quit, status, ping) to the open window. None if none is open."""
    import socket
    try:
        with open(INSTANCE, encoding="utf-8") as fh:
            info = json.load(fh)
        with socket.create_connection(("127.0.0.1", int(info["port"])), timeout=timeout) as c:
            c.settimeout(timeout)
            c.sendall(("%s %s\n" % (info["token"], cmd)).encode())
            got = b""
            while not got.endswith(b"\n"):
                chunk = c.recv(4096)
                if not chunk:
                    break
                got += chunk
        return got.decode("utf-8", "replace").strip() or "ok"
    except Exception:
        return None


def run_args(*extra):
    """The command that starts this program again (with extra options)."""
    return ([sys.executable] if FROZEN else [python_for_tasks(), os.path.abspath(__file__)]) + list(extra)


def autostart_is_on():
    if IS_WIN:
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run") as k:
                winreg.QueryValueEx(k, AUTOSTART_WIN)
                return True
        except OSError:
            return False
    return os.path.exists(AUTOSTART_LINUX)


def autostart_set(on):
    """Start with the computer (in the background), or not."""
    cmd = run_args("--background")
    if IS_WIN:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run", 0, winreg.KEY_SET_VALUE) as k:
            if on:
                winreg.SetValueEx(k, AUTOSTART_WIN, 0, winreg.REG_SZ, " ".join('"%s"' % x if " " in x else x for x in cmd))
            else:
                try:
                    winreg.DeleteValue(k, AUTOSTART_WIN)
                except OSError:
                    pass
        return
    if on:
        os.makedirs(os.path.dirname(AUTOSTART_LINUX), exist_ok=True)
        exe = "epgtalk-builder --background" if INSTALLED and shutil.which("epgtalk-builder") else \
            " ".join('"%s"' % x.replace('"', '\\"') for x in cmd)
        with open(AUTOSTART_LINUX, "w", encoding="utf-8") as fh:
            fh.write("[Desktop Entry]\nType=Application\nName=EPGTalk Guide Builder\nComment=Shares your TV guide in the background\n"
                     "Exec=%s\nIcon=epgtalk-builder\nTerminal=false\nX-GNOME-Autostart-enabled=true\nX-GNOME-Autostart-Delay=10\n" % exe)
    else:
        try:
            os.remove(AUTOSTART_LINUX)
        except OSError:
            pass


def tray_status(send):
    r = send("status")
    if r is None:
        return None
    try:
        st = json.loads(r)
    except ValueError:
        return APP
    return ("● " + T("Sharing on") if st.get("share") else "○ " + T("Sharing off")) + "  ·  " + \
        {"ready": T("guide ready"), "changed": T("changes not built yet"), "failed": T("the last update failed"),
         "none": T("no guide yet")}.get(st.get("state"), "")


def tray_main():
    """--tray [PID]: the little icon next to the clock. A separate small program that talks to the open window,
    so a problem with the icon can never stop the guide. It goes as soon as its program (PID) is gone.
    Exits 3 if this computer can't show tray icons."""
    owner = None
    try:
        owner = int(sys.argv[sys.argv.index("--tray") + 1])
    except (ValueError, IndexError):
        pass
    p = load_profile()
    set_lang(p.get("lang", "en"))
    import base64
    send = instance_send
    if IS_WIN:
        try:
            import io
            import pystray
            from PIL import Image
        except Exception:
            return 3
        img = Image.open(io.BytesIO(base64.b64decode("".join(ICON_PNG))))
        state = {"text": tray_status(send) or APP, "miss": 0}

        def quit_(icon, item):
            send("quit")
            icon.stop()
        menu = pystray.Menu(pystray.MenuItem(lambda item: state["text"], None, enabled=False), pystray.Menu.SEPARATOR,
                            pystray.MenuItem(T("Open"), lambda icon, item: send("show"), default=True),
                            pystray.MenuItem(T("Build now"), lambda icon, item: send("build")),
                            pystray.MenuItem(T("Copy the TV address"), lambda icon, item: send("copy")),
                            pystray.Menu.SEPARATOR, pystray.MenuItem(T("Quit"), quit_))
        icon = pystray.Icon("epgtalk-builder", img, APP, menu)

        def watch():
            while True:
                for _ in range(15):
                    time.sleep(1)
                    if owner and not pid_alive(owner):
                        icon.stop()
                        return
                t = tray_status(send)
                if t is None:
                    state["miss"] += 1
                    if state["miss"] >= 3:                 # the window is gone: go too
                        icon.stop()
                        return
                else:
                    state["miss"] = 0
                    state["text"] = t
                    try:
                        icon.update_menu()
                    except Exception:
                        pass

        def setup(ic):
            ic.visible = True
            threading.Thread(target=watch, daemon=True).start()
        icon.run(setup=setup)
        return 0
    try:
        import gi
        gi.require_version("Gtk", "3.0")
        try:
            gi.require_version("AyatanaAppIndicator3", "0.1")
            from gi.repository import AyatanaAppIndicator3 as AI
        except (ValueError, ImportError):
            gi.require_version("AppIndicator3", "0.1")
            from gi.repository import AppIndicator3 as AI
        from gi.repository import Gtk, GLib
    except Exception:
        return 3
    try:
        with open(TRAY_ICON, "wb") as fh:
            fh.write(base64.b64decode("".join(ICON_PNG)))
    except OSError:
        pass
    ind = AI.Indicator.new("epgtalk-builder", TRAY_ICON, AI.IndicatorCategory.APPLICATION_STATUS)
    ind.set_status(AI.IndicatorStatus.ACTIVE)
    try:
        ind.set_title(APP)
    except Exception:
        pass
    menu = Gtk.Menu()
    st_item = Gtk.MenuItem(label=tray_status(send) or APP)
    st_item.set_sensitive(False)
    menu.append(st_item)
    menu.append(Gtk.SeparatorMenuItem())
    for label, cmd in ((T("Open"), "show"), (T("Build now"), "build"), (T("Copy the TV address"), "copy")):
        it = Gtk.MenuItem(label=label)
        it.connect("activate", lambda w, c=cmd: send(c))
        menu.append(it)
    menu.append(Gtk.SeparatorMenuItem())
    qi = Gtk.MenuItem(label=T("Quit"))
    qi.connect("activate", lambda w: (send("quit"), Gtk.main_quit()))
    menu.append(qi)
    menu.show_all()
    ind.set_menu(menu)
    miss = [0]

    def refresh():
        t = tray_status(send)
        if t is None:
            miss[0] += 1
            if miss[0] >= 3:
                Gtk.main_quit()
                return False
        else:
            miss[0] = 0
            st_item.set_label(t)
        return True
    GLib.timeout_add_seconds(15, refresh)

    def owner_check():
        if owner and not pid_alive(owner):
            Gtk.main_quit()
            return False
        return True
    GLib.timeout_add_seconds(1, owner_check)
    Gtk.main()
    return 0


_WIN = {"root": None, "tray": None, "fonts": {}, "keep": []}   # kept when the look or language changes


def pid_alive(pid):
    """True while the program with this process id runs (without disturbing it)."""
    if IS_WIN:
        try:
            import ctypes
            h = ctypes.windll.kernel32.OpenProcess(0x1000, False, int(pid))      # PROCESS_QUERY_LIMITED_INFORMATION
            if not h:
                return False
            code = ctypes.c_ulong()
            ctypes.windll.kernel32.GetExitCodeProcess(h, ctypes.byref(code))
            ctypes.windll.kernel32.CloseHandle(h)
            return code.value == 259                                             # STILL_ACTIVE
        except Exception:
            return True
    try:
        os.kill(int(pid), 0)
        return True
    except ProcessLookupError:
        return False
    except Exception:
        return True


def gui(background=False):
    """Opens the window. Returns 'restart' when the look or language changed: the same window is then
    filled again in the new look (no second window). background=True: start hidden (sharing only)."""
    import tkinter as tk
    from tkinter import ttk, messagebox, filedialog, font as tkfont

    if IS_WIN:
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)        # sharp text on high-DPI screens
        except Exception:
            pass

    p = load_profile()
    set_lang(p.get("lang", "en"))
    P = THEMES.get(p.get("theme", "light"), THEMES["light"])
    root = _WIN["root"]
    reuse = False
    if root is not None:
        try:
            reuse = bool(root.winfo_exists())
        except Exception:
            reuse = False
    if reuse:                                          # look or language switched: empty the window, keep it on screen
        for aid in root.tk.splitlist(root.tk.call("after", "info")):
            try:
                root.after_cancel(aid)
            except Exception:
                pass
        for w in root.winfo_children():
            w.destroy()
        root.config(menu="")
        for ev in ("<MouseWheel>", "<Button-4>", "<Button-5>", "<F5>", "<Control-b>", "<Control-B>"):
            root.unbind_all(ev)
        root.unbind_class("TButton", "<Map>")
    else:
        root = tk.Tk(className="epgtalk-builder")      # lets the dock match the window to its icon
        _WIN["root"] = root
        if background:
            root.withdraw()
    root.title("%s - %s" % (APP, T(CREDIT)))
    def place(win, w, h, over=None):
        """A window size that fits this screen (taskbar included), for sizes made for normal text: with
        bigger Windows display scaling the window grows too. Windows opens new windows in the top-left
        corner, so there we centre them ourselves; Linux desktops centre them already (and can see two
        screens as one wide one, so we leave the position to them)."""
        k = max(1.0, float(root.tk.call("tk", "scaling")) / (96 / 72))
        sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
        if not IS_WIN:
            return "%dx%d" % (min(int(w * k), int(sw * 0.94)), min(int(h * k), int(sh * 0.85)))
        ax, ay, aw, ah = 0, 0, sw, sh - 48
        bw, cap, menu = 8, 23, 20
        try:
            import ctypes
            import ctypes.wintypes as wt
            r = wt.RECT()
            if ctypes.windll.user32.SystemParametersInfoW(0x30, 0, ctypes.byref(r), 0):    # screen minus taskbar
                ax, ay, aw, ah = r.left, r.top, r.right - r.left, r.bottom - r.top
            gm = ctypes.windll.user32.GetSystemMetrics
            bw, cap, menu = gm(33) + gm(92), gm(4), gm(15)       # frame border, title bar, menu bar
        except Exception:
            pass
        # Tk's size is the inside of the window; the title bar, menu bar and borders come on top
        extra_w, extra_h = 2 * bw, cap + (menu if win is root else 0) + 2 * bw
        w, h = min(int(w * k), aw - extra_w - 16), min(int(h * k), ah - extra_h - 12)
        fw, fh = w + extra_w, h + extra_h
        if over is not None and over.winfo_viewable():
            x = over.winfo_rootx() + (over.winfo_width() - fw) // 2
            y = over.winfo_rooty() + (over.winfo_height() - fh) // 2
        else:
            x, y = ax + (aw - fw) // 2, ay + (ah - fh) // 2
        y = max(ay, min(y, ay + ah - fh))
        return "%dx%d+%d+%d" % (w, h, x, y)

    def on_screen(geo):
        """False for a saved Windows position that is off every screen (e.g. a monitor was unplugged)."""
        m = re.match(r"(\d+)x(\d+)([+-]-?\d+)([+-]-?\d+)$", geo or "")
        if not m:
            return False
        if not IS_WIN:
            return True
        try:
            import ctypes
            gm = ctypes.windll.user32.GetSystemMetrics
            vx, vy, vw, vh = gm(76), gm(77), gm(78), gm(79)          # the area of all screens together
        except Exception:
            vx, vy, vw, vh = 0, 0, root.winfo_screenwidth(), root.winfo_screenheight()
        w, h, x, y = int(m.group(1)), int(m.group(2)), int(m.group(3)), int(m.group(4))
        return vx - w + 120 <= x <= vx + vw - 120 and vy <= y <= vy + vh - 80 and h <= vh

    if not reuse:                                      # a reused window keeps its size and place
        g = p.get("window")
        root.geometry(g if on_screen(g) else place(root, 1120, 760))
        root.minsize(min(900, int(root.winfo_screenwidth() * 0.9)), min(600, int(root.winfo_screenheight() * 0.75)))
        if p.get("window_max"):
            try:
                root.state("zoomed") if IS_WIN else root.attributes("-zoomed", True)
            except tk.TclError:
                pass
    root.configure(bg=P["bg"])
    try:
        root.iconphoto(True, tk.PhotoImage(data="".join(ICON_PNG)))
    except Exception:
        pass
    result = {"restart": False}
    keep = _WIN["keep"]                                  # images must stay referenced (also across look switches)

    # ---------------- fonts ----------------
    fam = tkfont.nametofont("TkDefaultFont").cget("family")
    base = _WIN["fonts"]                                 # the system's own sizes, read once (later they're scaled)
    for nm in ("TkDefaultFont", "TkTextFont", "TkHeadingFont", "TkMenuFont", "TkFixedFont", "TkCaptionFont"):
        if nm not in base:
            try:
                base[nm] = abs(int(tkfont.nametofont(nm).cget("size"))) or 10
            except tk.TclError:
                pass
    F = {"title": tkfont.Font(family=fam, size=18, weight="bold"), "h": tkfont.Font(family=fam, size=12, weight="bold"),
         "mid": tkfont.Font(family=fam, size=11), "small": tkfont.Font(family=fam, size=9),
         "nav": tkfont.Font(family=fam, size=11), "brand": tkfont.Font(family=fam, size=13, weight="bold"),
         "big": tkfont.Font(family=fam, size=20, weight="bold"), "url": tkfont.Font(family=fam, size=15, weight="bold"),
         "hello": tkfont.Font(family=fam, size=20, weight="bold"), "status": tkfont.Font(family=fam, size=14, weight="bold"),
         "bold": tkfont.Font(family=fam, size=10, weight="bold"), "tiny": tkfont.Font(family=fam, size=8),
         "link": tkfont.Font(family=fam, size=11, underline=1),
         "mono": tkfont.Font(family=tkfont.nametofont("TkFixedFont").cget("family"), size=10),
         "mono_big": tkfont.Font(family=tkfont.nametofont("TkFixedFont").cget("family"), size=15, weight="bold")}
    FBASE = {k: abs(int(f.cget("size"))) for k, f in F.items()}

    # ---------------- rounded pictures + ttk style ----------------
    st = ttk.Style()
    try:
        st.theme_use("clam")
    except tk.TclError:
        pass

    def img(b64):
        im = tk.PhotoImage(data=b64)
        keep.append(im)
        return im

    def stretch(small, w, h, bx, by):
        """Makes a big copy of a small rounded picture: corners kept, the middle filled once here.
        Tk repeats an image element's middle strip to fill the button, and on Linux every repeat is a
        slow round trip to the screen - a 2-pixel strip made each page switch lag. Big picture = one draw."""
        sw, sh = small.width(), small.height()
        big = tk.PhotoImage(width=w, height=h)
        for (fx0, fx1, tx0, tx1) in ((0, bx, 0, bx), (bx, sw - bx, bx, w - bx), (sw - bx, sw, w - bx, w)):
            for (fy0, fy1, ty0, ty1) in ((0, by, 0, by), (by, sh - by, by, h - by), (sh - by, sh, h - by, h)):
                big.tk.call(big, "copy", small, "-from", fx0, fy0, fx1, fy1, "-to", tx0, ty0, tx1, ty1)
        keep.append(big)
        return big

    LOOK = p.get("theme", "light")

    def pill_element(name, normal, active, disabled, pressed=None):
        """A fully rounded button background (normal / hover / pressed / disabled)."""
        def mk(fill, border):
            return stretch(img(shape_png(32, 30, 14.5, fill, border, 1.2)), 640, 120, 15, 14)
        el = name + ".pill" + LOOK
        if el not in st.element_names():
            n, a, d = mk(*normal), mk(*active), mk(*disabled)
            pr = mk(*pressed) if pressed else a
            st.element_create(el, "image", n, ("disabled", d), ("pressed", pr), ("active", a),
                              border=(15, 14, 15, 14), sticky="nsew", width=32, height=30)   # size of the small original
        st.layout(name, [(el, {"sticky": "nsew", "children": [
            ("Button.padding", {"sticky": "nsew", "children": [("Button.label", {"sticky": "nsew"})]})]})])

    try:
        pill_element("TButton", (P["card"], P["border_strong"]), (P["accent_soft"], P["accent"]), (P["bg"], P["border"]))
        pill_element("Accent.TButton", (P["accent"], P["accent"]), (P["accent_d"], P["accent_d"]), (P["off"], P["off"]))
        pill_element("Big.TButton", (P["accent"], P["accent"]), (P["accent_d"], P["accent_d"]), (P["off"], P["off"]))
        pill_element("Chip.TButton", (P["card"], P["border_strong"]), (P["accent_soft"], P["accent"]), (P["bg"], P["border"]))
        pill_element("ChipOn.TButton", (P["accent_soft"], P["accent"]), (P["accent_soft"], P["accent_d"]), (P["bg"], P["border"]))
        pill_element("Danger.TButton", (P["card"], P["err"]), (P["err_soft"], P["err"]), (P["bg"], P["border"]))
        chk_off = img(shape_png(18, 18, 5, P["field"], P["border_strong"], 1.5))
        chk_on = img(shape_png(18, 18, 5, P["accent"], None, 1, mark=[(4.5, 9.2), (7.6, 12.4), (13.6, 5.6)]))
        chk_dis = img(shape_png(18, 18, 5, P["bg"], P["border"], 1.5))
        rad_off = img(shape_png(18, 18, 9, P["field"], P["border_strong"], 1.5))
        rad_on = img(shape_png(18, 18, 9, P["accent"], None, 1, dot=3.2))
        if "Round.Checkbutton.indicator" + LOOK not in st.element_names():
            st.element_create("Round.Checkbutton.indicator" + LOOK, "image", chk_off, ("disabled", chk_dis), ("selected", chk_on),
                              border=0, sticky="", padding=(0, 0, 8, 0))
            st.element_create("Round.Radiobutton.indicator" + LOOK, "image", rad_off, ("selected", rad_on), border=0, sticky="",
                              padding=(0, 0, 8, 0))
        for w, ind in (("TCheckbutton", "Round.Checkbutton.indicator" + LOOK), ("TRadiobutton", "Round.Radiobutton.indicator" + LOOK)):
            st.layout(w, [(w.replace("T", "", 1) + ".padding", {"sticky": "nswe", "children": [
                (ind, {"side": "left", "sticky": ""}),
                (w.replace("T", "", 1) + ".focus", {"side": "left", "sticky": "w", "children": [
                    (w.replace("T", "", 1) + ".label", {"sticky": "nswe"})]})]})])
        ROUND = True
    except Exception:
        chk_off = chk_on = None
        ROUND = False                                 # very old Tk: plain look still works

    def style():
        st.configure(".", background=P["bg"], foreground=P["text"], bordercolor=P["border"], focuscolor=P["accent"],
                     troughcolor=P["border"], fieldbackground=P["field"], insertcolor=P["text"], lightcolor=P["card"],
                     darkcolor=P["border"], selectbackground=P["sel"], selectforeground=P["text"])
        st.configure("TFrame", background=P["bg"])
        st.configure("Card.TFrame", background=P["card"])
        st.configure("TLabel", background=P["bg"], foreground=P["text"])
        st.configure("Card.TLabel", background=P["card"], foreground=P["text"])
        st.configure("Muted.TLabel", background=P["bg"], foreground=P["muted"])
        st.configure("CardMuted.TLabel", background=P["card"], foreground=P["muted"])
        st.configure("TButton", foreground=P["text"], padding=(14, 5), anchor="center", width=0)
        st.map("TButton", foreground=[("disabled", P["off_text"])])
        st.configure("Accent.TButton", foreground=P["on_accent"], padding=(16, 6), anchor="center", width=0)
        st.configure("Big.TButton", foreground=P["on_accent"], padding=(28, 12), anchor="center", font=F["h"], width=0)
        st.configure("Chip.TButton", foreground=P["text"], padding=(10, 1), anchor="center", font=F["small"], width=0)
        st.configure("ChipOn.TButton", foreground=P["accent_text"], padding=(10, 1), anchor="center", font=F["small"], width=0)
        st.configure("Danger.TButton", foreground=P["err"], padding=(14, 5), anchor="center", width=0)
        if not ROUND:
            for s_ in ("TButton", "Chip.TButton", "Danger.TButton"):
                st.configure(s_, background=P["card"], bordercolor=P["border_strong"], lightcolor=P["card"], darkcolor=P["card"])
            for s_ in ("Accent.TButton", "Big.TButton", "ChipOn.TButton"):
                st.configure(s_, background=P["accent"], bordercolor=P["accent"], lightcolor=P["accent"], darkcolor=P["accent"])
        for w in ("TCheckbutton", "TRadiobutton"):
            st.configure(w, background=P["bg"], foreground=P["text"], indicatorbackground=P["field"], indicatorforeground=P["accent"])
            st.map(w, background=[("active", P["bg"])])
            st.configure("Card." + w, background=P["card"], foreground=P["text"])
            st.map("Card." + w, background=[("active", P["card"])])
        st.configure("TEntry", fieldbackground=P["field"], foreground=P["text"], bordercolor=P["border_strong"], padding=6,
                     lightcolor=P["field"], darkcolor=P["field"])
        st.map("TEntry", bordercolor=[("focus", P["accent"])], lightcolor=[("focus", P["accent"])])
        st.configure("TSpinbox", fieldbackground=P["field"], foreground=P["text"], arrowcolor=P["text"], background=P["card"],
                     bordercolor=P["border_strong"])
        st.configure("TCombobox", fieldbackground=P["field"], foreground=P["text"], arrowcolor=P["text"], background=P["card"],
                     bordercolor=P["border_strong"])
        st.map("TCombobox", fieldbackground=[("readonly", P["field"])], foreground=[("readonly", P["text"])])
        st.configure("Treeview", background=P["card"], fieldbackground=P["card"], foreground=P["text"], bordercolor=P["card"],
                     borderwidth=0)
        st.map("Treeview", background=[("selected", P["sel"])], foreground=[("selected", P["text"])])
        st.configure("Treeview.Heading", background=P["card"], foreground=P["muted"], relief="flat", font=F["tiny"], padding=(8, 7),
                     bordercolor=P["card"], lightcolor=P["card"], darkcolor=P["card"])
        st.map("Treeview.Heading", background=[("active", P["accent_soft"])])
        st.configure("Horizontal.TProgressbar", background=P["ok"], troughcolor=P["border"], bordercolor=P["border"],
                     lightcolor=P["ok"], darkcolor=P["ok"], thickness=8)
        st.configure("Vertical.TScrollbar", background=P["card"], troughcolor=P["bg"], arrowcolor=P["muted"], bordercolor=P["bg"],
                     lightcolor=P["card"], darkcolor=P["card"])

    def side_width(scale):
        return int(220 * max(1.0, float(scale)) ** 0.9)

    def set_text(scale):
        p["text"] = scale
        for nm, sz in base.items():
            tkfont.nametofont(nm).configure(size=max(8, round(sz * scale)))
        for k, f in F.items():
            f.configure(size=max(8, round(FBASE[k] * scale)))
        lh = tkfont.nametofont("TkDefaultFont").metrics("linespace")
        st.configure("Treeview", rowheight=max(38, int(lh * 2.1)))
        try:
            side.configure(width=side_width(scale))        # bigger text: a wider menu, so nothing gets cut off
        except NameError:
            pass                                       # (first call: the menu isn't made yet)
        save_profile(p)
    style()
    set_text(float(p.get("text", 1.0)))

    # Rounded buttons: the corners outside the round shape show the button's background colour. Give
    # buttons that sit on a card a card-coloured twin style, and keep that colour on hover/press
    # (the clam theme lightens it, which showed as a square behind the round button).
    PILLS = ("TButton", "Accent.TButton", "Big.TButton", "Chip.TButton", "ChipOn.TButton", "Danger.TButton")
    if ROUND:
        for s_ in PILLS:
            for bgc, name in ((P["bg"], s_), (P["card"], "Card." + s_)):
                if name != s_:
                    st.configure(name, background=bgc)
                st.map(name, background=[("pressed", bgc), ("active", bgc), ("disabled", bgc)])

        def card_btn(e):
            w = e.widget
            try:
                sty = str(w.cget("style")) or "TButton"
                if sty in PILLS and str(w.nametowidget(w.winfo_parent()).cget("bg")) == P["card"]:
                    w.configure(style="Card." + sty)
            except (tk.TclError, KeyError):
                pass                                    # ttk frames have no bg: those sit on the page colour
        root.bind_class("TButton", "<Map>", card_btn, add="+")

    # ---------------- threads -> window ----------------
    q = queue.Queue()

    def ui(fn, *a):
        q.put((fn, a))

    pump_id = [None]

    def pump():
        try:
            while True:
                fn, a = q.get_nowait()
                fn(*a)
        except queue.Empty:
            pass
        try:
            logos.poll()
        except NameError:
            pass
        pump_id[0] = root.after(80, pump)
    pump_id[0] = root.after(80, pump)

    def work(fn, done=None, fail=None):
        def run():
            try:
                r = fn()
                if done:
                    ui(done, r)
            except Exception as ex:
                ui(fail or (lambda m: messagebox.showerror(APP, m, parent=root)), str(ex))
        threading.Thread(target=run, daemon=True).start()

    def modal(win, tries=0):
        """Keep the focus on a pop-up box. On some desktops (Wayland) the grab fails if the box isn't on
        screen yet, which used to stop the box from drawing - so try again a moment later instead."""
        try:
            win.grab_set()
        except tk.TclError:
            if tries < 20:
                win.after(100, lambda: modal(win, tries + 1) if win.winfo_exists() else None)

    def dialog(title, geometry=None):
        d = tk.Toplevel(root)
        d.title(title)
        d.configure(bg=P["bg"])
        d.transient(root)
        if geometry:
            w, h = (int(v) for v in geometry.split("x"))
            d.geometry(place(d, w, h, root))
        elif IS_WIN:                                   # natural size: just centre it over the window
            def centre():
                if d.winfo_exists():
                    d.update_idletasks()
                    w, h = d.winfo_reqwidth(), d.winfo_reqheight()
                    d.geometry("+%d+%d" % (root.winfo_rootx() + (root.winfo_width() - w) // 2,
                                           max(0, root.winfo_rooty() + (root.winfo_height() - h) // 2 - 15)))
            d.after_idle(centre)
        modal(d)
        return d

    def listbox(parent):
        return tk.Listbox(parent, font="TkDefaultFont", activestyle="none", bg=P["card"], fg=P["text"], highlightthickness=1,
                          highlightbackground=P["border"], highlightcolor=P["accent"], selectbackground=P["sel"],
                          selectforeground=P["text"], relief="flat", borderwidth=0)

    # ---------------- logos ----------------
    tile_png = shape_png(Logos.BOX[0], Logos.BOX[1], 6, P["logo_tile"])
    blank_tile = img(tile_png)
    logo_watchers = {}                                   # url -> [callbacks]

    def logo_ready(url):
        for cb in logo_watchers.pop(logo_url(url), []):
            try:
                cb()
            except Exception:
                pass
    logos = Logos(root, tile_png, logo_ready)

    def logo_or_wait(url, cb):
        """The logo image now, or the plain tile now and cb() once the logo has downloaded."""
        im = logos.get(url)
        if im is None and logo_url(url) and logo_url(url) not in logos.failed:
            logo_watchers.setdefault(logo_url(url), []).append(cb)
        return im or blank_tile

    # ---------------- little drawn pieces ----------------
    def icon(c, kind, col, s=20):
        """Simple line icons drawn on a canvas (work on every system, no icon fonts needed)."""
        w = 2
        m = s / 20.0
        if kind == "antenna":
            c.create_line(10*m, 7*m, 10*m, 18*m, fill=col, width=w)
            c.create_line(4*m, 2*m, 10*m, 8*m, 16*m, 2*m, fill=col, width=w)
            c.create_oval(8*m, 6*m, 12*m, 10*m, outline=col, width=w)
        elif kind == "satellite":
            c.create_arc(2*m, 4*m, 18*m, 20*m, start=200, extent=140, style="arc", outline=col, width=w)
            c.create_line(10*m, 12*m, 15*m, 5*m, fill=col, width=w)
            c.create_oval(14*m, 3*m, 17*m, 6*m, outline=col, width=w)
        elif kind in ("cable", "tv"):
            c.create_rectangle(2*m, 4*m, 18*m, 15*m, outline=col, width=w)
            c.create_line(7*m, 18*m, 13*m, 18*m, fill=col, width=w)
            if kind == "tv":
                c.create_line(7*m, 1*m, 10*m, 4*m, 13*m, 1*m, fill=col, width=w)
        elif kind == "home":
            c.create_line(2*m, 10*m, 10*m, 3*m, 18*m, 10*m, fill=col, width=w)
            c.create_line(5*m, 8*m, 5*m, 17*m, 15*m, 17*m, 15*m, 8*m, fill=col, width=w)
        elif kind == "providers":
            for y in (5, 10, 15):
                c.create_line(5*m, y*m, 18*m, y*m, fill=col, width=w)
                c.create_oval(1*m, (y-1)*m, 3*m, (y+1)*m, fill=col, outline=col)
        elif kind == "settings":
            for x, y in ((6, 6), (13, 10), (8, 14)):
                c.create_line(2*m, y*m, 18*m, y*m, fill=col, width=w)
                c.create_oval((x-2)*m, (y-2)*m, (x+2)*m, (y+2)*m, fill=P["side"], outline=col, width=w)
        elif kind == "build":
            c.create_polygon(6*m, 3*m, 17*m, 10*m, 6*m, 17*m, fill="", outline=col, width=w)
        elif kind == "share":
            for r in (3, 6, 9):
                c.create_arc((10-r)*m, (14-r)*m, (10+r)*m, (14+r)*m, start=45, extent=90, style="arc", outline=col, width=w)
            c.create_oval(9*m, 13*m, 11*m, 15*m, fill=col, outline=col)
        elif kind == "grid":
            c.create_rectangle(2*m, 3*m, 18*m, 17*m, outline=col, width=w)
            c.create_line(2*m, 8*m, 18*m, 8*m, fill=col, width=w)
            c.create_line(2*m, 12.5*m, 18*m, 12.5*m, fill=col, width=w)
            c.create_line(7*m, 3*m, 7*m, 17*m, fill=col, width=w)
        elif kind == "playlist":
            for y, x2 in ((5, 17), (10, 17), (15, 9)):
                c.create_line(2*m, y*m, x2*m, y*m, fill=col, width=w)
            c.create_polygon(12*m, 12*m, 18*m, 15.5*m, 12*m, 19*m, fill=col, outline=col)
        elif kind == "clock":
            c.create_oval(2*m, 2*m, 18*m, 18*m, outline=col, width=w)
            c.create_line(10*m, 10*m, 10*m, 5*m, fill=col, width=w)
            c.create_line(10*m, 10*m, 14*m, 12*m, fill=col, width=w)

    def toggle_switch(parent, on, command, bg):
        c = tk.Canvas(parent, width=44, height=24, bg=bg, highlightthickness=0, cursor="hand2")
        col = P["accent"] if on else P["off"]
        c.create_oval(1, 1, 23, 23, fill=col, outline=col)
        c.create_oval(21, 1, 43, 23, fill=col, outline=col)
        c.create_rectangle(12, 1, 32, 23, fill=col, outline=col)
        x = 22 if on else 3
        c.create_oval(x, 3, x + 19, 21, fill="#ffffff", outline="#ffffff")
        c.bind("<Button-1>", lambda e: command())
        c.is_switch = True
        return c

    def pill(parent, text, bg, fg):
        return tk.Label(parent, text=" %s " % text, bg=bg, fg=fg, font=F["small"], padx=8, pady=2)

    def rcard(parent, bg=None, border=None):
        """A card with softly rounded corners: drawn background + an inner frame for the content."""
        bg = bg or P["card"]
        border = border or P["border"]
        outer = tk.Frame(parent, bg=P["bg"])
        cv = tk.Canvas(outer, bg=P["bg"], highlightthickness=0, height=10)
        cv.place(x=0, y=0, relwidth=1, relheight=1)
        inner = tk.Frame(outer, bg=bg)
        inner.pack(fill="both", expand=True, padx=2, pady=2)

        def draw(e=None):
            cv.delete("all")
            w, h, r = outer.winfo_width(), outer.winfo_height(), 12
            if w < 30 or h < 30:
                return
            for (x0, y0, x1, y1) in ((0, 0, 2*r, 2*r), (w-2*r-1, 0, w-1, 2*r), (0, h-2*r-1, 2*r, h-1), (w-2*r-1, h-2*r-1, w-1, h-1)):
                cv.create_oval(x0, y0, x1, y1, fill=bg, outline=border)
            cv.create_rectangle(r, 0, w-r-1, h-1, fill=bg, outline="")
            cv.create_rectangle(0, r, w-1, h-r-1, fill=bg, outline="")
            cv.create_line(r, 0, w-r-1, 0, fill=border)
            cv.create_line(r, h-1, w-r-1, h-1, fill=border)
            cv.create_line(0, r, 0, h-r-1, fill=border)
            cv.create_line(w-1, r, w-1, h-r-1, fill=border)
        outer.bind("<Configure>", draw)
        outer.body = inner
        inner.configure(padx=10, pady=4)
        return outer

    class Scroll(tk.Frame):
        """A frame that scrolls (mouse wheel too)."""
        def __init__(self, parent, bg):
            super().__init__(parent, bg=bg)
            self.cv = tk.Canvas(self, bg=bg, highlightthickness=0)
            self.sb = ttk.Scrollbar(self, orient="vertical", command=self.cv.yview)
            self.inner = tk.Frame(self.cv, bg=bg)
            self.win = self.cv.create_window(0, 0, window=self.inner, anchor="nw")
            self.cv.configure(yscrollcommand=self.sb.set)
            self.cv.pack(side="left", fill="both", expand=True)
            self.sb.pack(side="left", fill="y")
            self.inner.bind("<Configure>", lambda e: self.cv.configure(scrollregion=self.cv.bbox("all")))
            self.cv.bind("<Configure>", lambda e: self.cv.itemconfigure(self.win, width=e.width))
            for ev in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
                self.cv.bind_all(ev, self.wheel, add="+")

        def wheel(self, e):
            w = e.widget
            try:
                while w is not None and w is not self:
                    w = w.master
            except Exception:
                return
            if w is None:
                return
            d = -1 if getattr(e, "num", None) == 4 else 1 if getattr(e, "num", None) == 5 else (-1 if e.delta > 0 else 1)
            self.cv.yview_scroll(d, "units")

    # ---------------- layout: sidebar + pages ----------------
    shell = tk.Frame(root, bg=P["bg"])
    shell.pack(fill="both", expand=True)
    side = tk.Frame(shell, bg=P["side"], width=side_width(p.get("text", 1.0)))
    side.pack(side="left", fill="y")
    side.pack_propagate(False)
    main = tk.Frame(shell, bg=P["bg"])
    main.pack(side="left", fill="both", expand=True)

    brand = tk.Frame(side, bg=P["side"])
    brand.pack(fill="x", padx=14, pady=(18, 16))
    bc = tk.Canvas(brand, width=34, height=34, bg=P["side"], highlightthickness=0)
    try:
        bimg = tk.PhotoImage(data="".join(ICON_PNG)).subsample(2, 2)
        bc.create_image(17, 17, image=bimg)
        keep.append(bimg)
    except Exception:
        icon(bc, "tv", "#33bfff", 30)
    bc.pack(side="left")
    if P["tech"]:
        bt = tk.Frame(brand, bg=P["side"])
        bt.pack(side="left", padx=8)
        b1 = tk.Frame(bt, bg=P["side"])
        b1.pack(anchor="w")
        tk.Label(b1, text="EPG", bg=P["side"], fg=P["side_text"], font=F["brand"], bd=0, padx=0, pady=0).pack(side="left")
        tk.Label(b1, text="Talk", bg=P["side"], fg=P["accent"], font=F["brand"], bd=0, padx=0, pady=0).pack(side="left")
        tk.Label(bt, text="Guide Builder", bg=P["side"], fg=P["side_text"], font=F["brand"], bd=0, padx=0, pady=0).pack(anchor="w")
    else:
        tk.Label(brand, text="EPGTalk\nGuide Builder", justify="left", bg=P["side"], fg=P["side_text"], font=F["brand"]).pack(side="left", padx=8)

    pages, navs = {}, {}
    current_page = [None]

    def show(key):
        for k, (fr, _) in pages.items():
            if k == key:
                fr.pack(fill="both", expand=True)
            else:
                fr.pack_forget()
        for k, (row, lbl, cv, kind) in navs.items():
            on = k == key
            bg = P["side_hi"] if on else P["side"]
            row.configure(bg=bg, highlightbackground=P["nav_ring"] if on else P["side"],
                          highlightcolor=P["nav_ring"] if on else P["side"])
            lbl.configure(bg=bg, fg=P["nav_on"] if on else P["side_muted"])
            cv.configure(bg=bg)
            cv.delete("all")
            icon(cv, kind, P["nav_icon_on"] if on else P["side_muted"])
        current_page[0] = key
        cb = pages[key][1]
        if cb:
            cb()

    def nav(key, text, kind):
        row = tk.Frame(side, bg=P["side"], cursor="hand2", highlightthickness=1 if P["tech"] else 0,
                       highlightbackground=P["side"], highlightcolor=P["side"])
        row.pack(fill="x", padx=10, pady=2)
        cv = tk.Canvas(row, width=20, height=20, bg=P["side"], highlightthickness=0)
        cv.pack(side="left", padx=(10, 10), pady=9)
        lbl = tk.Label(row, text=text, bg=P["side"], fg=P["side_muted"], font=F["nav"], anchor="w")
        lbl.pack(side="left", fill="x", expand=True)
        for w in (row, cv, lbl):
            w.bind("<Button-1>", lambda e, k=key: show(k))
        navs[key] = (row, lbl, cv, kind)

    def page(key, title, sub, on_show=None, scroll=False):
        fr = tk.Frame(main, bg=P["bg"])
        head = tk.Frame(fr, bg=P["bg"])
        head.pack(fill="x", padx=28, pady=(22, 4))
        tl = tk.Label(head, text=title, bg=P["bg"], fg=P["text"], font=F["title"])
        tl.pack(side="left")
        actions = tk.Frame(head, bg=P["bg"])
        actions.pack(side="right")
        sl = None
        if sub:
            sl = tk.Label(fr, text=sub, bg=P["bg"], fg=P["muted"], font=F["mid"], anchor="w", justify="left", wraplength=780)
            sl.pack(fill="x", padx=28, pady=(0, 14))
        if scroll:
            sc = Scroll(fr, P["bg"])
            sc.pack(fill="both", expand=True, padx=(28, 6), pady=(0, 18))
            body = sc.inner
        else:
            body = tk.Frame(fr, bg=P["bg"])
            body.pack(fill="both", expand=True, padx=28, pady=(0, 18))
        pages[key] = (fr, on_show)
        fr.title_lbl, fr.sub_lbl = tl, sl
        return body, actions

    for key, text, kind in (("home", T("Home"), "home"), ("prov", T("Providers"), "providers"),
                            ("build", T("Build guide"), "build"), ("list", T("Your playlist"), "playlist"),
                            ("guide", T("TV guide"), "grid"), ("now", T("What's on now"), "tv"),
                            ("share", T("Use on your TV"), "share"), ("daily", T("Daily update"), "clock"),
                            ("set", T("Settings"), "settings")):
        nav(key, text, kind)

    tk.Frame(side, bg=P["side"]).pack(fill="both", expand=True)
    upd_box = tk.Frame(side, bg=P["accent"], cursor="hand2")
    upd_lbl = tk.Label(upd_box, text="", bg=P["accent"], fg=P["on_accent"], font=F["small"], justify="left", anchor="w", cursor="hand2")
    upd_lbl.pack(fill="x", padx=10, pady=6)
    sbox = tk.Frame(side, bg=P["side_hi"], cursor="hand2")
    sbox.pack(fill="x", padx=12, pady=(0, 8))
    s_dot = tk.Label(sbox, text="", bg=P["side_hi"], fg=P["side_muted"], font=F["small"], anchor="w")
    s_dot.pack(fill="x", padx=10, pady=(8, 0))
    s_info = tk.Label(sbox, text="", bg=P["side_hi"], fg=P["side_muted"], font=F["small"], anchor="w", justify="left")
    s_info.pack(fill="x", padx=10, pady=(0, 8))
    for w in (sbox, s_dot, s_info):
        w.bind("<Button-1>", lambda e: show("home"))
    cred = tk.Label(side, text="%s\nEPGTalk.com  ·  v%s" % (T("made by aCiDjEsUs"), VERSION), bg=P["side"], fg=P["side_dim"],
                    font=F["small"], justify="left", anchor="w", cursor="hand2")
    cred.pack(fill="x", padx=16, pady=(0, 14))
    cred.bind("<Button-1>", lambda e: webbrowser.open("https://epgtalk.com"))

    # ---------------- status (always checks the real guide file) ----------------
    def guide_exists():
        return os.path.exists(out_path(p))

    def state():
        """'none' / 'changed' / 'ready' / 'failed' (last automatic update failed)."""
        la = p.get("last_auto") or {}
        if la and not la.get("ok") and not la.get("seen"):
            return "failed"
        if not p.get("last_build") or not guide_exists():
            return "none"
        return "changed" if p.get("changed") else "ready"

    def side_status():
        s = state()
        lb = p.get("last_build") or {}
        when = lb.get("when", "")
        if s == "failed":
            s_dot.configure(text="● " + T("Automatic update failed"), fg="#ff7b72")
            s_info.configure(text=T("Open Home for details"))
        elif s == "none":
            s_dot.configure(text="● " + T("No guide yet"), fg=P["side_muted"])
            s_info.configure(text=T("Press “Build guide”") if p["lineups"] else T("Add a provider, then build"))
        elif s == "changed":
            s_dot.configure(text="● " + T("Changes not built yet"), fg="#ffb547")
            s_info.configure(text=T("Last built %s") % nice_when(when, p))
        else:
            s_dot.configure(text="● " + T("Guide ready"), fg="#4fd18b")
            s_info.configure(text=T("Built %s\n%s channels") % (nice_when(when, p), lb.get("channels")))

    def mark_changed():
        """Providers, channels or settings changed: the guide needs building again."""
        p["changed"] = True
        p["change_n"] = int(p.get("change_n", 0)) + 1       # (a build that already started doesn't include this)
        save_profile(p)
        side_status()

    # ---------------- menu ----------------
    menu = tk.Menu(root)
    m_file = tk.Menu(menu, tearoff=False)
    m_file.add_command(label=T("Open my guide folder"), command=lambda: (os.makedirs(os.path.dirname(out_path(p)), exist_ok=True),
                                                                          open_path(os.path.dirname(out_path(p)))))
    m_file.add_command(label=T("Open the settings folder"), command=lambda: open_path(DATA))
    m_file.add_command(label=T("Open the log"), command=lambda: open_path(LOGFILE) if os.path.exists(LOGFILE) else None)
    m_file.add_separator()
    m_file.add_command(label=T("Back up my settings…"), command=lambda: do_backup())
    m_file.add_command(label=T("Restore settings from a backup…"), command=lambda: do_restore())
    if not INSTALLED:
        m_file.add_command(label=T("Add to my apps menu"), command=lambda: add_shortcut())
    m_file.add_separator()
    m_file.add_command(label=T("Quit"), command=lambda: on_close())
    menu.add_cascade(label=T("File"), menu=m_file)
    m_view = tk.Menu(menu, tearoff=False)
    tsize = tk.DoubleVar(value=float(p.get("text", 1.0)))
    for lbl, v in ((T("Normal text"), 1.0), (T("Large text"), 1.25), (T("Extra large text"), 1.5)):
        m_view.add_radiobutton(label=lbl, variable=tsize, value=v, command=lambda v=v: set_text(v))
    m_view.add_separator()
    themev = tk.StringVar(value=p.get("theme", "light"))
    langv = tk.StringVar(value=p.get("lang", "en"))

    def restart_with(key, val):
        if p.get(key, {"theme": "light", "lang": "en"}.get(key)) == val:
            return
        p[key] = val
        save_profile(p)
        result["restart"] = True
        if key == "lang":
            result["tray_too"] = True
        on_close()
    m_view.add_radiobutton(label=T("Light look"), variable=themev, value="light", command=lambda: restart_with("theme", "light"))
    m_view.add_radiobutton(label=T("Dark look"), variable=themev, value="dark", command=lambda: restart_with("theme", "dark"))
    m_view.add_separator()
    m_view.add_radiobutton(label="English", variable=langv, value="en", command=lambda: restart_with("lang", "en"))
    m_view.add_radiobutton(label="Español", variable=langv, value="es", command=lambda: restart_with("lang", "es"))
    menu.add_cascade(label=T("View"), menu=m_view)
    m_help = tk.Menu(menu, tearoff=False)

    def guide_page():
        es = here("APP-GUIDE-es.html")
        return es if LANG == "es" and os.path.exists(es) else \
            here("APP-GUIDE.html") if os.path.exists(here("APP-GUIDE.html")) else here("GUIDE.html")
    m_help.add_command(label=T("How to use (step by step)"), command=lambda: open_in_browser(guide_page()))
    m_help.add_command(label=T("Set it up in your app (Plex, TiviMate, xTeVe…)"), command=lambda: webbrowser.open(SETUP_URL))
    m_help.add_command(label=T("Run it 24/7 on your NAS…"), command=lambda: move_to_nas())
    if os.path.exists(here("GUIDE.html")) and not INSTALLED:
        m_help.add_command(label=T("mc2xml and install guide"), command=lambda: open_in_browser(here("GUIDE.html")))
    m_help.add_command(label="EPGTalk.com", command=lambda: webbrowser.open("https://epgtalk.com"))
    m_help.add_separator()
    m_help.add_command(label=T("About"), command=lambda: messagebox.showinfo(
        APP, "%s %s\n\n%s\n%s\n\n%s\n%s\n\n%s" % (
            APP, VERSION, T("Made by aCiDjEsUs, a Hamtramck kid · EPGTalk.com"), T("Free, for the community."),
            T("Builds your own XMLTV guide with mc2xml (EPGTalk edition)."),
            T("Listings: Gracenote (free) or your Schedules Direct account."),
            T("Shortcuts: Ctrl+B build · F5 refresh")), parent=root))
    menu.add_cascade(label=T("Help"), menu=m_help)
    root.config(menu=menu)

    def add_shortcut():
        work(add_app_shortcut, lambda m: messagebox.showinfo(APP, T(m), parent=root),
             lambda m: messagebox.showerror(APP, T("Could not add the shortcut:") + "\n\n" + m, parent=root))

    def do_backup():
        f = filedialog.asksaveasfilename(parent=root, title=T("Back up my settings"), defaultextension=".zip",
                                         initialfile="EPGTalk-Builder-backup-%s.zip" % dt.date.today().isoformat(),
                                         filetypes=[(T("Backup"), "*.zip")])
        if not f:
            return
        with_login = has_login() and messagebox.askyesno(
            APP, T("Also include your Schedules Direct login?\n\nOnly say yes if you keep this backup file private."), parent=root)
        try:
            backup_settings(f, with_login)
            flash(T("Backup saved: %s") % os.path.basename(f))
        except Exception as ex:
            messagebox.showerror(APP, T("Could not save the backup:") + "\n\n%s" % ex, parent=root)

    def do_restore():
        f = filedialog.askopenfilename(parent=root, title=T("Restore settings from a backup"), filetypes=[(T("Backup"), "*.zip")])
        if not f:
            return
        if not messagebox.askyesno(APP, T("Replace your current providers, channels and settings with this backup?\n\n"
                                          "A copy of your current setup is saved first, just in case."), parent=root):
            return
        try:
            safety = restore_settings(f)
        except Exception as ex:
            messagebox.showerror(APP, T("Could not restore:") + "\n\n%s" % ex, parent=root)
            return
        messagebox.showinfo(APP, T("Restored. The app opens again with your restored setup.\n\n"
                                   "Your previous setup was saved as:\n%s") % safety, parent=root)
        result["restart"] = True
        on_close(save=False)

    def card(parent, bg=None, border=None):
        c = rcard(parent, bg, border)
        return c

    def autowrap(lbl, pad=18):
        """Wrap a label's text to the width of the frame it sits in. Measured on the frame (the label's own
        size changes with wrapping, which would loop forever); one hook per frame, dead labels are skipped."""
        m = lbl.master
        if not hasattr(m, "_wrapped"):
            m._wrapped = []

            def fit(e=None, m=m):
                w = m.winfo_width() - pad
                if w <= 60:
                    return
                alive = []
                for l in m._wrapped:
                    try:
                        if not l.winfo_exists():
                            continue
                        if abs(int(float(l.cget("wraplength") or 0)) - w) > 3:
                            l.configure(wraplength=w)
                        alive.append(l)
                    except (tk.TclError, ValueError):
                        pass
                m._wrapped = alive
            m.bind("<Configure>", fit, add="+")
        m._wrapped.append(lbl)
        mw = m.winfo_width()
        lbl.configure(wraplength=(mw - pad) if mw > 80 else 300)
        return lbl

    # ====================================================================== #
    # Home
    # ====================================================================== #
    hbody, _ = page("home", "", None, lambda: home_refresh(), scroll=True)
    pages["home"][0].title_lbl.pack_forget()
    hrow = tk.Frame(hbody, bg=P["bg"])
    hrow.pack(fill="x", pady=(0, 2))
    hello = tk.Label(hrow, text="", bg=P["bg"], fg=P["text"], font=F["hello"], anchor="w")
    hello.pack(side="left")
    live = tk.Label(hrow, text="", bg=P["bg"], fg=P["accent"], font=F["mono"])
    if P["tech"]:
        live.pack(side="right", padx=(0, 14))
    tk.Label(hbody, text=T("Everything about your guide, at a glance."), bg=P["bg"], fg=P["muted"], font=F["mid"],
             anchor="w").pack(fill="x", pady=(0, 14))
    h_notices = tk.Frame(hbody, bg=P["bg"])
    h_notices.pack(fill="x")
    h_top = tk.Frame(hbody, bg=P["bg"])
    h_top.pack(fill="x")
    h_top.grid_columnconfigure(0, weight=13, uniform="h")
    h_top.grid_columnconfigure(1, weight=10, uniform="h")
    h_stat = card(h_top)
    h_stat.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
    h_tv = card(h_top)
    h_tv.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
    h_now = card(hbody)
    h_now.pack(fill="x", pady=(12, 0))

    def notice(parent, kind, title, text, buttons):
        bg, fg = {"err": (P["err_soft"], P["err"]), "warn": (P["warn_soft"], P["warn"]), "info": (P["accent_soft"], P["accent_text"])}[kind]
        c = card(parent, bg, fg)
        c.pack(fill="x", pady=(0, 12))
        b = c.body
        b.configure(bg=bg)
        tk.Label(b, text=title, bg=bg, fg=fg, font=F["h"], anchor="w", justify="left", wraplength=760).pack(fill="x", padx=6, pady=(8, 2))
        if text:
            tk.Label(b, text=text, bg=bg, fg=P["text"], font=F["mid"], anchor="w", justify="left", wraplength=760).pack(fill="x", padx=6)
        r = tk.Frame(b, bg=bg)
        r.pack(fill="x", padx=6, pady=(8, 10))
        for txt, cmd, sty in buttons:
            ttk.Button(r, text=txt, command=cmd, style=sty).pack(side="left", padx=(0, 8))
        return c

    home_key = [None]

    def home_lines():
        s, lb = state(), p.get("last_build") or {}
        lines = []
        if lb and guide_exists():
            lines.append(T("Built %s · %s channels · %s shows") % (nice_when(lb.get("when", ""), p), lb.get("channels"),
                                                                             "{:,}".format(lb.get("programs", 0))))
        elif not p["lineups"]:
            lines.append(T("Start by adding your TV provider."))
        else:
            lines.append(T("Press “Build my guide” to make your guide file."))
        if s == "changed":
            lines.append(T("You changed providers, channels or settings since then."))
        sch = sched_cache[0]
        if sch:
            hh, mm = [int(x) for x in sch.split(":")] if ":" in sch else (4, 30)
            nxt = dt.datetime.combine(dt.date.today(), dt.time(hh, mm))
            when = T("today") if nxt > dt.datetime.now() else T("tomorrow")
            lines.append(T("Next automatic update: %s %s") % (when, clock(nxt, p)))
        else:
            lines.append(T("Automatic daily update: off"))
        return s, lines, sch

    def home_refresh():
        h = dt.datetime.now().hour
        hi = T("Good morning") if h < 12 else T("Good afternoon") if h < 18 else T("Good evening")
        s, lines, sch = home_lines()
        la = p.get("last_auto") or {}
        key = json.dumps([hi, s, lines, bool(sch), bool(p["lineups"]), guide_exists(), la, update_info[0], p.get("update_skip"),
                          share_url() if server.httpd else ""], sort_keys=True, default=str)
        if key == home_key[0]:
            home_now()                                  # cards unchanged - just check the On now list
            return
        home_key[0] = key
        hello.configure(text=hi)
        for w in h_notices.winfo_children():
            w.destroy()
        if la and not la.get("seen") and (not la.get("ok") or la.get("failed") or la.get("stale")):
            def seen():
                la["seen"] = True
                p["last_auto"] = la
                save_profile(p)
                home_refresh()
                side_status()
            if not la.get("ok"):
                notice(h_notices, "err", "⚠  " + T("The automatic update %s didn't finish") % nice_when(la.get("when", ""), p),
                       T("Reason: %s") % (la.get("error") or ", ".join(la.get("failed") or []) or T("see the log")),
                       [(T("Build now"), lambda: (seen(), start_build()), "Accent.TButton"),
                        (T("Open the log"), lambda: open_path(LOGFILE), "TButton"), (T("Dismiss"), seen, "TButton")])
            else:
                notice(h_notices, "warn", "⚠  " + T("The automatic update %s left something out") % nice_when(la.get("when", ""), p),
                       " ".join(x for x in (
                           (T("Not included: %s. The rest of your guide was updated.") % ", ".join(la["failed"])) if la.get("failed") else "",
                           (T("Today's update didn't work for %s, so their last good listings are in your guide.") %
                            ", ".join(la["stale"])) if la.get("stale") else "") if x),
                       [(T("Build now"), lambda: (seen(), start_build()), "Accent.TButton"),
                        (T("Open the log"), lambda: open_path(LOGFILE), "TButton"), (T("Dismiss"), seen, "TButton")])
        up = update_info[0]
        if up and p.get("update_skip") != up.get("version"):
            def skip():
                p["update_skip"] = up.get("version")
                save_profile(p)
                home_refresh()
                update_badge()
            page_ = lambda: webbrowser.open(up.get("page") or "https://epgtalk.com")
            notice(h_notices, "info", "✨  " + T("New version %s is available") % up.get("version"),
                   up.get("notes_es" if LANG == "es" else "notes") or T("Updates bring fixes and new features."),
                   [(T("Update now"), lambda: update_now(up), "Accent.TButton"), (T("What's new"), page_, "TButton"),
                    (T("Later"), skip, "TButton")] if update_plan(up) else
                   [(T("Download"), page_, "Accent.TButton"), (T("Later"), skip, "TButton")])
        # status card
        b = h_stat.body
        for w in b.winfo_children():
            w.destroy()
        icon_t, col, head = {"ready": ("✔", P["ok"], T("Your guide is ready")),
                             "changed": ("⚠", P["warn"], T("Changes not built yet")),
                             "failed": ("⚠", P["err"], T("The last automatic update failed")),
                             "none": ("○", P["muted"], T("No guide yet"))}[s]
        if P["tech"]:
            g = tk.Frame(b, bg=P["card"])
            g.pack(fill="x", padx=6, pady=(10, 6))
            lbx = p.get("last_build") or {}
            nx = "—"
            if sch:
                hh, mm = [int(x) for x in sch.split(":")] if ":" in sch else (4, 30)
                nx = clock(dt.datetime.combine(dt.date.today(), dt.time(hh, mm)), p)
            word = {"ready": T("Ready"), "changed": T("Not built"), "failed": T("Failed"), "none": T("No guide")}[s]
            for c_, (cap, val, fg_, fnt) in enumerate(((T("STATUS"), word, col, F["h"]),
                                                      (T("CHANNELS"), str(lbx.get("channels") or "—") if guide_exists() else "—", P["text"], F["mono_big"]),
                                                      (T("NEXT UPDATE"), nx if sch else T("Off"), P["text"], F["mono_big"]))):
                g.grid_columnconfigure(c_, weight=1, uniform="st")
                tk.Label(g, text=cap, bg=P["card"], fg=P["muted"], font=F["tiny"], anchor="w").grid(row=0, column=c_, sticky="w")
                tk.Label(g, text=val, bg=P["card"], fg=fg_, font=fnt, anchor="w").grid(row=1, column=c_, sticky="w")
            autowrap(tk.Label(b, text="\n".join(lines[:2] if s != "changed" else lines[1:2]), bg=P["card"], fg=P["muted"],
                              font=F["small"], anchor="w", justify="left")).pack(fill="x", padx=6)
        else:
            tk.Label(b, text="%s  %s" % (icon_t, head), bg=P["card"], fg=col, font=F["status"], anchor="w").pack(fill="x", padx=6, pady=(10, 4))
            autowrap(tk.Label(b, text="\n".join(lines), bg=P["card"], fg=P["muted"], font=F["mid"], anchor="w",
                              justify="left")).pack(fill="x", padx=6)
        r = tk.Frame(b, bg=P["card"])
        r.pack(fill="x", padx=6, pady=(12, 4))
        r2 = tk.Frame(b, bg=P["card"])
        r2.pack(fill="x", padx=6, pady=(0, 10))
        if not p["lineups"]:
            ttk.Button(r, text="+  " + T("Add a provider"), style="Accent.TButton", command=lambda: (show("prov"), add_provider())).pack(side="left")
        else:
            ttk.Button(r, text="▶  " + (T("Build again") if s == "ready" else T("Build my guide")), style="Accent.TButton",
                       command=start_build).pack(side="left")
            if guide_exists():
                ttk.Button(r, text=T("Open folder"), command=lambda: open_path(os.path.dirname(out_path(p)))).pack(side="left", padx=8)
            if not sch:
                ttk.Button(r2, text=T("Turn on daily update"), style="Chip.TButton", command=lambda: show("daily")).pack(side="left")
        # TV card
        b = h_tv.body
        for w in b.winfo_children():
            w.destroy()
        if server.httpd:
            tk.Label(b, text=T("Your TV box loads it from"), bg=P["card"], fg=P["muted"], font=F["small"], anchor="w").pack(fill="x", padx=6, pady=(12, 2))
            u = share_url()
            autowrap(tk.Label(b, text=u, bg=P["card"], fg=P["accent"], font=F["bold"], anchor="w", justify="left")).pack(fill="x", padx=6)
            r = tk.Frame(b, bg=P["card"])
            r.pack(fill="x", padx=6, pady=(10, 12))
            ttk.Button(r, text=T("Copy"), command=lambda: copy_text(u)).pack(side="left")
            tk.Label(r, text="● " + T("Sharing on"), bg=P["card"], fg=P["ok"], font=F["small"]).pack(side="left", padx=10)
        else:
            tk.Label(b, text=T("Use it on your TV"), bg=P["card"], fg=P["text"], font=F["h"], anchor="w").pack(fill="x", padx=6, pady=(12, 2))
            autowrap(tk.Label(b, text=T("Let your TV box load the guide straight from this computer — no copying files."),
                              bg=P["card"], fg=P["muted"], font=F["mid"], anchor="w", justify="left")).pack(fill="x", padx=6)
            ttk.Button(b, text=T("Turn on sharing"), command=lambda: (share_toggle(), home_refresh())).pack(anchor="w", padx=6, pady=(10, 12))
        # on now
        home_now()

    now_box = {"holder": None, "key": None, "bars": []}   # the On now list stays on screen; redrawn only when a show changes

    def bar_draw(cv, a, z):
        try:
            frac = (dt.datetime.now(dt.timezone.utc) - a).total_seconds() / max(60.0, (z - a).total_seconds())
        except Exception:
            frac = 0
        cv.delete("all")
        w = int(cv.cget("width"))
        cv.create_rectangle(0, 0, w, 4, fill=P["border"], outline="")
        cv.create_rectangle(0, 0, max(2, int(w * min(1.0, max(0.0, frac)))), 4, fill=P["accent"], outline="")

    def home_tick():
        """Every 30 s: the clock, the show bars, and a fresh list once a show has ended."""
        try:
            if P["tech"]:
                live.configure(text="● " + T("LIVE") + "  " + clock(dt.datetime.now(), p))
            now = dt.datetime.now(dt.timezone.utc)
            ended = False
            for cv, a, z in now_box["bars"]:
                if cv.winfo_exists():
                    bar_draw(cv, a, z)
                    ended = ended or (z is not None and z <= now)
            if ended and current_page[0] == "home":
                home_now()
        except Exception:
            pass
        root.after(30000, home_tick)
    root.after(1500, home_tick)

    def home_now():
        b = h_now.body
        holder = now_box["holder"]
        if not guide_exists() or holder is None or not holder.winfo_exists():
            now_box["holder"] = now_box["key"] = holder = None
            for w in b.winfo_children():
                w.destroy()
            top = tk.Frame(b, bg=P["card"])
            top.pack(fill="x", padx=6, pady=(10, 4))
            tk.Label(top, text=T("On now"), bg=P["card"], fg=P["text"], font=F["h"]).pack(side="left")
            ttk.Button(top, text=T("See all"), style="Chip.TButton", command=lambda: show("now")).pack(side="right")
            if not guide_exists():
                tk.Label(b, text=T("Your channels show up here once your guide is built."), bg=P["card"], fg=P["muted"],
                         font=F["mid"], anchor="w").pack(fill="x", padx=6, pady=(4, 14))
                return
            holder = now_box["holder"] = tk.Frame(b, bg=P["card"])
            holder.pack(fill="x", padx=6, pady=(0, 10))
            tk.Label(holder, text=T("Reading your guide…"), bg=P["card"], fg=P["muted"], font=F["mid"]).pack(anchor="w")

        def done(res):
            rows, _ = res
            if not holder.winfo_exists():
                return
            key = [(r[0], r[1], r[2], r[5], clock(r[6].astimezone(), p) if r[5] else "") for r in rows[:7]] + [len(rows)]
            if key == now_box["key"]:
                return                                  # nothing changed - keep what's on screen
            now_box["key"] = key
            now_box["bars"] = []
            for w in holder.winfo_children():
                w.destroy()
            holder.grid_columnconfigure(2, weight=3)
            holder.grid_columnconfigure(3, weight=2)
            for i, (name, logo, title, a, z, ntitle, na) in enumerate(rows[:7]):
                if i:
                    tk.Frame(holder, bg=P["border"], height=1).grid(row=2 * i - 1, column=0, columnspan=5, sticky="ew")
                lab = tk.Label(holder, bg=P["card"])
                lab.grid(row=2 * i, column=0, pady=3, sticky="w")

                def setimg(lab=lab, logo=logo):
                    if lab.winfo_exists():
                        lab.configure(image=logo_or_wait(logo, lambda: setimg(lab, logo)))
                setimg()
                tk.Label(holder, text=name, bg=P["card"], fg=P["muted"], font=F["mid"], width=18, anchor="w").grid(
                    row=2 * i, column=1, sticky="w", padx=(10, 6))
                tk.Label(holder, text=title or "—", bg=P["card"], fg=P["text"] if title else P["muted"], font=F["bold"],
                         anchor="w", width=1).grid(row=2 * i, column=2, sticky="ew", padx=(0, 10))
                tk.Label(holder, text=("%s  %s" % (clock(na.astimezone(), p), ntitle)) if ntitle else "", bg=P["card"],
                         fg=P["muted"], font=F["small"], anchor="w", width=1).grid(row=2 * i, column=3, sticky="ew")
                if a is not None and z is not None:
                    bcv = tk.Canvas(holder, width=56, height=4, bg=P["card"], highlightthickness=0)
                    bcv.grid(row=2 * i, column=4, padx=(10, 2))
                    bar_draw(bcv, a, z)
                    now_box["bars"].append((bcv, a, z))
            if len(rows) > 7:
                tk.Label(holder, text=T("… and %d more channels") % (len(rows) - 7), bg=P["card"], fg=P["muted"],
                         font=F["small"], anchor="w").grid(row=99, column=0, columnspan=5, sticky="w", pady=(6, 0))
        root.after(0 if root.winfo_viewable() else 700, lambda: work(lambda: on_now(out_path(p)), done, lambda m: None))

    # ====================================================================== #
    # Providers
    # ====================================================================== #
    pbody, pact = page("prov", T("Your TV providers"), T("Their channels are combined into one guide, top to bottom."),
                       lambda: refresh_lineups())
    ttk.Button(pact, text=T("Import old mc2xml files"), command=lambda: import_old()).pack(side="left", padx=(0, 8))
    ttk.Button(pact, text="+  " + T("Add a provider"), style="Accent.TButton", command=lambda: add_provider()).pack(side="left")
    plist = Scroll(pbody, P["bg"])
    plist.pack(fill="both", expand=True)

    def new_id():
        n = int(p.get("next_id", 1))
        while os.path.exists(data("lineup%d.dat" % n)):
            n += 1
        p["next_id"] = n + 1
        return "lineup%d" % n

    tile_imgs = {}
    work(lambda: {c: shape_png(42, 42, 10, c) for c in (P["accent_soft"], P["tile_sd"], P["tile_off"])},   # drawn in the background
         lambda d: [tile_imgs.setdefault(c, img(b)) for c, b in d.items()], lambda m: None)

    def refresh_lineups(select=None):
        for w in plist.inner.winfo_children():
            w.destroy()
        if not p["lineups"]:
            c = card(plist.inner)
            c.pack(fill="x", pady=(4, 0), padx=(0, 6))
            inner = tk.Frame(c.body, bg=P["card"])
            inner.pack(padx=30, pady=30)
            cv = tk.Canvas(inner, width=48, height=48, bg=P["card"], highlightthickness=0)
            icon(cv, "tv", P["accent"], 46)
            cv.pack()
            tk.Label(inner, text=T("Add your first TV provider"), bg=P["card"], fg=P["text"], font=F["h"]).pack(pady=(10, 4))
            tk.Label(inner, text=T("Type your zip code and pick your cable, satellite or antenna lineup.\n"
                                   "Used mc2xml before? Import your old .dat / .chl / .ren files instead."),
                     bg=P["card"], fg=P["muted"], font=F["mid"], justify="center").pack()
            b = tk.Frame(inner, bg=P["card"])
            b.pack(pady=(14, 0))
            ttk.Button(b, text="+  " + T("Add a provider"), style="Accent.TButton", command=lambda: add_provider()).pack(side="left", padx=4)
            ttk.Button(b, text=T("Import old mc2xml files"), command=lambda: import_old()).pack(side="left", padx=4)
            side_status()
            return
        n = len(p["lineups"])
        for idx, it in enumerate(p["lineups"]):
            on = it.get("enabled", True)
            c = card(plist.inner)
            c.pack(fill="x", pady=(0, 10), padx=(0, 6))
            row = tk.Frame(c.body, bg=P["card"])
            row.pack(fill="x", padx=8, pady=10)
            name = it.get("name", "")
            kind = "satellite" if it["source"] == "sd" or "satellite" in name.lower() else \
                   "antenna" if "over the air" in name.lower() or "antenna" in name.lower() else "cable"
            tbg = (P["tile_sd"] if kind == "satellite" else P["accent_soft"]) if on else P["tile_off"]
            tfg = (P["tile_sd_fg"] if kind == "satellite" else P["accent"]) if on else P["off_text"]
            if tbg not in tile_imgs:                     # drawn once per colour, not on every visit
                tile_imgs[tbg] = img(shape_png(42, 42, 10, tbg))
            tile = tk.Label(row, image=tile_imgs[tbg], bg=P["card"])
            tile.pack(side="left")
            ic = tk.Canvas(row, width=22, height=22, bg=tbg, highlightthickness=0)
            icon(ic, kind, tfg, 22)
            ic.place(in_=tile, relx=0.5, rely=0.5, anchor="center")
            txt = tk.Frame(row, bg=P["card"])
            txt.pack(side="left", fill="x", expand=True, padx=12)
            tk.Label(txt, text=name, bg=P["card"], fg=P["text"] if on else P["off_text"], font=F["h"], anchor="w").pack(fill="x")
            src = T("free listings") if it["source"] == "gracenote" else "Schedules Direct"
            where = ("%s %s" % (it.get("country", "").upper(), it.get("postal", ""))).strip()
            sub = ("%s · %s" % (where, src)) if on else T("Switched off · not in the guide")
            tk.Label(txt, text=sub, bg=P["card"], fg=P["muted"] if on else P["off_text"], font=F["mid"], anchor="w").pack(fill="x")
            dat, chl, ren = lineup_files(it["id"])
            cnt = count_lines(chl)
            pill(row, T("all channels") if cnt is None else (T("%d channel") if cnt == 1 else T("%d channels")) % cnt,
                 P["accent_soft"] if on else P["tile_off"], P["accent_text"] if on else P["muted"]).pack(side="left", padx=(0, 10))
            ttk.Button(row, text=T("Channels"), command=lambda it=it: edit_channels(it)).pack(side="left", padx=(0, 6))
            mb = ttk.Button(row, text="⋮", width=2, style="Chip.TButton")
            mb.pack(side="left", padx=(0, 10))

            def more(e=None, it=it, mb=mb, idx=idx):
                m = tk.Menu(root, tearoff=False)
                m.add_command(label=T("Channels…"), command=lambda: edit_channels(it))
                m.add_command(label=T("Edit name / zip code…"), command=lambda: edit_provider(it))
                if idx > 0:
                    m.add_command(label=T("Move up"), command=lambda: move(it, -1))
                if idx < n - 1:
                    m.add_command(label=T("Move down"), command=lambda: move(it, 1))
                m.add_separator()
                m.add_command(label=T("Remove…"), command=lambda: remove_provider(it))
                m.tk_popup(mb.winfo_rootx(), mb.winfo_rooty() + mb.winfo_height())
            mb.configure(command=more)

            def flip(it=it):
                it["enabled"] = not it.get("enabled", True)
                mark_changed()
                refresh_lineups()
            toggle_switch(row, on, flip, P["card"]).pack(side="left")
            for w in (c.body, row, txt):
                w.bind("<Double-1>", lambda e, it=it: edit_channels(it))
        side_status()

    def pick_dialog(title, intro, options):
        d = dialog(title, "680x500")
        res = [None]
        ttk.Label(d, text=intro, wraplength=640, padding=16).pack(anchor="w")
        lf = ttk.Frame(d, padding=(16, 0))
        lf.pack(fill="both", expand=True)
        lb = listbox(lf)
        for lbl, _ in options:
            lb.insert("end", "  " + lbl)
        s2 = ttk.Scrollbar(lf, command=lb.yview)
        lb.configure(yscrollcommand=s2.set)
        lb.pack(side="left", fill="both", expand=True)
        s2.pack(side="left", fill="y")

        def ok(*_):
            if lb.curselection():
                res[0] = options[lb.curselection()[0]][1]
                d.destroy()
        lb.bind("<Double-1>", ok)
        bf = ttk.Frame(d, padding=16)
        bf.pack(fill="x", side="bottom", before=lf)          # buttons keep their room on small screens
        ttk.Button(bf, text=T("Choose"), style="Accent.TButton", command=ok).pack(side="right")
        ttk.Button(bf, text=T("Cancel"), command=d.destroy).pack(side="right", padx=8)
        d.wait_window()
        return res[0]

    def pick_in_thread(title, intro, options):
        box, ev = [None], threading.Event()

        def go():
            box[0] = pick_dialog(title, intro, options)
            ev.set()
        ui(go)
        ev.wait()
        return box[0]

    def ask_in_thread(text):
        box, ev = [False], threading.Event()

        def go():
            box[0] = messagebox.askyesno(APP, text, parent=root)
            ev.set()
        ui(go)
        ev.wait()
        return box[0]

    def add_provider():
        d = dialog(T("Add a TV provider"), "760x640")
        frm = ttk.Frame(d, padding=20)
        frm.pack(fill="both", expand=True)
        src = tk.StringVar(value="gracenote")
        ttk.Label(frm, text=T("Where should the listings come from?"), font=F["h"]).pack(anchor="w")
        ttk.Radiobutton(frm, text=T("Free listings (Gracenote) — United States, Canada, Mexico"), variable=src, value="gracenote",
                        command=lambda: set_src()).pack(anchor="w", pady=(8, 2))
        ttk.Radiobutton(frm, text=T("My Schedules Direct account (paid, more countries)"), variable=src, value="sd",
                        command=lambda: set_src()).pack(anchor="w")
        row = ttk.Frame(frm)
        row.pack(fill="x", pady=(16, 4))
        ttk.Label(row, text=T("Country")).pack(side="left")
        country = ttk.Combobox(row, state="readonly", width=20)
        country.pack(side="left", padx=(6, 16))
        ttk.Label(row, text=T("Zip / postal code")).pack(side="left")
        postal = ttk.Entry(row, width=12)
        postal.pack(side="left", padx=6)
        findb = ttk.Button(row, text=T("Find providers"), style="Accent.TButton")
        findb.pack(side="left", padx=(10, 0))
        note = ttk.Label(frm, style="Muted.TLabel", wraplength=700, justify="left")
        note.pack(anchor="w", pady=(8, 10))
        lf = ttk.Frame(frm)
        lf.pack(fill="both", expand=True)
        lb = listbox(lf)
        s2 = ttk.Scrollbar(lf, command=lb.yview)
        lb.configure(yscrollcommand=s2.set)
        lb.pack(side="left", fill="both", expand=True)
        s2.pack(side="left", fill="y")
        found = []

        def set_src():
            lst = GN_COUNTRIES if src.get() == "gracenote" else SD_COUNTRIES
            country.configure(values=[T(n) for _, n in lst])
            country.current(0)
            if src.get() == "gracenote":
                note.configure(text=T("Type your zip / postal code and press “Find providers”. For an antenna or "
                                      "HDHomeRun, pick “Local Over the Air Broadcast”."))
            else:
                note.configure(text=T("Lineups already on your Schedules Direct account are listed first (no zip code needed). "
                                      "Adding a new lineup uses one of your account's daily lineup changes (max 4 lineups per account).")
                               + ("" if has_login() else "  ⚠ " + T("Enter your login in Settings first.")))
            lb.delete(0, "end")
            found.clear()
        set_src()

        def cc():
            lst = GN_COUNTRIES if src.get() == "gracenote" else SD_COUNTRIES
            return lst[max(0, country.current())][0]

        def find(*_):
            z = postal.get().strip()
            if src.get() == "gracenote" and not z:
                messagebox.showinfo(APP, T("Type your zip / postal code first."), parent=d)
                return
            lb.delete(0, "end")
            found.clear()
            lb.insert("end", "  " + T("Searching…"))
            findb.state(["disabled"])

            def go():
                if src.get() == "gracenote":
                    return [(n, x, False) for n, x in gn_providers(cc(), z)]
                return sd_lineups(cc(), z)[0]

            def done(res):
                findb.state(["!disabled"])
                lb.delete(0, "end")
                found.extend(res)
                for n, x, on in res:
                    lb.insert("end", ("  ★ " if on else "     ") + n + ("   (" + T("on your account") + ")" if on else ""))
                if not res:
                    lb.insert("end", "  " + T("Nothing found — check the zip / postal code and country."))

            def fail(m):
                findb.state(["!disabled"])
                lb.delete(0, "end")
                lb.insert("end", "  " + T("Problem:") + " " + m)
            work(go, done, fail)
        findb.configure(command=find)
        postal.bind("<Return>", find)

        def add(*_):
            if not lb.curselection() or not found:
                messagebox.showinfo(APP, T("Pick a provider from the list first."), parent=d)
                return
            n, lu, on = found[lb.curselection()[0]]
            if src.get() == "sd" and not on and not messagebox.askyesno(
                    APP, T("%s is not on your Schedules Direct account yet.\n\nAdd it? This uses one of your account's "
                           "daily lineup changes.") % n, parent=d):
                return
            lid = new_id()
            write_dat(lineup_files(lid)[0], lu)
            it = {"id": lid, "name": n, "source": src.get(), "country": cc(), "postal": postal.get().strip(), "enabled": True}
            p["lineups"].append(it)
            mark_changed()
            refresh_lineups()
            d.destroy()
            if messagebox.askyesno(APP, T("Added: %s\n\nPick its channels now? (Otherwise every channel is included.)") % n, parent=root):
                edit_channels(it)
        lb.bind("<Double-1>", add)
        bf = ttk.Frame(frm, padding=(0, 14, 0, 0))
        bf.pack(fill="x", side="bottom", before=lf)          # buttons keep their room on small screens
        ttk.Button(bf, text=T("Add this provider"), style="Accent.TButton", command=add).pack(side="right")
        ttk.Button(bf, text=T("Cancel"), command=d.destroy).pack(side="right", padx=8)
        postal.focus_set()

    def import_old():
        path = filedialog.askopenfilename(parent=root, title=T("Choose an mc2xml lineup file (.dat)"),
                                          filetypes=[(T("mc2xml lineup"), "*.dat"), (T("All files"), "*.*")])
        if not path:
            return
        folder, stem = os.path.dirname(path), os.path.splitext(os.path.basename(path))[0]

        def partner(ext):
            for f in os.listdir(folder):
                if f.lower() == (stem + ext).lower():
                    return os.path.join(folder, f)
            return None
        chl = partner(".chl") or filedialog.askopenfilename(parent=root, initialdir=folder, title=T("Its channel file (.chl)? (Cancel = all channels)"),
                                                            filetypes=[(T("mc2xml channels"), "*.chl"), (T("All files"), "*.*")])
        ren = partner(".ren") or filedialog.askopenfilename(parent=root, initialdir=folder, title=T("Its rename file (.ren)? (Cancel = none)"),
                                                            filetypes=[(T("mc2xml renames"), "*.ren"), (T("All files"), "*.*")])
        d0, legacy = read_dat(path)
        name = (d0 or {}).get("lineup_name") or legacy or stem
        guess_sd = bool(d0 and d0.get("source") == "sd")
        d = dialog(T("Import old mc2xml files"))
        frm = ttk.Frame(d, padding=20)
        frm.pack(fill="both", expand=True)
        ttk.Label(frm, text=name, font=F["h"]).pack(anchor="w")
        ttk.Label(frm, style="Muted.TLabel", text=T("Channels: %s\nRenames: %s") % (chl or T("all channels"), ren or T("none"))).pack(anchor="w", pady=(2, 12))
        src = tk.StringVar(value="sd" if guess_sd else "gracenote")
        ttk.Label(frm, text=T("Did this lineup use Schedules Direct (mc2xml -J)?")).pack(anchor="w")
        ttk.Radiobutton(frm, text=T("No — free listings (Gracenote)"), variable=src, value="gracenote").pack(anchor="w", pady=(6, 2))
        ttk.Radiobutton(frm, text=T("Yes — my Schedules Direct account"), variable=src, value="sd").pack(anchor="w")
        row = ttk.Frame(frm)
        row.pack(fill="x", pady=(14, 0))
        ttk.Label(row, text=T("Country")).pack(side="left")
        country = ttk.Combobox(row, state="readonly", width=20, values=[T(n) for _, n in SD_COUNTRIES])
        country.current(0)
        country.pack(side="left", padx=(6, 16))
        ttk.Label(row, text=T("Zip / postal code")).pack(side="left")
        postal = ttk.Entry(row, width=12)
        postal.insert(0, (d0 or {}).get("postal", ""))
        postal.pack(side="left", padx=6)
        ttk.Label(frm, style="Muted.TLabel", wraplength=600, justify="left",
                  text=T("The zip code you used with -g. (Schedules Direct users can leave it empty if the lineup is on "
                         "their account.) Your original files are not changed: copies are made in this program's folder.")).pack(anchor="w", pady=(10, 0))

        def ok():
            if src.get() == "gracenote" and not postal.get().strip():
                messagebox.showinfo(APP, T("Free listings need the zip / postal code."), parent=d)
                return
            lid = new_id()
            dat2, chl2, ren2 = lineup_files(lid)
            shutil.copyfile(path, dat2)
            if chl:
                shutil.copyfile(chl, chl2)
            if ren:
                shutil.copyfile(ren, ren2)
            p["lineups"].append({"id": lid, "name": name, "source": src.get(), "country": SD_COUNTRIES[max(0, country.current())][0],
                                 "postal": postal.get().strip(), "enabled": True, "imported": os.path.basename(path)})
            mark_changed()
            refresh_lineups()
            d.destroy()
            flash(T("Imported %s.") % name)
        bf = ttk.Frame(frm, padding=(0, 16, 0, 0))
        bf.pack(fill="x")
        ttk.Button(bf, text=T("Import"), style="Accent.TButton", command=ok).pack(side="right")
        ttk.Button(bf, text=T("Cancel"), command=d.destroy).pack(side="right", padx=8)

    def edit_provider(it):
        d = dialog(T("Edit provider"))
        frm = ttk.Frame(d, padding=20)
        frm.pack(fill="both", expand=True)
        ttk.Label(frm, text=T("Name shown in the list")).grid(row=0, column=0, sticky="w", padx=(0, 10))
        nm = ttk.Entry(frm, width=46)
        nm.insert(0, it.get("name", ""))
        nm.grid(row=0, column=1, sticky="w", pady=6)
        ttk.Label(frm, text=T("Zip / postal code")).grid(row=1, column=0, sticky="w", padx=(0, 10))
        z = ttk.Entry(frm, width=14)
        z.insert(0, it.get("postal", ""))
        z.grid(row=1, column=1, sticky="w", pady=6)

        def ok():
            it["name"], it["postal"] = nm.get().strip() or it["name"], z.get().strip()
            mark_changed()
            refresh_lineups()
            d.destroy()
        ttk.Button(frm, text=T("Save"), style="Accent.TButton", command=ok).grid(row=2, column=1, sticky="e", pady=(16, 0))

    def remove_provider(it, ask=True):
        if ask and not messagebox.askyesno(APP, T("Remove %s from your providers?") % it.get("name"), parent=root):
            return
        p["lineups"] = [x for x in p["lineups"] if x["id"] != it["id"]]
        forget_last_good(it["id"])
        for f in lineup_files(it["id"]) + (tweak_file(it["id"]),):
            for g in (f, f + ".orig"):
                try:
                    os.remove(g)
                except OSError:
                    pass
        mark_changed()
        refresh_lineups()

    def move(it, delta):
        i = p["lineups"].index(it)
        j = i + delta
        if 0 <= j < len(p["lineups"]):
            p["lineups"][i], p["lineups"][j] = p["lineups"][j], p["lineups"][i]
            mark_changed()
            refresh_lineups()

    # ---------------- channel picker (tick boxes + logos + filters) ----------------
    def edit_pick(key):
        """Pick the channels you want from an EPGTalk guide or an extra XMLTV guide."""
        d = dialog(T("Channels"), "1040x720")
        d.configure(bg=P["bg"])
        frm = tk.Frame(d, bg=P["bg"])
        frm.pack(fill="both", expand=True, padx=18, pady=16)
        top = tk.Frame(frm, bg=P["bg"])
        top.pack(fill="x")
        ttl = tk.Label(top, text=T("Channels"), bg=P["bg"], fg=P["text"], font=F["status"])
        ttl.pack(side="left")
        tr_ = tk.Frame(top, bg=P["bg"])
        tr_.pack(side="right")
        cnt = tk.Label(tr_, text="", bg=P["bg"], fg=P["muted"], font=F["mid"], anchor="e")
        cnt.pack(anchor="e")
        szl = tk.Label(tr_, text="", bg=P["bg"], fg=P["ok"], font=F["bold"], anchor="e")
        szl.pack(anchor="e")
        bar = tk.Frame(frm, bg=P["bg"])
        bar.pack(fill="x", pady=(12, 4))
        qv = tk.StringVar()
        qe = ttk.Entry(bar, textvariable=qv, width=24)
        qe.pack(side="left")
        chipbar = tk.Frame(frm, bg=P["bg"])                # filter chips, wrapped onto as many rows as they need
        chipbar.pack(fill="x")
        bar2 = tk.Frame(frm, bg=P["bg"])
        bar2.pack(fill="x", pady=(4, 6))
        ttk.Button(bar2, text=T("Tick all shown"), style="Chip.TButton", command=lambda: mark(True)).pack(side="left")
        ttk.Button(bar2, text=T("Untick all shown"), style="Chip.TButton", command=lambda: mark(False)).pack(side="left", padx=6)
        tk.Label(frm, bg=P["bg"], fg=P["muted"], font=F["small"], anchor="w", justify="left", wraplength=980,
                 text=T("Search looks at every name a channel has. Click “✎ Rename” — or double-click a channel — to give it "
                        "your own name or number.")).pack(fill="x", pady=(0, 6))
        tc = card(frm)
        tc.pack(fill="both", expand=True)
        tf = tk.Frame(tc.body, bg=P["card"])
        tf.pack(fill="both", expand=True, pady=4)
        gname = {"x_sports": T("LEAGUE"), "x_freetv": T("SERVICE"), "x_uslocal": T("NETWORK")}.get(key, T("GROUP"))
        ct = ttk.Treeview(tf, columns=("name", "full", "grp", "ren"), show="tree headings")
        ct.heading("#0", text="")
        ct.column("#0", width=104, minwidth=104, stretch=False, anchor="w")
        for c_, txt, w_ in (("name", T("CHANNEL"), 300), ("full", T("FULL NAME"), 220), ("grp", gname, 140), ("ren", T("YOUR NAME"), 200)):
            ct.heading(c_, text=txt, anchor="w")
            ct.column(c_, width=w_, anchor="w", stretch=(c_ in ("name", "full", "ren")))
        ct.tag_configure("odd", background=P["stripe"])
        ct.tag_configure("picked", foreground=P["text"])
        ct.tag_configure("unpicked", foreground=P["muted"])
        s3 = ttk.Scrollbar(tf, command=ct.yview)
        ct.configure(yscrollcommand=s3.set)
        ct.pack(side="left", fill="both", expand=True)
        s3.pack(side="left", fill="y")
        bottom = tk.Frame(frm, bg=P["bg"])
        bottom.pack(fill="x", pady=(12, 0), side="bottom", before=tc)
        saveb = ttk.Button(bottom, text=T("Save channels"), style="Accent.TButton", command=lambda: save())
        saveb.pack(side="right")
        ttk.Button(bottom, text=T("Cancel"), command=lambda: close_ask()).pack(side="right", padx=8)
        autov = tk.BooleanVar(value=True)
        autof = tk.Frame(bottom, bg=P["bg"])
        autof.pack(side="left")
        ttk.Checkbutton(autof, text=T("Add new channels automatically"), variable=autov).pack(anchor="w")
        tk.Label(autof, text=T("Off: only the channels you picked. On: new channels added to this guide later come in too."),
                 bg=P["bg"], fg=P["muted"], font=F["small"], anchor="w", justify="left", wraplength=380).pack(anchor="w", padx=(26, 0))
        dirtyl = tk.Label(bottom, text="", bg=P["bg"], fg=P["warn"], font=F["mid"])
        dirtyl.pack(side="right", padx=(0, 10))
        ct.insert("", "end", iid="loading", text="", values=(T("Loading the channel list…"), "", "", ""))
        rows, checked, renames, tweaks, base = [], set(), {}, {}, {}
        S = {"groups": set(), "picked": False, "total": 0, "touched_auto": False, "quiet": False}
        autov.trace_add("write", lambda *_: None if S["quiet"] else S.update(touched_auto=True))
        composite = {}

        def fmt(n):
            return ("%d KB" % max(1, round(n / 1e3))) if n < 1e6 else ("%.1f MB" % (n / 1e6))

        def ren_text(i):
            t = tweaks.get(i, {})
            bits = [renames.get(i) or ""]
            if t.get("num"):
                bits.append("#%s" % t["num"])
            if t.get("shift"):
                bits.append("%+g h" % float(t["shift"]))
            return "  ·  ".join(b_ for b_ in bits if b_) or "✎ " + T("Rename")

        def row_img(i):
            r = rows[i]
            on = i in checked
            lg = logos.get(r.get("logo"))
            k_ = (on, logo_url(r.get("logo")) if lg is not None else None)
            if k_ in composite:
                return composite[k_]
            im = tk.PhotoImage(width=100, height=34)
            if chk_on is not None:
                im.tk.call(str(im), "copy", str(chk_on if on else chk_off), "-to", 6, 8)
            im.tk.call(str(im), "copy", str(lg if lg is not None else blank_tile), "-to", 36, 1)
            composite[k_] = im
            if lg is None and logo_url(r.get("logo")) and logo_url(r.get("logo")) not in logos.failed:
                logo_watchers.setdefault(logo_url(r.get("logo")), []).append(lambda i=i: refresh_row(i))
            return im

        def refresh_row(i):
            if d.winfo_exists() and ct.exists(str(i)):
                ct.item(str(i), image=row_img(i), tags=("picked" if i in checked else "unpicked",))

        def count():
            if base and base["auto"] and len(base["chk"]) == len(rows) and not S["touched_auto"]:
                S["quiet"] = True                     # picking from "every channel": new ones shouldn't sneak in
                autov.set(len(checked) == len(rows))
                S["quiet"] = False
            cnt.configure(text=T("%d of %d picked") % (len(checked), len(rows)))
            got = sum(rows[i]["bytes"] for i in checked)
            szl.configure(text=(T("about %s instead of %s") % (fmt(got), fmt(S["total"]))) if rows and len(checked) < len(rows)
                          else (fmt(S["total"]) if rows else ""))
            for g_, b_ in chips.items():
                on = (g_ == "*all" and not S["groups"] and not S["picked"]) or (g_ == "*picked" and S["picked"]) or g_ in S["groups"] or \
                     (g_.startswith("*menu:") and S["groups"] & set(menus.get(g_, ())))
                b_.configure(style="ChipOn.TButton" if on else "Chip.TButton")

        def shown_ids():
            ql = qv.get().strip().lower()
            out_ = []
            for i, r in enumerate(rows):
                if S["picked"] and i not in checked:
                    continue
                if S["groups"] and r["group"] not in S["groups"]:
                    continue
                if ql and ql not in (" ".join(r["names"]) + " " + renames.get(i, "") + " " + r["group"]).lower():
                    continue
                out_.append(i)
            return out_

        def fill(*_):
            ct.delete(*ct.get_children())
            for k_, i in enumerate(shown_ids()):
                r = rows[i]
                ct.insert("", "end", iid=str(i), image=row_img(i), tags=("picked" if i in checked else "unpicked",) + (("odd",) if k_ % 2 else ()),
                          values=(r["name"], r["full"], r["group"], ren_text(i)))
            count()
        qv.trace_add("write", fill)

        def mark(on):
            for iid in ct.get_children():
                if iid != "loading":
                    (checked.add if on else checked.discard)(int(iid))
            fill()

        def toggle(i):
            (checked.discard if i in checked else checked.add)(i)
            refresh_row(i)
            count()

        def click(ev):
            row, col = ct.identify_row(ev.y), ct.identify_column(ev.x)
            if not row or row == "loading":
                return None
            if col == "#0":
                toggle(int(row))
                return "break"
            if col == "#4":
                ct.selection_set(row)
                d.after(10, lambda: rename_row(row))
                return "break"
            return None
        ct.bind("<Button-1>", click)
        ct.bind("<space>", lambda ev: ([toggle(int(x)) for x in ct.selection() if x != "loading"], "break")[1])
        ct.bind("<Double-1>", lambda ev: rename_row(ct.identify_row(ev.y)) if ct.identify_row(ev.y) and ct.identify_column(ev.x) != "#0" else None)

        def rename_row(row):
            if not row or row == "loading":
                return
            i, r = int(row), rows[int(row)]
            w = tk.Toplevel(d)
            w.title(T("Channel settings"))
            w.configure(bg=P["bg"])
            w.transient(d)
            modal(w)
            f_ = ttk.Frame(w, padding=20)
            f_.pack(fill="both", expand=True)
            hd = tk.Frame(f_, bg=P["bg"])
            hd.pack(fill="x")
            tk.Label(hd, image=logos.get(r.get("logo")) or blank_tile, bg=P["bg"]).pack(side="left")
            tk.Label(hd, text="  %s" % r["name"], bg=P["bg"], fg=P["text"], font=F["h"]).pack(side="left")
            ttk.Label(f_, text=T("Show this channel as")).pack(anchor="w", pady=(14, 4))
            ent = ttk.Entry(f_, width=40)
            ent.insert(0, renames.get(i, ""))
            ent.pack(fill="x")
            ttk.Label(f_, style="Muted.TLabel", text=T("Leave it empty to use the normal name.")).pack(anchor="w", pady=(6, 0))
            t0 = tweaks.get(i, {})
            g_ = ttk.Frame(f_)
            g_.pack(fill="x", pady=(14, 0))
            ttk.Label(g_, text=T("Channel number")).grid(row=0, column=0, sticky="w", padx=(0, 10), pady=3)
            nument = ttk.Entry(g_, width=8)
            nument.insert(0, str(t0.get("num") or ""))
            nument.grid(row=0, column=1, sticky="w")
            ttk.Label(g_, style="Muted.TLabel", text=T("empty = no channel number")).grid(row=0, column=2, sticky="w", padx=8)
            shifts = [T("No shift")] + ["%+d h" % h for h in range(-12, 13) if h]
            ttk.Label(g_, text=T("Time shift")).grid(row=1, column=0, sticky="w", padx=(0, 10), pady=3)
            shv = ttk.Combobox(g_, state="readonly", width=10, values=shifts)
            cur = float(t0.get("shift") or 0)
            shv.set("%+d h" % cur if cur else shifts[0])
            shv.grid(row=1, column=1, sticky="w")

            def ok(*_):
                v = ent.get().strip()
                if v:
                    renames[i] = v
                else:
                    renames.pop(i, None)
                num = re.sub(r"[^0-9.\-]", "", nument.get().strip())[:8]
                sh = shv.get()
                hrs = 0 if sh == shifts[0] else int(sh.split()[0])
                if num or hrs:
                    tweaks[i] = {"num": num, "shift": hrs}
                else:
                    tweaks.pop(i, None)
                if (renames.get(i) or num or hrs) and i not in checked:
                    checked.add(i)
                if ct.exists(str(i)):
                    ct.set(str(i), "ren", ren_text(i))
                refresh_row(i)
                count()
                w.destroy()
            bf = ttk.Frame(f_, padding=(0, 16, 0, 0))
            bf.pack(fill="x")
            ttk.Button(bf, text=T("OK"), style="Accent.TButton", command=ok).pack(side="right")
            ttk.Button(bf, text=T("Cancel"), command=w.destroy).pack(side="right", padx=8)
            ent.bind("<Return>", ok)
            ent.bind("<Escape>", lambda *_: w.destroy())
            ent.focus_set()

        chips, menus = {}, {}

        def make_chips():
            for w_ in chipbar.winfo_children():
                w_.destroy()
            chips.clear()
            menus.clear()
            n = collections.Counter(r["group"] for r in rows if r["group"])

            line = [None, 0]

            def chip(label, g_, cmd):
                b_ = ttk.Button(chipbar, text=label, style="Chip.TButton", command=cmd)
                b_.update_idletasks()
                w_ = b_.winfo_reqwidth() + 6
                if line[0] is None or line[1] + w_ > max(600, frm.winfo_width() - 20):
                    line[0] = tk.Frame(chipbar, bg=P["bg"])
                    line[0].pack(fill="x", pady=(2, 0))
                    line[1] = 0
                b_.destroy()
                b_ = ttk.Button(line[0], text=label, style="Chip.TButton", command=cmd)
                b_.pack(side="left", padx=(0, 6), pady=1)
                line[1] += w_
                chips[g_] = b_
                return b_

            def flip(g_):
                S["groups"] ^= {g_}
                fill()

            def popup(g_, items, b_):
                m_ = tk.Menu(d, tearoff=False)
                m_._vars = []                              # (keep the tick states alive while the menu is open)
                for it_ in items:
                    v_ = tk.IntVar(master=d, value=1 if it_ in S["groups"] else 0)
                    m_._vars.append(v_)
                    m_.add_checkbutton(label="%s · %d" % (T(it_), n[it_]), onvalue=1, offvalue=0, variable=v_,
                                       command=lambda it_=it_: flip(it_))
                m_.tk_popup(b_.winfo_rootx(), b_.winfo_rooty() + b_.winfo_height())
            chip(T("All"), "*all", lambda: (S["groups"].clear(), S.update(picked=False), fill()))
            chip(T("Picked"), "*picked", lambda: (S.update(picked=not S["picked"]), fill()))
            if key == "x_sports":
                order = ["NFL", "NBA", "MLB", "NHL", "MLS", "WNBA", "NCAA Football", "NCAA Basketball"]
                for g_ in order:
                    if n.get(g_):
                        chip(T(g_), g_, lambda g_=g_: flip(g_))
                fam = [("*menu:soccer", T("Soccer"), [g_ for g_ in PICK_SOCCER if n.get(g_)]),
                       ("*menu:more", T("More"), [g_ for g_ in n if g_ not in order and g_ not in PICK_SOCCER])]
            else:
                top_ = [g_ for g_, _ in n.most_common()]
                for g_ in top_[:7]:
                    chip("%s · %d" % (g_, n[g_]), g_, lambda g_=g_: flip(g_))
                fam = [("*menu:more", T("More"), top_[7:])]
            for mk, lbl, items in fam:
                if items:
                    menus[mk] = items
                    b_ = chip(lbl + " ▾", mk, None)
                    b_.configure(command=lambda b_=b_, items=items, mk=mk: popup(mk, items, b_))

        def changes():
            if not base:
                return {}
            nt = lambda t: (str(t.get("num") or ""), float(t.get("shift") or 0))
            return {"renamed": sum(1 for i in set(renames) | set(base["ren"]) if renames.get(i) != base["ren"].get(i)),
                    "picked": len(checked - base["chk"]), "unticked": len(base["chk"] - checked),
                    "tweaked": sum(1 for i in set(tweaks) | set(base["tw"]) if nt(tweaks.get(i, {})) != nt(base["tw"].get(i, {}))),
                    "auto": int(autov.get() != base["auto"])}

        def dirty_tick():
            if not d.winfo_exists():
                return
            n_ = sum(changes().values())
            dirtyl.configure(text=("● " + (T("1 change not saved yet") if n_ == 1 else T("%d changes not saved yet") % n_)) if n_ else "")
            d.after(400, dirty_tick)

        def close_ask():
            ch = changes()
            if not sum(ch.values()):
                d.destroy()
                return
            parts_ = []
            if ch["renamed"]:
                parts_.append(T("renamed 1 channel") if ch["renamed"] == 1 else T("renamed %d channels") % ch["renamed"])
            if ch["picked"]:
                parts_.append(T("picked %d more") % ch["picked"])
            if ch["unticked"]:
                parts_.append(T("unticked %d") % ch["unticked"])
            if ch["tweaked"]:
                parts_.append(T("changed the number or time shift of %d") % ch["tweaked"])
            if ch["auto"]:
                parts_.append(T("changed “Add new channels automatically”"))
            said = parts_[0] if len(parts_) == 1 else ", ".join(parts_[:-1]) + " " + T("and") + " " + parts_[-1]
            q = tk.Toplevel(d)
            q.title(APP)
            q.configure(bg=P["bg"])
            q.transient(d)
            modal(q)
            qf = ttk.Frame(q, padding=22)
            qf.pack(fill="both", expand=True)
            ttk.Label(qf, text=T("Save your changes?"), font=F["h"]).pack(anchor="w")
            msg = T("You %s. If you don't save, these changes are lost.") % said
            ttk.Label(qf, text=msg[:1].upper() + msg[1:], wraplength=460, justify="left").pack(anchor="w", pady=(6, 0))
            qb = ttk.Frame(qf, padding=(0, 18, 0, 0))
            qb.pack(fill="x")
            ttk.Button(qb, text=T("Save"), style="Accent.TButton", command=lambda: (q.destroy(), save())).pack(side="right")
            ttk.Button(qb, text=T("Don't save"), command=lambda: (q.destroy(), d.destroy())).pack(side="right", padx=8)
            ttk.Button(qb, text=T("Keep editing"), command=q.destroy).pack(side="right")
            q.bind("<Escape>", lambda *_: q.destroy())
        d.protocol("WM_DELETE_WINDOW", close_ask)

        def load():
            path, title = pick_source(key, p)
            rs, total = pick_rows(path, key)
            return title, rs, total

        def loaded(res):
            title, rs, total = res
            if not d.winfo_exists():
                return
            d.title(T("Channels") + " — %s" % title)
            ttl.configure(text=T("Channels") + " · " + title)
            rows.extend(rs)
            S["total"] = total
            pk = read_pick(key)
            for i, r in enumerate(rows):
                if pk["ids"] is None or r["cid"] in pk["ids"] or (pk["auto"] and pk["known"] and r["cid"] not in pk["known"]):
                    checked.add(i)
                if r["cid"] in pk["ren"]:
                    renames[i] = pk["ren"][r["cid"]]
                if r["cid"] in pk["twk"]:
                    tweaks[i] = pk["twk"][r["cid"]]
            S["quiet"] = True
            autov.set(bool(pk["auto"]))
            S["quiet"] = False
            S["touched_auto"] = False
            base.update(chk=set(checked), ren=dict(renames), tw={k_: dict(v) for k_, v in tweaks.items()}, auto=bool(pk["auto"]))
            make_chips()
            fill()
            dirty_tick()

        def failed(m):
            if d.winfo_exists():
                ct.delete(*ct.get_children())
                ct.insert("", "end", iid="loading", text="", values=(T("Problem:") + " " + m, "", "", ""))

        def save():
            if not rows:
                d.destroy()
                return
            if not checked and not messagebox.askyesno(APP, T("No channels are picked. Save anyway?"), parent=d):
                return
            auto = autov.get()
            every = len(checked) == len(rows) and auto
            save_pick(key, None if every else {rows[i]["cid"] for i in checked},
                      {rows[i]["cid"]: n_ for i, n_ in renames.items()}, {rows[i]["cid"]: t for i, t in tweaks.items()},
                      {r["cid"]: r["name"] for r in rows}, auto)
            mark_changed()
            try:
                ex_refresh()
                gm_fill()
            except Exception:
                pass
            flash(T("Saved %d channels for %s.") % (len(checked), ttl.cget("text").split(" · ", 1)[-1]))
            d.destroy()
        work(load, loaded, failed)

    def lineup_dialog(it, opts, nm, mine):
        """Pick the lineup for a provider that wasn't found by name. mine = positions of the lineups on the
        Schedules Direct account (None = free listings). Returns a lineup, None or "remove"."""
        sd = mine is not None
        d = dialog(T("Which lineup is it?"), "700x560")
        res = [None]
        frm = ttk.Frame(d, padding=20)
        frm.pack(fill="both", expand=True)
        ttk.Label(frm, text=(T("“%s” isn't on your Schedules Direct account") if sd else T("“%s” wasn't found by name")) % nm,
                  font=F["h"], wraplength=650, justify="left").pack(anchor="w")
        if sd and mine:
            sub = T("It may have been removed from the account. Pick the lineup this provider should use — these are the "
                    "lineups on your account right now:")
        elif sd:
            sub = T("Your Schedules Direct account has no lineups right now. Search by zip / postal code, or remove this provider.")
        else:
            sub = T("Providers rename their lineups now and then. Please pick it:")
        ttk.Label(frm, text=sub, style="Muted.TLabel", wraplength=650, justify="left").pack(anchor="w", pady=(4, 10))
        lf = ttk.Frame(frm)
        lf.pack(fill="both", expand=True)
        lb = listbox(lf)
        s2 = ttk.Scrollbar(lf, command=lb.yview)
        lb.configure(yscrollcommand=s2.set)
        lb.pack(side="left", fill="both", expand=True)
        s2.pack(side="left", fill="y")
        shown = []

        def show(idx, plain=False):
            shown[:] = idx
            lb.delete(0, "end")
            for k in idx:
                lb.insert("end", "  " + (opts[k][0].replace("  (" + T("on your account") + ")", "") if plain else opts[k][0]))
            if idx:
                lb.selection_set(0)
        show(mine, True) if sd and mine else show(list(range(len(opts))))
        if sd and mine and len(opts) > len(mine):
            lk = tk.Label(frm, text=T("Search all lineups by zip / postal code instead…"), bg=P["bg"], fg=P["accent_text"],
                          font=F["link"], cursor="hand2", anchor="w")
            lk.pack(anchor="w", pady=(8, 0))
            lk.bind("<Button-1>", lambda e: (show(list(range(len(opts)))), lk.pack_forget()))
        if sd and it.get("country", "us") in ("us", "ca", "mx"):
            hint = tk.Frame(frm, bg=P["warn_soft"])
            hint.pack(fill="x", pady=(10, 0))
            tk.Frame(hint, bg=P["warn"], width=3).pack(side="left", fill="y")
            tk.Label(hint, text=T("Want %s back? Remove this provider, then add it again with the free listings (Gracenote) — "
                                  "it doesn't use one of your 4 Schedules Direct lineups.") % nm.split(" (")[0],
                     bg=P["warn_soft"], fg=P["text"], font=F["small"], wraplength=620, justify="left", anchor="w").pack(
                side="left", fill="x", padx=10, pady=8)

        def ok(*_):
            if lb.curselection():
                res[0] = opts[shown[lb.curselection()[0]]][1]
                d.destroy()

        def rm():
            res[0] = "remove"
            d.destroy()
        lb.bind("<Double-1>", ok)
        bf = ttk.Frame(frm, padding=(0, 16, 0, 0))
        bf.pack(fill="x", side="bottom", before=lf)
        ttk.Button(bf, text=T("Use this lineup"), style="Accent.TButton", command=ok).pack(side="right")
        ttk.Button(bf, text=T("Cancel"), command=d.destroy).pack(side="right", padx=8)
        ttk.Button(bf, text=T("Remove this provider"), style="Danger.TButton", command=rm).pack(side="left")
        d.wait_window()
        return res[0]

    def edit_channels(it):
        d = dialog(T("Channels") + " — %s" % it.get("name"), "1000x700")
        d.configure(bg=P["bg"])
        frm = tk.Frame(d, bg=P["bg"])
        frm.pack(fill="both", expand=True, padx=18, pady=16)
        top = tk.Frame(frm, bg=P["bg"])
        top.pack(fill="x")
        tk.Label(top, text=T("Channels") + " · " + it.get("name", ""), bg=P["bg"], fg=P["text"], font=F["status"]).pack(side="left")
        cnt = tk.Label(top, text="", bg=P["bg"], fg=P["muted"], font=F["mid"])
        cnt.pack(side="right")
        bar = tk.Frame(frm, bg=P["bg"])
        bar.pack(fill="x", pady=(12, 8))
        qv = tk.StringVar()
        qe = ttk.Entry(bar, textvariable=qv, width=26)
        qe.pack(side="left")
        ph = T("Find a channel")

        def ph_show(*_):
            if not qv.get() and d.focus_get() is not qe:
                qe.configure(foreground=P["muted"])
                qe.insert(0, ph)

        def ph_hide(*_):
            if qe.get() == ph and str(qe.cget("foreground")) == P["muted"]:
                qe.delete(0, "end")
                qe.configure(foreground=P["text"])
        qe.bind("<FocusIn>", ph_hide)
        qe.bind("<FocusOut>", ph_show)
        flt = tk.StringVar(value="all")
        chips = {}
        for key, lbl in (("all", T("All")), ("picked", T("Picked")), ("main", T("Main stations")), ("sub", T("Sub-channels"))):
            b = ttk.Button(bar, text=lbl, style="Chip.TButton", command=lambda k=key: (flt.set(k), fill()))
            b.pack(side="left", padx=(8 if key == "all" else 4, 0))
            chips[key] = b
        bar2 = tk.Frame(frm, bg=P["bg"])
        bar2.pack(fill="x", pady=(0, 6))
        ttk.Button(bar2, text=T("Tick all shown"), style="Chip.TButton", command=lambda: mark(True)).pack(side="left")
        ttk.Button(bar2, text=T("Untick all shown"), style="Chip.TButton", command=lambda: mark(False)).pack(side="left", padx=6)
        info = tk.Label(frm, bg=P["bg"], fg=P["muted"], font=F["small"], anchor="w", justify="left", wraplength=940,
                        text=T("Click the box to pick a channel (or select rows and press the space bar). Click “✎ Rename” "
                               "— or double-click a channel — to give it your own name."))
        info.pack(fill="x", pady=(0, 6))
        tipf = tk.Frame(frm, bg=P["accent_soft"])
        tipf.pack(fill="x", pady=(0, 8))
        tk.Frame(tipf, bg=P["accent"], width=3).pack(side="left", fill="y")
        tk.Label(tipf, text=T("Tip: TiviMate shows the channel names from your playlist. The names you give here show in Plex, "
                              "Jellyfin, Emby, Channels DVR and this app's TV guide, and they help match your channels."),
                 bg=P["accent_soft"], fg=P["text"], font=F["small"], anchor="w", justify="left", wraplength=920).pack(
            side="left", fill="x", padx=10, pady=6)
        tc = card(frm)
        tc.pack(fill="both", expand=True)
        tf = tk.Frame(tc.body, bg=P["card"])
        tf.pack(fill="both", expand=True, pady=4)
        ct = ttk.Treeview(tf, columns=("num", "name", "cs", "ren"), show="tree headings")
        ct.heading("#0", text="")
        ct.column("#0", width=104, minwidth=104, stretch=False, anchor="w")
        for c, txt, w, anc in (("num", T("NUMBER"), 80, "w"), ("name", T("CHANNEL"), 330, "w"), ("cs", T("CALL SIGN"), 120, "w"),
                               ("ren", T("YOUR NAME"), 220, "w")):
            ct.heading(c, text=txt, anchor="w")
            ct.column(c, width=w, anchor=anc, stretch=(c in ("name", "ren")))
        ct.tag_configure("odd", background=P["stripe"])
        ct.tag_configure("picked", foreground=P["text"])
        ct.tag_configure("unpicked", foreground=P["muted"])
        s3 = ttk.Scrollbar(tf, command=ct.yview)
        ct.configure(yscrollcommand=s3.set)
        ct.pack(side="left", fill="both", expand=True)
        s3.pack(side="left", fill="y")
        bottom = tk.Frame(frm, bg=P["bg"])
        bottom.pack(fill="x", pady=(12, 0), side="bottom", before=tc)   # buttons keep their room on small screens
        saveb = ttk.Button(bottom, text=T("Save channels"), style="Accent.TButton")
        saveb.pack(side="right")
        ttk.Button(bottom, text=T("Cancel"), command=lambda: close_ask()).pack(side="right", padx=8)
        dirtyl = tk.Label(bottom, text="", bg=P["bg"], fg=P["warn"], font=F["mid"], anchor="w")
        dirtyl.pack(side="left")
        ct.insert("", "end", iid="loading", text="", values=("", T("Loading the channel list…"), "", ""))
        rows, checked, renames, tweaks = [], set(), {}, {}
        base = {}                                       # how it was when the list loaded (to spot unsaved changes)

        def changes():
            if not base:
                return {}
            norm_t = lambda t: (str(t.get("num") or ""), float(t.get("shift") or 0))
            return {"renamed": sum(1 for i in set(renames) | set(base["ren"]) if renames.get(i) != base["ren"].get(i)),
                    "picked": len(checked - base["chk"]), "unticked": len(base["chk"] - checked),
                    "tweaked": sum(1 for i in set(tweaks) | set(base["tw"])
                                   if norm_t(tweaks.get(i, {})) != norm_t(base["tw"].get(i, {})))}

        def dirty_tick():
            if not d.winfo_exists():
                return
            n = sum(changes().values())
            dirtyl.configure(text=("● " + (T("1 change not saved yet") if n == 1 else T("%d changes not saved yet") % n)) if n else "")
            d.after(400, dirty_tick)

        def close_ask():
            ch = changes()
            if not sum(ch.values()):
                d.destroy()
                return
            parts = []
            if ch["renamed"]:
                parts.append(T("renamed 1 channel") if ch["renamed"] == 1 else T("renamed %d channels") % ch["renamed"])
            if ch["picked"]:
                parts.append(T("picked %d more") % ch["picked"])
            if ch["unticked"]:
                parts.append(T("unticked %d") % ch["unticked"])
            if ch["tweaked"]:
                parts.append(T("changed the number or time shift of %d") % ch["tweaked"])
            said = parts[0] if len(parts) == 1 else ", ".join(parts[:-1]) + " " + T("and") + " " + parts[-1]
            q = tk.Toplevel(d)
            q.title(APP)
            q.configure(bg=P["bg"])
            q.transient(d)
            modal(q)
            qf = ttk.Frame(q, padding=22)
            qf.pack(fill="both", expand=True)
            ttk.Label(qf, text=T("Save your changes?"), font=F["h"]).pack(anchor="w")
            msg = T("You %s. If you don't save, these changes are lost.") % said
            ttk.Label(qf, text=msg[:1].upper() + msg[1:], wraplength=460,
                      justify="left").pack(anchor="w", pady=(6, 0))
            qb = ttk.Frame(qf, padding=(0, 18, 0, 0))
            qb.pack(fill="x")
            ttk.Button(qb, text=T("Save"), style="Accent.TButton", command=lambda: (q.destroy(), save())).pack(side="right")
            ttk.Button(qb, text=T("Don't save"), command=lambda: (q.destroy(), d.destroy())).pack(side="right", padx=8)
            ttk.Button(qb, text=T("Keep editing"), command=q.destroy).pack(side="right")
            q.bind("<Escape>", lambda *_: q.destroy())
        d.protocol("WM_DELETE_WINDOW", close_ask)

        def ren_text(i):
            t = tweaks.get(i, {})
            bits = [renames.get(i) or ""]
            if t.get("num"):
                bits.append("#%s" % t["num"])
            if t.get("shift"):
                bits.append("%+g h" % float(t["shift"]))
            txt = "  ·  ".join(b for b in bits if b)
            return txt or "✎ " + T("Rename")
        e = engine()
        composite = {}

        def row_img(i):
            """Tick box + logo tile in one picture (Treeview shows one picture per row)."""
            r = rows[i]
            on = i in checked
            logo = logos.get(r.get("logo"))
            key = (on, logo_url(r.get("logo")) if logo is not None else None)
            if key in composite:
                return composite[key]
            im = tk.PhotoImage(width=100, height=34)
            if chk_on is not None:
                im.tk.call(str(im), "copy", str(chk_on if on else chk_off), "-to", 6, 8)
            im.tk.call(str(im), "copy", str(logo if logo is not None else blank_tile), "-to", 36, 1)
            composite[key] = im
            if logo is None and logo_url(r.get("logo")) and logo_url(r.get("logo")) not in logos.failed:
                logo_watchers.setdefault(logo_url(r.get("logo")), []).append(lambda i=i: refresh_row(i))
            return im

        def label(r):
            return e.network_label(r["name"], r["cs"]) or r["cs"] or r["num"]

        def refresh_row(i):
            if d.winfo_exists() and ct.exists(str(i)):
                ct.item(str(i), image=row_img(i), tags=tag_of(i))

        def tag_of(i):
            return ("picked" if i in checked else "unpicked",)

        def count():
            cnt.configure(text=T("%d of %d picked") % (len(checked), len(rows)))
            for k, b in chips.items():
                b.configure(style="ChipOn.TButton" if flt.get() == k else "Chip.TButton")

        def is_main(r):
            return "." not in r["num"] or r["num"].endswith(".1")

        def fill(*_):
            ct.delete(*ct.get_children())
            ql = qv.get().strip().lower()
            if ql == ph.lower():
                ql = ""
            f = flt.get()
            k = 0
            for i, r in enumerate(rows):
                if f == "picked" and i not in checked:
                    continue
                if f == "main" and not is_main(r):
                    continue
                if f == "sub" and is_main(r):
                    continue
                if ql and ql not in ("%s %s %s %s %s" % (r["num"], r["cs"], r["name"], label(r), renames.get(i, ""))).lower():
                    continue
                ct.insert("", "end", iid=str(i), image=row_img(i), tags=tag_of(i) + (("odd",) if k % 2 else ()),
                          values=(r["num"], label(r), r["cs"], ren_text(i)))
                k += 1
            count()
        qv.trace_add("write", fill)

        def mark(on):
            for iid in ct.get_children():
                if iid != "loading":
                    (checked.add if on else checked.discard)(int(iid))
            fill()

        def toggle(i):
            (checked.discard if i in checked else checked.add)(i)
            refresh_row(i)
            count()

        def click(ev):
            row, col = ct.identify_row(ev.y), ct.identify_column(ev.x)
            if not row or row == "loading":
                return None
            if col == "#0":                             # the tick box and the logo next to it: tick / untick
                toggle(int(row))                        # (the box sits after the tree's indent, so the whole
                return "break"                          #  column counts - an exact spot was too easy to miss)
            if col == "#4":
                ct.selection_set(row)
                d.after(10, lambda: rename_row(row))
                return "break"
            return None
        ct.bind("<Button-1>", click)

        def space(ev):
            for iid in ct.selection():
                if iid != "loading":
                    toggle(int(iid))
            return "break"
        ct.bind("<space>", space)

        def set_name(i, v):
            v = (v or "").strip()
            if v:
                renames[i] = v
            else:
                renames.pop(i, None)
            if ct.exists(str(i)):
                ct.set(str(i), "ren", ren_text(i))

        def rename_row(row):
            if not row or row == "loading":
                return
            i, r = int(row), rows[int(row)]
            w = tk.Toplevel(d)
            w.title(T("Channel settings"))
            w.configure(bg=P["bg"])
            w.transient(d)
            modal(w)
            f = ttk.Frame(w, padding=20)
            f.pack(fill="both", expand=True)
            hd = tk.Frame(f, bg=P["bg"])
            hd.pack(fill="x")
            tk.Label(hd, image=logos.get(r.get("logo")) or blank_tile, bg=P["bg"]).pack(side="left")
            tk.Label(hd, text="  %s   %s   %s" % (r["num"], label(r), r["cs"]), bg=P["bg"], fg=P["text"], font=F["h"]).pack(side="left")
            ttk.Label(f, text=T("Show this channel as")).pack(anchor="w", pady=(14, 4))
            ent = ttk.Entry(f, width=40)
            ent.insert(0, renames.get(i, ""))
            ent.pack(fill="x")
            ttk.Label(f, style="Muted.TLabel", text=T("Leave it empty to use the normal name.")).pack(anchor="w", pady=(6, 0))
            t0 = tweaks.get(i, {})
            g2_ = ttk.Frame(f)
            g2_.pack(fill="x", pady=(14, 0))
            ttk.Label(g2_, text=T("Channel number")).grid(row=0, column=0, sticky="w", padx=(0, 10), pady=3)
            nument = ttk.Entry(g2_, width=8)
            nument.insert(0, str(t0.get("num") or ""))
            nument.grid(row=0, column=1, sticky="w")
            ttk.Label(g2_, style="Muted.TLabel", text=T("empty = the provider's number (%s)") % r["num"]).grid(row=0, column=2, sticky="w", padx=8)
            shifts = [T("No shift")] + ["%+d h" % h for h in range(-12, 13) if h]
            ttk.Label(g2_, text=T("Time shift")).grid(row=1, column=0, sticky="w", padx=(0, 10), pady=3)
            shv = ttk.Combobox(g2_, state="readonly", width=10, values=shifts)
            cur = float(t0.get("shift") or 0)
            shv.set("%+d h" % cur if cur else shifts[0])
            shv.grid(row=1, column=1, sticky="w")
            ttk.Label(g2_, style="Muted.TLabel", text=T("e.g. +3 h for a West Coast feed")).grid(row=1, column=2, sticky="w", padx=8)

            def ok(*_):
                set_name(i, ent.get())
                num = re.sub(r"[^0-9.\-]", "", nument.get().strip())[:8]
                sh = shv.get()
                hrs = 0 if sh == shifts[0] else int(sh.split()[0])
                if num or hrs:
                    tweaks[i] = {"num": num, "shift": hrs}
                else:
                    tweaks.pop(i, None)
                if ct.exists(str(i)):
                    ct.set(str(i), "ren", ren_text(i))
                if (renames.get(i) or num or hrs) and i not in checked:      # setting a channel up means you want it
                    toggle(i)
                w.destroy()
            bf = ttk.Frame(f, padding=(0, 16, 0, 0))
            bf.pack(fill="x")
            ttk.Button(bf, text=T("OK"), style="Accent.TButton", command=ok).pack(side="right")
            ttk.Button(bf, text=T("Cancel"), command=w.destroy).pack(side="right", padx=8)
            ent.bind("<Return>", ok)
            ent.bind("<Escape>", lambda *_: w.destroy())
            ent.focus_set()
            ent.select_range(0, "end")

        def dbl(ev):
            row = ct.identify_row(ev.y)
            if row and row != "loading" and ct.identify_column(ev.x) != "#0":   # double-click on the box = just a tick
                ct.selection_set(row)
                rename_row(row)
        ct.bind("<Double-1>", dbl)
        rmenu = tk.Menu(d, tearoff=False)

        def right(ev):
            row = ct.identify_row(ev.y)
            if not row or row == "loading":
                return
            ct.selection_set(row)
            i = int(row)
            rmenu.delete(0, "end")
            rmenu.add_command(label=T("Channel settings…"), command=lambda: rename_row(row))
            if i in renames:
                rmenu.add_command(label=T("Remove my name"), command=lambda: set_name(i, ""))
            rmenu.add_command(label=T("Untick") if i in checked else T("Tick"), command=lambda: toggle(i))
            rmenu.tk_popup(ev.x_root, ev.y_root)
        ct.bind("<Button-3>", right)
        ct.bind("<Button-2>" if sys.platform == "darwin" else "<Control-Button-1>", right)

        removed = [False]

        def ask_lineup(opts, nm, mine):
            box, ev = [None], threading.Event()

            def go():
                box[0] = lineup_dialog(it, opts, nm, mine)
                ev.set()
            ui(go)
            ev.wait()
            if box[0] == "remove":
                removed[0] = True
            return box[0]

        def load():
            lu = resolve_legacy(it, ask_lineup)
            return channel_rows(it, lu, lambda lid: ask_in_thread(
                T("%s is not on your Schedules Direct account yet.\n\nAdd it? This uses one of your account's daily lineup changes.") % lid))

        def loaded(res):
            rows.extend(res)
            dat, chl, ren = lineup_files(it["id"])
            keys, rn, tw = read_chl(chl), read_ren(ren), read_tweaks(tweak_file(it["id"]))
            for i, r in enumerate(rows):
                if keys is None or keys & row_keys(r):
                    checked.add(i)
                for kk in ((r.get("cid") or "").upper(), r["cs"].upper(), r["num"].upper()):   # (a channel whose call sign
                    if kk and kk in rn:                                                     #  and number repeat is kept
                        renames[i] = rn[kk]                                                 #  by its channel id)
                        break
                for kk in (r["cs"].upper(), r["num"].upper(), (r.get("cid") or "").upper()):
                    if kk and kk in tw:
                        tweaks[i] = tw[kk]
                        break
            if keys is None:
                info.configure(text=T("All channels are picked (no channel list yet). Untick what you don't want — or "
                                      "“Untick all shown” and then tick your favourites."))
            if not any("." in r["num"] for r in rows):
                chips["main"].pack_forget()
                chips["sub"].pack_forget()
            base.update(chk=set(checked), ren=dict(renames), tw={k: dict(v) for k, v in tweaks.items()})
            dirty_tick()
            fill()
            ph_show()

        def failed(m):
            if removed[0]:                              # "Remove this provider" in the lineup question
                if d.winfo_exists():
                    d.destroy()
                remove_provider(it, ask=False)
                flash(T("Removed %s.") % it.get("name"))
                return
            if not d.winfo_exists():
                return
            ct.delete(*ct.get_children())
            ct.insert("", "end", iid="loading", text="", values=("", T("Problem:") + " " + m, "", ""))

        def save():
            if not rows:
                d.destroy()
                return
            if not checked and not messagebox.askyesno(APP, T("No channels are picked. Save anyway?"), parent=d):
                return
            dat, chl, ren = lineup_files(it["id"])
            save_channel_files(rows, checked, renames, chl, ren, tweaks, tweak_file(it["id"]))
            mark_changed()
            refresh_lineups()
            flash(T("Saved %d channels for %s.") % (len(checked), it.get("name")))
            d.destroy()
        saveb.configure(command=save)
        work(load, loaded, failed)

    # ====================================================================== #
    # Build
    # ====================================================================== #
    bbody, _ = page("build", T("Build your guide"), T("Downloads the listings for your providers and makes one guide file. Shortcut: Ctrl+B."))
    btop = tk.Frame(bbody, bg=P["bg"])
    btop.pack(fill="x")
    buildb = ttk.Button(btop, text="▶   " + T("Build my guide"), style="Big.TButton")
    buildb.pack(side="left")
    stopb = ttk.Button(btop, text=T("Stop"), style="Danger.TButton")
    pbar = ttk.Progressbar(btop, mode="determinate")
    pbar.pack(side="left", fill="x", expand=True, padx=16)
    plabel = tk.Label(btop, text="", bg=P["bg"], fg=P["muted"], font=F["mid"])
    plabel.pack(side="left")
    tiles = tk.Frame(bbody, bg=P["bg"])
    tiles.pack(fill="x", pady=(16, 0))
    tvals = {}
    for i, (k, lbl) in enumerate((("channels", T("Channels")), ("programs", T("Shows")), ("size", T("File size")), ("secs", T("Built in")))):
        c = card(tiles)
        c.grid(row=0, column=i, sticky="ew", padx=(0 if i == 0 else 10, 0))
        tiles.grid_columnconfigure(i, weight=1, uniform="t")
        tk.Label(c.body, text=lbl, bg=P["card"], fg=P["muted"], font=F["small"], anchor="w").pack(fill="x", padx=6, pady=(8, 0))
        v = tk.Label(c.body, text="—", bg=P["card"], fg=P["text"], font=F["big"], anchor="w")
        v.pack(fill="x", padx=6, pady=(0, 8))
        tvals[k] = v
    mid = tk.Frame(bbody, bg=P["bg"])
    mid.pack(fill="x", pady=(12, 0))
    mid.grid_columnconfigure(0, weight=3, uniform="m")
    mid.grid_columnconfigure(1, weight=2, uniform="m")
    resc = card(mid)
    resc.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
    rtitle = autowrap(tk.Label(resc.body, text="", bg=P["card"], fg=P["text"], font=F["h"], anchor="w", justify="left"))
    rtitle.pack(fill="x", padx=6, pady=(10, 2))
    rsub = autowrap(tk.Label(resc.body, text="", bg=P["card"], fg=P["muted"], font=F["mid"], anchor="w", justify="left"))
    rsub.pack(fill="x", padx=6)
    rbtns = tk.Frame(resc.body, bg=P["card"])
    rbtns.pack(fill="x", padx=6, pady=(12, 12))

    def copy_text(t):
        root.clipboard_clear()
        root.clipboard_append(t)
        flash(T("Copied: %s") % t)
    ttk.Button(rbtns, text=T("Open the folder"), style="Chip.TButton", command=lambda: open_path(os.path.dirname(out_path(p)))).pack(side="left")
    ttk.Button(rbtns, text=T("Copy the file path"), style="Chip.TButton", command=lambda: copy_text(out_path(p))).pack(side="left", padx=6)
    stepc = card(mid)
    stepc.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
    tk.Label(stepc.body, text=T("Steps"), bg=P["card"], fg=P["text"], font=F["h"], anchor="w").pack(fill="x", padx=6, pady=(10, 4))
    stepbox = tk.Frame(stepc.body, bg=P["card"])
    stepbox.pack(fill="x", padx=6, pady=(0, 10))
    logbar = tk.Frame(bbody, bg=P["bg"])
    logbar.pack(fill="x", pady=(12, 0))
    logv = [bool(p.get("show_log", False))]
    logbtn = ttk.Button(logbar, text="", style="Chip.TButton")
    logbtn.pack(side="left")
    logf = tk.Frame(bbody, bg=P["log_bg"])
    logt = tk.Text(logf, wrap="word", height=8, font="TkFixedFont", relief="flat", borderwidth=0, background=P["log_bg"],
                   foreground=P["log_fg"], insertbackground=P["log_fg"], padx=12, pady=10, highlightthickness=0)
    ls = ttk.Scrollbar(logf, command=logt.yview)
    logt.configure(yscrollcommand=ls.set)
    logt.pack(side="left", fill="both", expand=True)
    ls.pack(side="left", fill="y")
    for tag, col in (("ok", "#4fd18b"), ("err", "#ff7b72"), ("warn", "#ffb547"), ("info", "#ffffff"), ("dim", "#8fa6c2")):
        logt.tag_configure(tag, foreground=col)
    logt.insert("end", T("The details of each build show here.") + "\n", "dim")
    logt.configure(state="disabled")

    def log_toggle(force=None):
        logv[0] = (not logv[0]) if force is None else force
        p["show_log"] = logv[0]
        logbtn.configure(text=("▾  " + T("Hide details")) if logv[0] else ("▸  " + T("Show details")))
        if logv[0]:
            logf.pack(fill="both", expand=True, pady=(8, 0))
        else:
            logf.pack_forget()
    logbtn.configure(command=log_toggle)
    log_toggle(logv[0])

    def say(text, kind="dim"):
        def put():
            logt.configure(state="normal")
            logt.insert("end", text + "\n", kind)
            logt.see("end")
            logt.configure(state="disabled")
            m = re.search(r"Completed \.*: \d+ bytes in \d+s, (\d+) channels, (\d+) programs", text)
            if m and steps[0]:
                for s_ in steps[0]:
                    if s_["state"] == "run":
                        s_["note"] = T("%s channels · %s shows") % (m.group(1), "{:,}".format(int(m.group(2))))
                        draw_steps()
            if kind == "err" and steps[0]:
                for s_ in steps[0]:
                    if s_["state"] == "run" and s_["name"] and s_["name"] in text:
                        s_["state"] = "fail"
                        draw_steps()
        ui(put)

    cancel = threading.Event()
    procbox = [None]
    building = [False]
    steps = [[]]
    spin = ["◐", "◓", "◑", "◒"]
    spin_i = [0]

    def draw_steps():
        for w in stepbox.winfo_children():
            w.destroy()
        if not steps[0]:
            names = [x.get("name") for x in p["lineups"] if x.get("enabled", True)] + \
                    [T(lbl).split(":")[0] for k, lbl, _ in EXTRAS if k in p.get("extras", [])]
            if not names:
                tk.Label(stepbox, text=T("Add a provider first."), bg=P["card"], fg=P["muted"], font=F["mid"], anchor="w").pack(fill="x")
                return
            for nm in names:
                tk.Label(stepbox, text="○  " + nm, bg=P["card"], fg=P["muted"], font=F["mid"], anchor="w").pack(fill="x", pady=1)
            return
        for s_ in steps[0]:
            sym, col = {"wait": ("○", P["muted"]), "run": (spin[spin_i[0] % 4], P["accent"]), "ok": ("✔", P["ok"]),
                        "fail": ("✖", P["err"]), "warn": ("⚠", P["warn"])}[s_["state"]]
            r = tk.Frame(stepbox, bg=P["card"])
            r.pack(fill="x", pady=2)
            tk.Label(r, text=sym, bg=P["card"], fg=col, font=F["bold"], width=2).pack(side="left", anchor="n")
            tx = tk.Frame(r, bg=P["card"])
            tx.pack(side="left", fill="x", expand=True)
            autowrap(tk.Label(tx, text=s_["label"], bg=P["card"], fg=P["text"] if s_["state"] != "wait" else P["muted"], font=F["mid"],
                              anchor="w", justify="left")).pack(fill="x")
            if s_.get("note"):
                tk.Label(tx, text=s_["note"], bg=P["card"], fg=P["muted"], font=F["small"], anchor="w").pack(fill="x")

    def spin_tick():
        if building[0]:
            spin_i[0] += 1
            draw_steps()
            root.after(180, spin_tick)

    def fill_tiles(lb):
        if not lb:
            return
        tvals["channels"].configure(text=str(lb.get("channels", "—")))
        tvals["programs"].configure(text="{:,}".format(lb.get("programs", 0)))
        tvals["size"].configure(text="%.1f MB" % (lb.get("size", 0) / 1e6))
        tvals["secs"].configure(text=(("%d s" % lb["secs"]) if lb["secs"] >= 1 else T("under 1 s")) if "secs" in lb else "—")

    def build_status():
        """Build page when you open it: no guide yet / changes not built yet / last build (checks the real file)."""
        if building[0]:
            return
        lb = p.get("last_build")
        draw_steps()
        if not lb or not guide_exists():
            for v in tvals.values():
                v.configure(text="—")
            rtitle.configure(text=T("Press “Build my guide” to make your guide file."), fg=P["text"])
            rsub.configure(text=T("It takes a few seconds per provider. Your guide will be saved as: %s") % out_path(p))
            plabel.configure(text="")
            pbar["value"] = 0
            return
        fill_tiles(lb)
        if p.get("changed"):
            rtitle.configure(text="⚠  " + T("Your changes aren't in the guide yet — press “Build my guide”"), fg=P["warn"])
        else:
            rtitle.configure(text=T("Last build: %s") % nice_when(lb.get("when", ""), p), fg=P["text"])
        rsub.configure(text=out_path(p))
    pages["build"] = (pages["build"][0], build_status)

    build_seq = [0]

    def show_result(s):
        building[0] = False
        buildb.state(["!disabled"])
        stopb.pack_forget()
        pbar["value"] = pbar["maximum"]
        failed, stale = set(s.get("failed") or []), set(s.get("stale") or [])
        for s_ in steps[0]:
            if s.get("ok") and s_["name"] in stale:          # it failed today, but its last good listings are in
                s_["state"] = "warn"
            elif s_["state"] in ("run", "wait"):
                s_["state"] = "fail" if (s_["name"] in failed or not s.get("ok")) else "ok"
        draw_steps()
        if s.get("ok"):
            p["last_build"] = {k: s[k] for k in ("when", "channels", "programs", "size", "secs")}
            if int(p.get("change_n", 0)) == build_seq[0]:  # (something changed while it built: still "not built")
                p["changed"] = False
            la = p.get("last_auto") or {}
            if la:
                la["seen"] = True
                p["last_auto"] = la
            save_profile(p)
            fill_tiles(p["last_build"])
            plabel.configure(text=T("Done") + " ✔", fg=P["ok"])
            rtitle.configure(text="✔  " + T("Your guide is ready"), fg=P["ok"])
            sub = s["file"] + (("   ·   " + T(".gz copy saved too")) if s.get("gz") else "")
            if s.get("stale"):
                sub += "\n⚠  " + T("Today's update didn't work for %s, so their last good listings are in your guide (see the details below)") % \
                       ", ".join(s["stale"])
                log_toggle(True)
            if s.get("failed"):
                sub += "\n⚠  " + T("Not included this time: %s (see the details below)") % ", ".join(s["failed"])
                log_toggle(True)
            if s.get("notfound"):
                sub += "\nℹ  " + T("Some picked channels aren't in their lineup any more — open “Channels” for: %s") % \
                       ", ".join(sorted({n for n, _ in s["notfound"]}))
            rsub.configure(text=sub)
            flash(T("Guide built %s.") % nice_when(s["when"], p))
            side_status()
            if server.httpd:
                share_refresh()
            prev_rows.clear()
        else:
            plabel.configure(text=T("Not finished"), fg=P["err"])
            rtitle.configure(text="✖  " + T("The guide was not built"), fg=P["err"])
            rsub.configure(text=T("Look at the red lines in the details below."))
            log_toggle(True)

    def start_build(*_):
        if building[0]:
            return
        save_settings()
        if not p["lineups"] and not p.get("extras"):
            messagebox.showinfo(APP, T("Add a TV provider first."), parent=root)
            show("prov")
            return
        show("build")
        building[0] = True
        build_seq[0] = int(p.get("change_n", 0))
        cancel.clear()
        buildb.state(["disabled"])
        stopb.pack(side="left", padx=(10, 0), after=buildb)
        logt.configure(state="normal")
        logt.delete("1.0", "end")
        logt.configure(state="disabled")
        pbar["value"] = 0
        plabel.configure(text=T("Starting…"), fg=P["muted"])
        rtitle.configure(text=T("Building your guide…"), fg=P["text"])
        rsub.configure(text=T("This takes a few seconds per provider."))
        steps[0] = [{"name": x.get("name"), "label": x.get("name"), "state": "wait"} for x in p["lineups"] if x.get("enabled", True)] + \
                   [{"name": T(lbl).split(":")[0], "label": T(lbl).split(":")[0], "state": "wait"} for k, lbl, _ in EXTRAS
                    if k in p.get("extras", [])] + \
                   [{"name": g.get("name") or T("Guide"), "label": g.get("name") or T("Guide"), "state": "wait"}
                    for g in p.get("more_guides", []) if g.get("url") and g.get("on", True)] + \
                   [{"name": "", "label": T("Put it all together"), "state": "wait"}]
        draw_steps()
        spin_tick()

        def prog(i, n, label):
            def upd():
                pbar["maximum"] = n
                pbar["value"] = i - 0.5
                plabel.configure(text=label)
                for k, s_ in enumerate(steps[0]):
                    if k < i - 1 and s_["state"] in ("run", "wait"):
                        s_["state"] = "ok"
                    elif k == i - 1 and s_["state"] == "wait":
                        s_["state"] = "run"
                draw_steps()
            ui(upd)

        def go():
            s = build(p, say, cancel, prog, procbox)
            try:
                with open(LOGFILE, "a", encoding="utf-8") as f:
                    f.write("[%s] window build: %s\n" % (dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                                        "ok, %s channels" % s.get("channels") if s.get("ok") else "failed"))
            except OSError:
                pass
            return s
        work(go, show_result, lambda m: (say("✖ " + m, "err"), show_result({"ok": False})))

    def stop_build():
        cancel.set()
        pr = procbox[0]
        if pr:
            try:
                pr.terminate()
            except Exception:
                pass
        plabel.configure(text=T("Stopping…"))
    buildb.configure(command=start_build)
    stopb.configure(command=stop_build)
    root.bind_all("<Control-b>", start_build)
    root.bind_all("<Control-B>", start_build)

    # ====================================================================== #
    # What's on now (with logos)
    # ====================================================================== #
    nbody, nact = page("now", T("What's on now"), T("A quick look inside your guide file — what's on right now on each channel."),
                       lambda: preview())
    ttk.Button(nact, text=T("Refresh"), command=lambda: preview(force=True)).pack(side="left")
    sr = tk.Frame(nbody, bg=P["bg"])
    sr.pack(fill="x", pady=(0, 10))
    sv = tk.StringVar()
    ttk.Label(sr, text=T("Find")).pack(side="left")
    ttk.Entry(sr, textvariable=sv, width=30).pack(side="left", padx=8)
    pinfo = ttk.Label(sr, style="Muted.TLabel")
    pinfo.pack(side="left", padx=8)
    pf = card(nbody)
    pf.pack(fill="both", expand=True)
    pvf = tk.Frame(pf.body, bg=P["card"])
    pvf.pack(fill="both", expand=True, pady=4)
    pv = ttk.Treeview(pvf, columns=("ch", "now", "time", "next"), show="tree headings")
    pv.heading("#0", text="")
    pv.column("#0", width=72, minwidth=72, stretch=False)
    for c, txt, w in (("ch", T("CHANNEL"), 200), ("now", T("ON NOW"), 280), ("time", T("TIME"), 150), ("next", T("UP NEXT"), 280)):
        pv.heading(c, text=txt, anchor="w")
        pv.column(c, width=w, minwidth=80, stretch=(c in ("now", "next")))
    pv.tag_configure("odd", background=P["stripe"])
    pv.tag_configure("none", foreground=P["muted"])
    s4 = ttk.Scrollbar(pvf, command=pv.yview)
    pv.configure(yscrollcommand=s4.set)
    pv.pack(side="left", fill="both", expand=True)
    s4.pack(side="left", fill="y")
    prev_rows = []
    prev_mtime = [None]

    def preview(force=False):
        path = out_path(p)
        if not os.path.exists(path):
            prev_rows.clear()
            pfill()
            pinfo.configure(text=T("No guide yet — build it first."))
            return
        mt = os.path.getmtime(path)
        if prev_rows and not force and len(prev_mtime) > 1 and prev_mtime[0] == mt and time.time() - prev_mtime[1] < 120:
            pfill()
            return
        pinfo.configure(text=T("Reading…"))

        def done(res):
            rows, nprog = res
            prev_rows[:] = rows
            prev_mtime[:] = [mt, time.time()]
            pinfo.configure(text=T("%d channels · %s shows · file from %s") % (
                len(rows), "{:,}".format(nprog), nice_when(dt.datetime.fromtimestamp(mt).strftime("%Y-%m-%d %H:%M"), p)))
            pfill()
        work(lambda: on_now(path), done, lambda m: pinfo.configure(text=T("Could not read the guide:") + " " + m))

    def pfill(*_):
        pv.delete(*pv.get_children())
        ql = sv.get().strip().lower()
        k = 0
        for i, (name, logo, title, a, z, ntitle, na) in enumerate(prev_rows):
            if ql and ql not in ("%s %s %s" % (name, title or "", ntitle or "")).lower():
                continue
            iid = "r%d" % i

            def again(iid=iid, logo=logo):
                if pv.exists(iid):
                    pv.item(iid, image=logos.get(logo) or blank_tile)
            pv.insert("", "end", iid=iid, image=logo_or_wait(logo, again),
                      values=(name, title or "— " + T("no listing right now") + " —",
                              ("%s – %s" % (clock(a.astimezone(), p), clock(z.astimezone(), p))) if a else "",
                              ("%s  %s" % (clock(na.astimezone(), p), ntitle)) if ntitle else ""),
                      tags=(["odd"] if k % 2 else []) + ([] if title else ["none"]))
            k += 1
    sv.trace_add("write", pfill)

    # ====================================================================== #
    # Use on your TV (share on the home network)
    # ====================================================================== #
    server = GuideServer()
    shbody, _ = page("share", T("Use it on your TV"), T("Let your TV box (Firestick, Android TV, TiviMate…) load the guide "
                     "straight from this computer over your home network — no copying files."), lambda: share_refresh())
    shc = card(shbody)
    shc.pack(fill="x")
    shr = tk.Frame(shc.body, bg=P["card"])
    shr.pack(fill="x", padx=8, pady=12)
    sh_title = tk.Label(shr, text="", bg=P["card"], fg=P["text"], font=F["h"], anchor="w")
    sh_title.pack(side="left", fill="x", expand=True)
    urlc = card(shbody)
    url_lbl = tk.Label(urlc.body, text="", bg=P["card"], fg=P["accent"], font=F["url"], anchor="w")
    url_lbl.pack(fill="x", padx=8, pady=(12, 2))
    url2 = tk.Label(urlc.body, text="", bg=P["card"], fg=P["muted"], font=F["mid"], anchor="w", justify="left", wraplength=760)
    url2.pack(fill="x", padx=8)
    ub = tk.Frame(urlc.body, bg=P["card"])
    ub.pack(fill="x", padx=8, pady=(10, 12))
    ttk.Button(ub, text=T("Copy the address"), command=lambda: copy_text(url_lbl.cget("text"))).pack(side="left")
    howc = card(shbody)
    tk.Label(howc.body, text=T("How to add it on your TV box"), bg=P["card"], fg=P["text"], font=F["h"], anchor="w").pack(fill="x", padx=8, pady=(10, 4))
    how = tk.Label(howc.body, bg=P["card"], fg=P["text"], font=F["mid"], anchor="w", justify="left", wraplength=760)
    how.pack(fill="x", padx=8, pady=(0, 6))

    def link(parent, text, cmd, bg=None):
        l_ = tk.Label(parent, text=text, bg=bg or P["card"], fg=P["accent_text"], font=F["link"], anchor="w", justify="left",
                      cursor="hand2")
        l_.bind("<Button-1>", lambda e: cmd())
        return l_
    autowrap(link(howc.body, T("Step by step for your app — Plex, Jellyfin, Emby, Channels DVR, Kodi, xTeVe / Threadfin →"),
                  lambda: webbrowser.open(SETUP_URL)), pad=36)
    howc.body.winfo_children()[-1].pack(fill="x", padx=8, pady=(0, 12))

    nasc = card(shbody, border=P["accent"])
    nasc.pack(fill="x", pady=(12, 0))
    tk.Label(nasc.body, text=T("Run it 24/7 on your NAS"), bg=P["card"], fg=P["text"], font=F["h"],
             anchor="w").pack(fill="x", padx=8, pady=(10, 4))
    autowrap(tk.Label(nasc.body, text=T("Don't want to leave this computer on? The Guide Builder can live on your NAS, Raspberry Pi "
                                        "or home server — it updates your guide every day by itself, and you manage it from any "
                                        "browser, even your phone."),
                      bg=P["card"], fg=P["muted"], font=F["mid"], anchor="w", justify="left"), pad=36)
    nasc.body.winfo_children()[-1].pack(fill="x", padx=8)
    nchips = tk.Frame(nasc.body, bg=P["card"])
    nchips.pack(fill="x", padx=8, pady=(8, 4))
    for t_ in ("Synology", "QNAP", "Unraid", "Raspberry Pi", T("any Docker")):
        pill(nchips, t_, P["accent_soft"], P["accent_text"]).pack(side="left", padx=(0, 6))
    nbtn = tk.Frame(nasc.body, bg=P["card"])
    nbtn.pack(fill="x", padx=8, pady=(8, 12))
    ttk.Button(nbtn, text=T("Move to my NAS…"), style="Accent.TButton", command=lambda: move_to_nas()).pack(side="left")
    ttk.Button(nbtn, text=T("How to set it up"), command=lambda: webbrowser.open(NAS_URL)).pack(side="left", padx=8)

    def share_files():
        o = out_path(p)
        f_ = {"/guide.xml.gz": o + ".gz", "/guide.xml": o}
        if (p.get("playlist") or {}).get("share"):
            f_["/playlist.m3u"] = playlist_out(p)
        return f_

    def share_url():
        gz = os.path.exists(out_path(p) + ".gz")
        return "http://%s:%d/guide.xml%s" % (GuideServer.lan_ip(), server.port or 8765, ".gz" if gz else "")

    def share_refresh():
        on = server.httpd is not None
        for w in shr.winfo_children()[1:]:
            w.destroy()
        sh_title.configure(text=T("Sharing is ON") if on else T("Sharing is off"), fg=P["ok"] if on else P["text"])
        toggle_switch(shr, on, lambda: share_toggle(), P["card"]).pack(side="right")
        if on:
            url_lbl.configure(text=share_url())
            url2.configure(text=(T("You can close the window: sharing keeps running in the background (File → Quit stops it).")
                                 if p.get("close_mode", "background") == "background" else
                                 T("Keep this window open (minimized is fine) while your TV box updates its guide."))
                           + ("" if guide_exists() else "  ⚠ " + T("Build your guide first."))
                           + (("\n" + T("Your fixed playlist: %s") % "http://%s:%d/playlist.m3u" % (GuideServer.lan_ip(), server.port or 8765))
                              if (p.get("playlist") or {}).get("share") and os.path.exists(playlist_out(p)) else ""))
            how.configure(text=T("TiviMate: Settings → EPG → Add EPG source → paste or type the address above.\n"
                                 "IPTV Smarters and most other apps: look for “EPG” / “TV guide” / “XMLTV URL” "
                                 "in the playlist settings and enter the address.\n"
                                 "Tip: give this computer a fixed address in your router, so the address never changes.")
                          + ("\n" + T("Windows may ask once whether to allow network access — choose “Private networks”.")
                             if IS_WIN else ""))
            urlc.pack(fill="x", pady=(12, 0), before=nasc)
            howc.pack(fill="x", pady=(12, 0), before=nasc)
        else:
            urlc.pack_forget()
            howc.pack_forget()
        row, lbl, cv, kind = navs["share"]
        lbl.configure(text=T("Use on your TV") + ("  ●" if on else ""))

    def share_toggle():
        if server.httpd:
            server.stop()
            p["share"] = False
        else:
            try:
                server.start(share_files, int(p.get("share_port", 8765)))
                p["share"] = True
                p["share_port"] = server.port
            except Exception as ex:
                messagebox.showerror(APP, T("Could not start sharing:") + "\n\n%s" % ex, parent=root)
        save_profile(p)
        share_refresh()

    def move_to_nas():
        d = dialog(T("Move to my NAS"), "660x620")
        frm = ttk.Frame(d, padding=20)
        frm.pack(fill="both", expand=True)
        ttk.Label(frm, text=T("Move to my NAS"), font=F["title"]).pack(anchor="w")
        ttk.Label(frm, text=T("Your providers, channels, names and numbers go to the Guide Builder on your NAS in one go."),
                  style="Muted.TLabel", wraplength=600, justify="left").pack(anchor="w", pady=(4, 12))
        ttk.Label(frm, text=T("Your NAS address")).pack(anchor="w")
        r1 = ttk.Frame(frm)
        r1.pack(fill="x", pady=(4, 2))
        addr = ttk.Entry(r1)
        addr.insert(0, p.get("nas_addr") or "")
        addr.pack(side="left", fill="x", expand=True)
        chk = ttk.Button(r1, text=T("Check"))
        chk.pack(side="left", padx=(8, 0))
        found = tk.Label(frm, text=T("For example 192.168.1.50:8765 — the address you open the NAS page with."), bg=P["bg"],
                         fg=P["muted"], font=F["small"], anchor="w", justify="left", wraplength=600)
        found.pack(fill="x", pady=(2, 10))
        ttk.Label(frm, text=T("NAS password (only if you set one there)")).pack(anchor="w")
        pw = ttk.Entry(frm, show="•")
        pw.pack(fill="x", pady=(4, 10))
        logv = tk.BooleanVar(value=True)
        stopv = tk.BooleanVar(value=True)
        ttk.Checkbutton(frm, text=T("Also send my Schedules Direct login and playlist address"), variable=logv).pack(anchor="w", pady=2)
        ttk.Checkbutton(frm, text=T("Stop the daily update and sharing on this computer"), variable=stopv).pack(anchor="w", pady=(2, 0))
        tk.Label(frm, text=T("Your NAS does it from now on. You can turn them back on any time."), bg=P["bg"], fg=P["muted"],
                 font=F["small"], anchor="w", justify="left", wraplength=560).pack(fill="x", padx=(28, 0))
        lk = tk.Frame(frm, bg=P["bg"])
        lk.pack(fill="x", pady=(12, 0))
        link(lk, T("Not on your NAS yet? Set it up first →"), lambda: webbrowser.open(NAS_URL), P["bg"]).pack(anchor="w")
        link(lk, T("No NAS handy? Save a backup file instead…"), lambda: (d.destroy(), do_backup()), P["bg"]).pack(anchor="w", pady=(4, 0))
        bf = ttk.Frame(frm, padding=(0, 14, 0, 0))
        bf.pack(fill="x", side="bottom")
        go = ttk.Button(bf, text=T("Move to my NAS"), style="Accent.TButton")
        go.pack(side="right")
        ttk.Button(bf, text=T("Cancel"), command=d.destroy).pack(side="right", padx=8)

        def say(text, kind="muted"):
            if d.winfo_exists():
                found.configure(text=text, fg={"ok": P["ok"], "err": P["err"]}.get(kind, P["muted"]))

        def check():
            try:
                base = nas_base(addr.get())
            except RuntimeError as ex:
                say(str(ex), "err")
                return
            say(T("Looking…"))
            work(lambda: nas_check(base),
                 lambda r: say("✓ " + T("Found Guide Builder %s on your NAS") % r[0]
                               + (" · " + T("it asks for a password") if r[1] else ""), "ok"),
                 lambda m: say(m, "err"))
        chk.configure(command=check)
        addr.bind("<Return>", lambda e: check())

        def move():
            try:
                base = nas_base(addr.get())
            except RuntimeError as ex:
                say(str(ex), "err")
                return
            p["nas_addr"] = base.split("://", 1)[1]
            save_profile(p)
            go.state(["disabled"])
            chk.state(["disabled"])
            secret, with_login, stop_here = pw.get(), logv.get(), stopv.get()

            def run():
                ver = nas_move(base, secret, with_login, lambda t: ui(say, t))
                if stop_here:
                    try:
                        schedule_off()
                    except Exception:
                        pass
                return ver

            def done(ver):
                if stop_here:
                    if server.httpd:
                        server.stop()
                    p["share"] = False
                    p["moved_to_nas"] = base
                    save_profile(p)
                    share_refresh()
                    sched_refresh()
                if d.winfo_exists():
                    d.destroy()
                moved_done(base, stop_here)

            def fail(m):
                if d.winfo_exists():
                    go.state(["!disabled"])
                    chk.state(["!disabled"])
                    say(T("Problem:") + " " + m, "err")
            work(run, done, fail)
        go.configure(command=move)
        addr.focus_set()

    def moved_done(base, stopped):
        d = dialog(T("Move to my NAS"), "620x430")
        frm = ttk.Frame(d, padding=22)
        frm.pack(fill="both", expand=True)
        tk.Label(frm, text="✔", font=F["hello"], fg=P["ok"], bg=P["bg"]).pack()
        ttk.Label(frm, text=T("Your NAS has it now!"), font=F["title"]).pack(pady=(4, 6))
        n = len(p.get("lineups", []))
        lb = p.get("last_build") or {}
        txt = (T("1 provider moved.") if n == 1 else T("%d providers moved.") % n) + ((" " + T("About %d channels.") % lb["channels"]) if lb.get("channels") else "")
        txt += " " + (T("The daily update and sharing on this computer are off.") if stopped else
                      T("This computer keeps sharing too, until you turn it off."))
        txt += " " + T("Your NAS is building the guide now (a minute or two).")
        ttk.Label(frm, text=txt, style="Muted.TLabel", wraplength=560, justify="center").pack()
        ttk.Label(frm, text=T("Change the address in TiviMate (or your app) to:")).pack(anchor="w", pady=(16, 4))
        gaddr = base + "/guide.xml" + (".gz" if p.get("gzip", True) else "")
        r_ = tk.Frame(frm, bg=P["bg"])
        r_.pack(fill="x")
        tk.Label(r_, text=gaddr, bg=P["accent_soft"], fg=P["accent_text"], font=F["mono"], anchor="w", padx=10, pady=6).pack(
            side="left", fill="x", expand=True)
        ttk.Button(r_, text=T("Copy"), command=lambda: copy_text(gaddr)).pack(side="left", padx=(8, 0))
        bf = ttk.Frame(frm, padding=(0, 16, 0, 0))
        bf.pack(fill="x", side="bottom")
        ttk.Button(bf, text=T("Open my NAS page"), style="Accent.TButton",
                   command=lambda: (webbrowser.open(base), d.destroy())).pack(side="right")
        ttk.Button(bf, text=T("Close"), command=d.destroy).pack(side="right", padx=8)

    # ====================================================================== #
    # Daily update
    # ====================================================================== #
    sched_cache = [None]
    dbody, _ = page("daily", T("Daily update"), T("Build a fresh guide automatically once a day — even when this window is closed "
                    "(the computer must be on).") + " " + (T("Uses Windows Task Scheduler.") if IS_WIN else T("Uses cron.")),
                    lambda: sched_refresh())
    dc = card(dbody)
    dc.pack(fill="x")
    dr = tk.Frame(dc.body, bg=P["card"])
    dr.pack(fill="x", padx=8, pady=(12, 6))
    schs = tk.Label(dr, text="", bg=P["card"], fg=P["text"], font=F["h"], anchor="w")
    schs.pack(side="left", fill="x", expand=True)
    dr2 = tk.Frame(dc.body, bg=P["card"])
    dr2.pack(fill="x", padx=8, pady=(0, 12))
    ttk.Label(dr2, text=T("Every day at"), style="Card.TLabel").pack(side="left")
    st0 = p.get("schedule_time", "04:30")
    timev = tk.StringVar(value=clock(dt.datetime.combine(dt.date.today(), dt.time(*[int(x) for x in st0.split(":")])), p))
    ttk.Entry(dr2, textvariable=timev, width=9).pack(side="left", padx=8)
    ttk.Label(dr2, text=T("(for example 4:30 AM)") if p.get("clock", "12") != "24" else T("(for example 04:30)"),
              style="CardMuted.TLabel").pack(side="left", padx=(0, 10))
    onb = ttk.Button(dr2, text=T("Turn on daily update"), style="Accent.TButton")
    onb.pack(side="left", padx=(6, 0))
    offb = ttk.Button(dr2, text=T("Turn off"))
    offb.pack(side="left", padx=8)
    lastc = card(dbody)
    lastc.pack(fill="x", pady=(12, 0))
    lastl = tk.Label(lastc.body, text="", bg=P["card"], fg=P["muted"], font=F["mid"], anchor="w", justify="left", wraplength=780)
    lastl.pack(fill="x", padx=8, pady=12)

    def sched_refresh():
        def done(s):
            sched_cache[0] = s
            if s and ":" in s:
                t = dt.datetime.combine(dt.date.today(), dt.time(*[int(x) for x in s.split(":")]))
                schs.configure(text="✔  " + T("Daily update is ON (%s)") % clock(t, p), fg=P["ok"])
            else:
                schs.configure(text=("✔  " + T("Daily update is ON")) if s else T("Daily update is off"), fg=P["ok"] if s else P["text"])
            lb = load_profile().get("last_build")
            la = p.get("last_auto") or {}
            txt = (T("Last build: %s · %s channels · %s shows") % (nice_when(lb.get("when"), p), lb.get("channels"),
                                                                            "{:,}".format(lb.get("programs", 0)))) if lb else T("No build yet.")
            if la:
                txt += "\n" + (T("Last automatic update: %s — %s") % (
                    nice_when(la.get("when", ""), p), T("OK") if la.get("ok") and not la.get("failed") else T("problem (see Home)")))
            txt += "\n" + T("Results of automatic builds are in the log (File → Open the log). Every build has several days of "
                            "listings, so once a day is plenty.")
            lastl.configure(text=txt)
            if current_page[0] == "home":
                home_refresh()
        work(schedule_status, done, lambda m: schs.configure(text=T("Could not check:") + " " + m))

    def sched_on():
        t = parse_time(timev.get())
        if not t:
            messagebox.showinfo(APP, T("Type a time like 4:30 AM or 18:00."), parent=root)
            return
        p["schedule_time"] = t
        save_profile(p)
        work(lambda: schedule_on(t), lambda _: (sched_refresh(), flash(T("Daily update set for %s.") % timev.get().strip())),
             lambda m: messagebox.showerror(APP, T("Could not set the daily update:") + "\n\n" + m, parent=root))
    onb.configure(command=sched_on)
    offb.configure(command=lambda: work(schedule_off, lambda _: sched_refresh()))

    # ====================================================================== #
    # TV guide (a real guide grid, with search)
    # ====================================================================== #
    gbody, gact = page("guide", T("TV guide"), None, lambda: grid_show())
    G = {"chans": [], "by": {}, "key": None, "top": 0, "t0": None, "hits": [], "names": {}, "results": []}
    RH, CW = 46, 190                                  # row height, channel column width
    gbar = tk.Frame(gbody, bg=P["bg"])
    gbar.pack(fill="x", pady=(0, 8))
    g_chips = {}

    def g_round(t):
        return t.replace(minute=0 if t.minute < 30 else 30, second=0, microsecond=0)

    def g_jump(kind):
        now = dt.datetime.now().astimezone()
        if kind == "now":
            G["t0"] = g_round(now) - dt.timedelta(minutes=30)
        elif kind == "tonight":
            G["t0"] = now.replace(hour=19, minute=30, second=0, microsecond=0)
        elif kind == "tomorrow":
            G["t0"] = (now + dt.timedelta(days=1)).replace(hour=19, minute=30, second=0, microsecond=0)
        G["mode"] = kind
        g_draw()

    def g_shift(mins):
        G["t0"] = (G["t0"] or g_round(dt.datetime.now().astimezone())) + dt.timedelta(minutes=mins)
        G["mode"] = ""
        g_draw()
    for k_, t_ in (("now", T("Now")), ("tonight", T("Tonight")), ("tomorrow", T("Tomorrow"))):
        b_ = ttk.Button(gbar, text=t_, style="Chip.TButton", command=lambda k=k_: g_jump(k))
        b_.pack(side="left", padx=(0, 4))
        g_chips[k_] = b_
    ttk.Button(gbar, text="‹", style="Chip.TButton", command=lambda: g_shift(-90)).pack(side="left", padx=(8, 2))
    ttk.Button(gbar, text="›", style="Chip.TButton", command=lambda: g_shift(90)).pack(side="left")
    g_day = tk.Label(gbar, text="", bg=P["bg"], fg=P["text"], font=F["h"])
    g_day.pack(side="left", padx=12)
    gq = tk.StringVar()
    g_ent = ttk.Entry(gbar, textvariable=gq, width=26)
    g_ent.pack(side="right")
    tk.Label(gbar, text="🔍", bg=P["bg"], fg=P["muted"], font=F["mid"]).pack(side="right", padx=(0, 4))
    gwrap = tk.Frame(gbody, bg=P["border"])
    gwrap.pack(fill="both", expand=True)
    ghead = tk.Canvas(gwrap, height=28, bg=P["card"], highlightthickness=0)
    ghead.pack(fill="x", padx=1, pady=(1, 0))
    gmid = tk.Frame(gwrap, bg=P["card"])
    gmid.pack(fill="both", expand=True, padx=1, pady=(0, 1))
    gcv = tk.Canvas(gmid, bg=P["card"], highlightthickness=0, cursor="hand2")
    gsb = ttk.Scrollbar(gmid, orient="vertical")
    gsb.pack(side="right", fill="y")
    gcv.pack(side="left", fill="both", expand=True)
    g_note = tk.Label(gbody, text="", bg=P["bg"], fg=P["muted"], font=F["small"], anchor="w")
    g_note.pack(fill="x", pady=(6, 0))
    g_res = tk.Listbox(gbody, font=F["mid"], activestyle="none", bg=P["card"], fg=P["text"], highlightthickness=1,
                       highlightbackground=P["accent"], selectbackground=P["sel"], selectforeground=P["text"], relief="flat", height=10)
    DAYS = [T("Monday"), T("Tuesday"), T("Wednesday"), T("Thursday"), T("Friday"), T("Saturday"), T("Sunday")]

    def g_dayname(t):
        today = dt.date.today()
        d_ = t.date()
        if d_ == today:
            return T("Today")
        if d_ == today + dt.timedelta(days=1):
            return T("Tomorrow")
        if d_ == today - dt.timedelta(days=1):
            return T("Yesterday")
        return "%s %d/%d" % (DAYS[d_.weekday()], d_.month, d_.day) if p.get("clock", "12") == "12" else \
               "%s %d.%d." % (DAYS[d_.weekday()], d_.day, d_.month)

    g_fitmemo = {}

    def g_fit(text, font, width):
        """Shortens a title to fit a box. Measuring text is slow, so it's estimated from the average
        letter width (checked once) and remembered."""
        if width <= 8:
            return ""
        key = (text, str(font), int(width) // 4)
        if key in g_fitmemo:
            return g_fitmemo[key]
        avg = g_fitmemo.get(("avg", str(font))) or font.measure("abcdefghijklmnopqrstuvwxyz ABCDEFGHIJ") / 37.0
        g_fitmemo[("avg", str(font))] = avg
        n = int(width / avg)
        if len(text) <= n * 0.85 or font.measure(text) <= width:
            out = text
        else:
            n = max(0, int(n * 0.92) - 1)
            out = text[:n].rstrip() + "…" if n else ""
            while out and font.measure(out) > width and n > 0:
                n -= 2
                out = text[:max(0, n)].rstrip() + "…" if n > 0 else ""
        if len(g_fitmemo) > 20000:
            g_fitmemo.clear()
        g_fitmemo[key] = out
        return out

    def g_rows_visible():
        return max(1, gcv.winfo_height() // RH)

    def g_scroll_set():
        n = max(1, len(G["chans"]))
        vis = g_rows_visible()
        gsb.set(G["top"] / n, min(1.0, (G["top"] + vis) / n))

    def g_scroll(*a):
        n = len(G["chans"])
        vis = g_rows_visible()
        if a[0] == "moveto":
            G["top"] = int(float(a[1]) * n)
        elif a[0] == "scroll":
            G["top"] += int(a[1]) * (vis if a[2] == "pages" else 1)
        G["top"] = max(0, min(G["top"], max(0, n - vis)))
        g_draw()
    gsb.configure(command=g_scroll)

    def g_wheel(e):
        if getattr(e, "num", 0) == 4 or getattr(e, "delta", 0) > 0:
            step = -3
        else:
            step = 3
        if e.state & 0x0001:                           # Shift + wheel: move through time
            g_shift(30 if step > 0 else -30)
        else:
            g_scroll("scroll", step, "units")
        return "break"
    for ev in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
        gcv.bind(ev, g_wheel)

    def g_draw(*_):
        gcv.delete("all")
        ghead.delete("all")
        G["hits"] = []
        W, H = gcv.winfo_width(), gcv.winfo_height()
        if W < 300:
            return
        if not G["chans"]:
            gcv.create_text(W // 2, 60, text=G.get("msg") or T("Reading your guide…"), fill=P["muted"], font=F["mid"])
            return
        if G["t0"] is None:
            G["t0"] = g_round(dt.datetime.now().astimezone()) - dt.timedelta(minutes=30)
            G["mode"] = "now"
        t0 = G["t0"]
        span = 180 if W - CW >= 760 else 120
        t1 = t0 + dt.timedelta(minutes=span)
        ppm = (W - CW) / float(span)
        for k_, b_ in g_chips.items():
            b_.configure(style="ChipOn.TButton" if G.get("mode") == k_ else "Chip.TButton")
        g_day.configure(text=g_dayname(t0))
        for i in range(0, span + 1, 30):              # time ruler
            x = CW + i * ppm
            tt = t0 + dt.timedelta(minutes=i)
            ghead.create_line(x, 18, x, 28, fill=P["border_strong"])
            if i < span:
                ghead.create_text(x + 6, 14, text=clock(tt, p), anchor="w", fill=P["muted"], font=F["mono"] if P["tech"] else F["small"])
        n_vis = H // RH + 1
        bold, small = F["bold"], F["small"]
        now = dt.datetime.now().astimezone()
        for r in range(n_vis):
            ix = G["top"] + r
            if ix >= len(G["chans"]):
                break
            cid, name, logo = G["chans"][ix]
            y = r * RH
            gcv.create_rectangle(0, y, CW, y + RH, fill=P["stripe"], outline="")
            gcv.create_line(0, y + RH - 1, W, y + RH - 1, fill=P["border"])

            def setimg(ix=ix):
                if current_page[0] == "guide" and G["top"] <= ix < G["top"] + g_rows_visible() + 1:
                    g_draw()
            gcv.create_image(8, y + RH // 2, image=logo_or_wait(logo, setimg) if logo else blank_tile, anchor="w")
            gcv.create_text(74, y + RH // 2, text=g_fit(name, small, CW - 82), anchor="w", fill=P["text"], font=small)
            for a, b, title, sa in G["by"].get(cid, []):
                if b <= t0:
                    continue
                if a >= t1:
                    break
                x0 = CW + max(0.0, (a - t0).total_seconds() / 60.0) * ppm
                x1 = CW + min(float(span), (b - t0).total_seconds() / 60.0) * ppm
                if x1 - x0 < 3:
                    continue
                on = a <= now < b
                gcv.create_rectangle(x0 + 2, y + 4, x1 - 2, y + RH - 5, fill=P["accent_soft"] if on else P["card"],
                                     outline=P["accent"] if on else P["border"])
                tx = x0 + 8 if a >= t0 else x0 + 8
                txt = ("‹ " if a < t0 else "") + (title or "—")
                gcv.create_text(tx, y + 15, text=g_fit(txt, bold, x1 - x0 - 14), anchor="w", fill=P["text"], font=bold)
                sub = "%s – %s" % (clock(a.astimezone(), p), clock(b.astimezone(), p))
                gcv.create_text(tx, y + 31, text=g_fit(sub, small, x1 - x0 - 14), anchor="w", fill=P["muted"], font=small)
                G["hits"].append((x0, y, x1, y + RH, cid, sa, name, logo))
        if t0 <= now < t1:                             # the "now" line
            x = CW + (now - t0).total_seconds() / 60.0 * ppm
            gcv.create_line(x, 0, x, H, fill=P["accent"], width=2)
            ghead.create_polygon(x - 5, 22, x + 5, 22, x, 28, fill=P["accent"], outline="")
        g_scroll_set()

    gcv.bind("<Configure>", g_draw)

    def g_click(e):
        if g_res.winfo_ismapped():
            g_res.place_forget()                       # a click on the grid closes the search results
            return
        for x0, y0, x1, y1, cid, sa, name, logo in G["hits"]:
            if x0 <= e.x <= x1 and y0 <= e.y <= y1:
                g_details(cid, sa, name, logo)
                return
    gcv.bind("<Button-1>", g_click)

    def g_details(cid, sa, name, logo):
        path = out_path(p)

        def show_(d0):
            if not d0:
                return
            d_ = dialog(d0.get("title") or T("Show"))
            fr_ = tk.Frame(d_, bg=P["bg"])
            fr_.pack(fill="both", expand=True, padx=22, pady=18)
            top_ = tk.Frame(fr_, bg=P["bg"])
            top_.pack(fill="x")
            tk.Label(top_, image=logos.get(logo) or blank_tile, bg=P["bg"]).pack(side="left")
            tk.Label(top_, text="  " + name, bg=P["bg"], fg=P["muted"], font=F["mid"]).pack(side="left")
            tk.Label(fr_, text=d0.get("title", ""), bg=P["bg"], fg=P["text"], font=F["title"], anchor="w", justify="left",
                     wraplength=560).pack(fill="x", pady=(12, 0))
            a_ = xml_time(sa)
            meta = []
            if a_:
                b_ = next((b for a, b, t, s_ in G["by"].get(cid, []) if s_ == sa), None)
                meta.append("%s · %s%s" % (g_dayname(a_.astimezone()), clock(a_.astimezone(), p),
                                           " – " + clock(b_.astimezone(), p) if b_ else ""))
            if d0.get("ep"):
                meta.append(d0["ep"])
            tags = [T("NEW")] if d0.get("new") else []
            tags += [T("LIVE")] if d0.get("live") else []
            if tags:
                meta.append(" ".join(tags))
            tk.Label(fr_, text="   ·   ".join(meta), bg=P["bg"], fg=P["accent_text"], font=F["bold"], anchor="w").pack(fill="x", pady=(4, 0))
            if d0.get("sub"):
                tk.Label(fr_, text=d0["sub"], bg=P["bg"], fg=P["text"], font=F["h"], anchor="w", justify="left",
                         wraplength=560).pack(fill="x", pady=(10, 0))
            if d0.get("desc"):
                tk.Label(fr_, text=d0["desc"], bg=P["bg"], fg=P["text"], font=F["mid"], anchor="w", justify="left",
                         wraplength=560).pack(fill="x", pady=(8, 0))
            if d0.get("cats"):
                tk.Label(fr_, text=" · ".join(d0["cats"]), bg=P["bg"], fg=P["muted"], font=F["small"], anchor="w").pack(fill="x", pady=(10, 0))
            ttk.Button(fr_, text=T("Close"), command=d_.destroy).pack(anchor="e", pady=(16, 0))
            d_.bind("<Escape>", lambda e: d_.destroy())
        work(lambda: programme_details(path, cid, sa), show_, lambda m: None)

    def g_search(*_):
        q = gq.get().strip().lower()
        if G.get("ph") and q == G["ph"].lower():
            q = ""
        if len(q) < 2 or not G["chans"]:
            g_res.place_forget()
            return
        now = dt.datetime.now().astimezone() - dt.timedelta(hours=1)
        out = []
        rq = re.compile(r"(?<![a-z0-9])" + re.escape(q))          # at the start of a word: "lions" finds Lions, not Billions
        for cid, name, logo in G["chans"]:
            for a, b, title, sa in G["by"].get(cid, []):
                if b > now and title and q in title.lower() and rq.search(title.lower()):
                    out.append((a, cid, sa, name, logo, title))
        out.sort(key=lambda x: x[0])
        out = out[:300]
        G["results"] = out
        g_res.delete(0, "end")
        if not out:
            g_res.insert("end", "  " + T("No shows found for “%s”") % gq.get().strip())
        for a, cid, sa, name, logo, title in out:
            la = a.astimezone()
            g_res.insert("end", "  %s %s   ·   %s   ·   %s" % (g_dayname(la), clock(la, p), name, title))
        g_res.place(in_=gwrap, relx=1.0, x=-2, y=0, anchor="ne", width=min(620, max(300, gwrap.winfo_width() - 4)))
        g_res.lift()

    def g_pick(*_):
        sel = g_res.curselection()
        if not sel or sel[0] >= len(G["results"]):
            return
        a, cid, sa, name, logo, title = G["results"][sel[0]]
        g_res.place_forget()
        G["t0"] = g_round(a.astimezone()) - dt.timedelta(minutes=30)
        G["mode"] = ""
        ix = next((i for i, c in enumerate(G["chans"]) if c[0] == cid), 0)
        G["top"] = max(0, ix - g_rows_visible() // 2)
        g_draw()
        g_details(cid, sa, name, logo)
    g_res.bind("<ButtonRelease-1>", g_pick)
    g_res.bind("<Return>", g_pick)
    g_after = [None]

    def g_typed(*_):
        if g_after[0]:
            root.after_cancel(g_after[0])
        g_after[0] = root.after(350, g_search)
    gq.trace_add("write", g_typed)
    g_ent.bind("<Return>", g_search)
    g_ent.bind("<Escape>", lambda e: (gq.set(""), g_res.place_forget()))
    G["ph"] = T("Find a show…")

    def g_ph_show(*_):
        if not gq.get():
            g_ent.configure(foreground=P["muted"])
            gq.set(G["ph"])

    def g_ph_hide(*_):
        if gq.get() == G["ph"]:
            gq.set("")
            g_ent.configure(foreground=P["text"])
    g_ent.bind("<FocusIn>", g_ph_hide)
    g_ent.bind("<FocusOut>", g_ph_show)
    g_ph_show()

    def grid_show():
        path = out_path(p)
        if not guide_exists():
            G["chans"], G["msg"] = [], T("No guide yet — build it first.")
            g_draw()
            return
        st_ = os.stat(path)
        key = (path, st_.st_mtime, st_.st_size)
        if key == G["key"] and G["chans"]:
            g_draw()
            return
        G["msg"] = T("Reading your guide…")
        g_draw()

        def done(res):
            G["chans"], G["by"] = res
            G["key"] = key
            G["top"] = min(G["top"], max(0, len(G["chans"]) - 1))
            g_note.configure(text=T("%s channels · click a show for details · Shift + mouse wheel moves through time")
                             % "{:,}".format(len(G["chans"])))
            g_draw()

        def fail(m):
            G["msg"] = T("Could not read the guide:") + " " + m
            g_draw()
        work(lambda: guide_grid_data(path), done, fail)

    # ====================================================================== #
    # Your playlist (matches an IPTV playlist to the guide)
    # ====================================================================== #
    plbody, plact = page("list", T("Your playlist"), T("Load your IPTV playlist: each channel is matched to your guide, so your app "
                                                        "shows the guide on every channel. The playlist stays on this computer."),
                         lambda: pl_show())
    ttk.Button(plact, text=T("Load a file…"), command=lambda: pl_load_file()).pack(side="left", padx=(0, 8))
    ttk.Button(plact, text=T("Load from a web address…"), command=lambda: pl_load_url()).pack(side="left", padx=(0, 8))
    ttk.Button(plact, text=T("Save fixed playlist"), style="Accent.TButton", command=lambda: pl_save()).pack(side="left")
    PL = {"entries": [], "res": [], "idx": None, "src": "", "loaded": False}
    pl_info = tk.Label(plbody, text="", bg=P["bg"], fg=P["muted"], font=F["mid"], anchor="w", justify="left")
    pl_info.pack(fill="x", pady=(0, 8))
    plbar = tk.Frame(plbody, bg=P["bg"])
    plbar.pack(fill="x", pady=(0, 8))
    plq = tk.StringVar()
    ttk.Entry(plbar, textvariable=plq, width=24).pack(side="left")
    plf = tk.StringVar(value="all")
    pl_chips = {}
    for key_, lab_ in (("all", T("All")), ("ok", T("Matched")), ("check", T("Check these")), ("none", T("No guide"))):
        b_ = ttk.Button(plbar, text=lab_, style="Chip.TButton", command=lambda k=key_: (plf.set(k), pl_fill()))
        b_.pack(side="left", padx=(8 if key_ == "all" else 4, 0))
        pl_chips[key_] = b_
    plc = card(plbody)
    plc.pack(fill="both", expand=True)
    plt_f = tk.Frame(plc.body, bg=P["card"])
    plt_f.pack(fill="both", expand=True, pady=4)
    plt = ttk.Treeview(plt_f, columns=("pl", "guide", "st"), show="headings", selectmode="extended")
    for c_, t_, w_ in (("pl", T("YOUR PLAYLIST"), 300), ("guide", T("GUIDE CHANNEL"), 320), ("st", "", 120)):
        plt.heading(c_, text=t_, anchor="w")
        plt.column(c_, width=w_, anchor="w", stretch=(c_ != "st"))
    plt.tag_configure("ok", foreground=P["ok"])
    plt.tag_configure("check", foreground=P["warn"])
    plt.tag_configure("none", foreground=P["muted"])
    pls = ttk.Scrollbar(plt_f, command=plt.yview)
    plt.configure(yscrollcommand=pls.set)
    plt.pack(side="left", fill="both", expand=True)
    pls.pack(side="left", fill="y")
    plb = tk.Frame(plbody, bg=P["bg"])
    plb.pack(fill="x", pady=(10, 0), side="bottom", before=plc)
    r1_ = tk.Frame(plb, bg=P["bg"])
    r1_.pack(fill="x")
    ttk.Button(r1_, text="✔ " + T("Accept the suggestions shown"), style="Chip.TButton", command=lambda: pl_accept()).pack(side="left")
    ttk.Button(r1_, text=T("Pick a guide channel…"), style="Chip.TButton", command=lambda: pl_pick()).pack(side="left", padx=6)
    ttk.Button(r1_, text=T("No guide for these"), style="Chip.TButton", command=lambda: pl_set_selected("-")).pack(side="left")
    r2_ = tk.Frame(plb, bg=P["bg"])
    r2_.pack(fill="x", pady=(8, 0))
    pl_saved = tk.Label(plb, text="", bg=P["bg"], fg=P["muted"], font=F["small"], anchor="w", justify="left")
    pl_saved.pack(fill="x", pady=(4, 0))
    pl0 = p.get("playlist") or {}
    pl_auto = tk.BooleanVar(value=pl0.get("auto", True))
    pl_chno = tk.BooleanVar(value=pl0.get("chno", False))
    pl_share = tk.BooleanVar(value=pl0.get("share", False))

    def pl_opts():
        if p.get("playlist"):
            p["playlist"].update(auto=pl_auto.get(), chno=pl_chno.get(), share=pl_share.get())
            save_profile(p)
            share_refresh()
    for v_, t_ in ((pl_auto, T("Make it again with every build")), (pl_chno, T("Add channel numbers (tvg-chno)")),
                   (pl_share, T("Share it on the TV address too"))):
        ttk.Checkbutton(r2_, text=t_, variable=v_, command=pl_opts).pack(anchor="w", pady=1)

    def pl_label(gid):
        ch = PL["idx"]["ch"].get(gid) if PL["idx"] and gid else None
        if not ch:
            return ""
        return ch["label"] + ("  · " + ch["num"] if ch["num"] else "")

    def pl_fill(*_):
        plt.delete(*plt.get_children())
        q = plq.get().strip().lower()
        fl = plf.get()
        cnt_ = {"ok": 0, "check": 0, "none": 0}
        for n_, (e_, gid, st_) in enumerate(PL["res"]):
            cnt_[st_] += 1
            if fl != "all" and st_ != fl:
                continue
            if q and q not in e_["title"].lower() and q not in pl_label(gid).lower():
                continue
            plt.insert("", "end", iid=str(n_), tags=(st_,), values=(
                e_["title"], pl_label(gid), {"ok": "✔ " + T("Matched"), "check": "? " + T("Check"), "none": "✖ " + T("No guide")}[st_]))
        for k_, b_ in pl_chips.items():
            b_.configure(text={"all": T("All"), "ok": "● %d %s" % (cnt_["ok"], T("matched")),
                               "check": "● %d %s" % (cnt_["check"], T("check these")),
                               "none": "● %d %s" % (cnt_["none"], T("no guide"))}[k_],
                         style="ChipOn.TButton" if plf.get() == k_ else "Chip.TButton")
    plq.trace_add("write", pl_fill)

    def pl_rematch():
        PL["res"] = m3u_results(PL["entries"], PL["idx"], pl_picks())

    def pl_picks():
        if (p.get("playlist") or {}).get("src") == PL["src"]:
            return p["playlist"].setdefault("picks", {})
        return PL.setdefault("picks", {})

    def pl_load(src, label):
        if not guide_exists():
            messagebox.showinfo(APP, T("Build your guide first: the playlist is matched to the channels in it."), parent=root)
            return
        pl_info.configure(text=T("Reading your playlist…"))
        plt.delete(*plt.get_children())

        def go():
            entries = m3u_parse(m3u_read(src))
            return entries, guide_index(out_path(p))

        def done(res):
            PL["entries"], PL["idx"] = res
            PL["src"], PL["label"], PL["loaded"] = src, label, True
            if (p.get("playlist") or {}).get("src") != src:
                PL["picks"] = {}
            pl_rematch()
            live = len(PL["res"])
            pl_info.configure(text=T("%s · %s live channels") % (label, "{:,}".format(live))
                              + ("  (" + T("%s movies and series skipped") % "{:,}".format(len(PL["entries"]) - live) + ")"
                                 if len(PL["entries"]) > live else ""))
            pl_fill()
            pl_status()

        def fail(m):
            pl_info.configure(text="✖ " + T("Couldn't read the playlist: %s") % m)
        work(go, done, fail)

    def pl_load_file():
        f_ = filedialog.askopenfilename(parent=root, title=T("Choose your IPTV playlist"),
                                        filetypes=[(T("Playlist"), "*.m3u *.m3u8 *.m3u.gz"), (T("All files"), "*.*")])
        if f_:
            pl_load(f_, os.path.basename(f_))

    def pl_load_url():
        d_ = dialog(T("Load from a web address"))
        fr_ = ttk.Frame(d_, padding=20)
        fr_.pack(fill="both", expand=True)
        ttk.Label(fr_, text=T("Your playlist's web address (from your IPTV provider)")).pack(anchor="w")
        en_ = ttk.Entry(fr_, width=60, show="•")
        en_.pack(fill="x", pady=(6, 4))
        ttk.Label(fr_, style="Muted.TLabel", wraplength=520, justify="left",
                  text=T("It usually contains your IPTV login, so it's hidden here, kept on this computer only and never "
                         "shown, logged or sent anywhere else.")).pack(anchor="w")

        def go_(*_):
            u = en_.get().strip()
            if not re.match(r"https?://", u):
                messagebox.showinfo(APP, T("Paste an address that starts with http:// or https://"), parent=d_)
                return
            d_.destroy()
            import urllib.parse
            pl_load(u, T("from %s") % (urllib.parse.urlsplit(u).hostname or T("the web")))
        bf_ = ttk.Frame(fr_, padding=(0, 14, 0, 0))
        bf_.pack(fill="x")
        ttk.Button(bf_, text=T("Load"), style="Accent.TButton", command=go_).pack(side="right")
        ttk.Button(bf_, text=T("Cancel"), command=d_.destroy).pack(side="right", padx=8)
        en_.bind("<Return>", go_)
        en_.focus_set()

    def pl_selected():
        return [PL["res"][int(i)] for i in plt.selection()]

    def pl_set(rows_, gid):
        pk = pl_picks()
        for e_, _, _ in rows_:
            pk[m3u_key(e_)] = gid
        pl_rematch()
        pl_fill()
        if p.get("playlist"):
            save_profile(p)

    def pl_set_selected(gid):
        if not plt.selection():
            messagebox.showinfo(APP, T("Select one or more channels in the list first."), parent=root)
            return
        pl_set(pl_selected(), gid)

    def pl_accept():
        shown = [PL["res"][int(i)] for i in plt.get_children() if PL["res"][int(i)][2] == "check"]
        if not shown:
            messagebox.showinfo(APP, T("There are no suggestions in the list right now."), parent=root)
            return
        pk = pl_picks()
        for e_, gid, _ in shown:
            pk[m3u_key(e_)] = gid
        pl_rematch()
        pl_fill()
        if p.get("playlist"):
            save_profile(p)
        flash(T("Accepted %d suggestions.") % len(shown))

    def pl_pick(*_):
        sel = pl_selected()
        if not sel:
            messagebox.showinfo(APP, T("Select one or more channels in the list first."), parent=root)
            return
        d_ = dialog(T("Pick a guide channel"), "560x560")
        fr_ = ttk.Frame(d_, padding=16)
        fr_.pack(fill="both", expand=True)
        ttk.Label(fr_, text=(sel[0][0]["title"] if len(sel) == 1 else T("%d channels") % len(sel)), font=F["h"]).pack(anchor="w")
        qv_ = tk.StringVar()
        qe_ = ttk.Entry(fr_, textvariable=qv_)
        qe_.pack(fill="x", pady=(8, 6))
        lf_ = ttk.Frame(fr_)
        lf_.pack(fill="both", expand=True)
        lb_ = listbox(lf_)
        sb_ = ttk.Scrollbar(lf_, command=lb_.yview)
        lb_.configure(yscrollcommand=sb_.set)
        lb_.pack(side="left", fill="both", expand=True)
        sb_.pack(side="left", fill="y")
        allc = sorted(PL["idx"]["ch"], key=lambda c: pl_label(c).lower())
        shown_ = []

        def refill(*_):
            q = qv_.get().strip().lower()
            lb_.delete(0, "end")
            shown_.clear()
            for c in allc:
                lab = pl_label(c)
                if not q or q in lab.lower() or q in " ".join(PL["idx"]["ch"][c]["names"]).lower():
                    shown_.append(c)
                    lb_.insert("end", "  " + lab)
                    if len(shown_) >= 3000:
                        break
        qv_.trace_add("write", refill)
        qv_.set(ch_norm(sel[0][0]["title"]).split(" ")[0] if len(sel) == 1 else "")
        refill()

        def ok_(*_):
            if not lb_.curselection():
                messagebox.showinfo(APP, T("Pick a channel from the list first."), parent=d_)
                return
            pl_set(sel, shown_[lb_.curselection()[0]])
            d_.destroy()
        lb_.bind("<Double-1>", ok_)
        bf_ = ttk.Frame(fr_, padding=(0, 12, 0, 0))
        bf_.pack(fill="x", side="bottom", before=lf_)
        ttk.Button(bf_, text=T("Use this channel"), style="Accent.TButton", command=ok_).pack(side="right")
        ttk.Button(bf_, text=T("Cancel"), command=d_.destroy).pack(side="right", padx=8)
        ttk.Button(bf_, text=T("No guide for this"), command=lambda: (pl_set(sel, "-"), d_.destroy())).pack(side="left")
        qe_.focus_set()
    plt.bind("<Double-1>", pl_pick)

    def pl_save():
        if not PL["loaded"]:
            messagebox.showinfo(APP, T("Load your playlist first."), parent=root)
            return
        pk = dict(pl_picks())
        p["playlist"] = {"src": PL["src"], "label": PL.get("label", ""), "picks": pk, "auto": pl_auto.get(),
                         "chno": pl_chno.get(), "share": pl_share.get(), "out": (p.get("playlist") or {}).get("out", "")}
        PL.pop("picks", None)
        try:
            n_ = m3u_write(playlist_out(p), PL["entries"], PL["res"], PL["idx"], pl_chno.get())
        except OSError as ex:
            messagebox.showerror(APP, T("Couldn't save the playlist:") + "\n\n%s" % ex, parent=root)
            return
        save_profile(p)
        pl_status()
        share_refresh()
        flash(T("Saved: %d of %d live channels have a guide.") % (n_, len(PL["res"])))

    def pl_status():
        o_ = playlist_out(p)
        if (p.get("playlist") or {}).get("src") and os.path.exists(o_):
            pl_saved.configure(text=T("Saved as %s") % o_)
        else:
            pl_saved.configure(text="")

    def pl_show():
        pl_status()
        pl0_ = p.get("playlist") or {}
        if not PL["loaded"] and pl0_.get("src") and guide_exists():
            pl_load(pl0_["src"], pl0_.get("label") or os.path.basename(pl0_["src"]))
        elif not PL["loaded"]:
            pl_info.configure(text=T("Load your playlist with the buttons at the top right.") if guide_exists()
                              else T("Build your guide first: the playlist is matched to the channels in it."))
            pl_fill()

    # ====================================================================== #
    # Settings
    # ====================================================================== #
    sbody, _ = page("set", T("Settings"), T("How your guide file is made. Changes are saved straight away."), scroll=True)
    V = {k: tk.BooleanVar(value=bool(p.get(k, DEFAULTS.get(k)))) for k in ("gzip", "utf8", "utc", "name_first", "net_names", "tag_new", "tag_live")}
    outv = tk.StringVar(value=p.get("output", "guide.xml"))
    daysv = tk.IntVar(value=int(p.get("days", 7)))
    exv = {k: tk.BooleanVar(value=k in p.get("extras", [])) for k, _, _ in EXTRAS}
    SETKEYS = ("gzip", "utf8", "utc", "name_first", "net_names", "tag_new", "tag_live", "output", "days", "extras")

    def save_settings(*_):
        before = json.dumps({k: p.get(k) for k in SETKEYS}, sort_keys=True)
        for k, v in V.items():
            p[k] = v.get()
        p["output"] = outv.get().strip() or "guide.xml"
        try:
            p["days"] = max(1, min(14, int(daysv.get())))
        except (tk.TclError, ValueError):
            pass
        p["extras"] = [k for k, v in exv.items() if v.get()]
        changed = json.dumps({k: p.get(k) for k in SETKEYS}, sort_keys=True) != before
        if changed:
            p["changed"] = True
            p["change_n"] = int(p.get("change_n", 0)) + 1
        save_profile(p)
        if changed:
            side_status()

    def section(title):
        c = card(sbody)
        c.pack(fill="x", pady=(0, 12), padx=(0, 10))
        tk.Label(c.body, text=title, bg=P["card"], fg=P["text"], font=F["h"], anchor="w").pack(fill="x", padx=8, pady=(10, 6))
        inner = tk.Frame(c.body, bg=P["card"])
        inner.pack(fill="x", padx=8, pady=(0, 12))
        return inner

    g1 = section(T("Your guide file"))
    r1 = tk.Frame(g1, bg=P["card"])
    r1.pack(fill="x")
    ttk.Label(r1, text=T("Save the guide as"), style="Card.TLabel").pack(side="left")
    ttk.Entry(r1, textvariable=outv, width=56).pack(side="left", padx=8, fill="x", expand=True)

    def browse():
        f = filedialog.asksaveasfilename(parent=root, initialfile=os.path.basename(out_path(p)), initialdir=os.path.dirname(out_path(p)),
                                         defaultextension=".xml", filetypes=[(T("XMLTV guide"), "*.xml"), (T("All files"), "*.*")])
        if f:
            outv.set(f)
            save_settings()
    ttk.Button(r1, text=T("Browse…"), command=browse).pack(side="left")
    r2 = tk.Frame(g1, bg=P["card"])
    r2.pack(fill="x", pady=(10, 6))
    ttk.Label(r2, text=T("Days of listings"), style="Card.TLabel").pack(side="left")
    ttk.Spinbox(r2, from_=1, to=14, width=5, textvariable=daysv, command=save_settings).pack(side="left", padx=8)
    ttk.Label(r2, text=T("7 is a good choice; more days = bigger file"), style="CardMuted.TLabel").pack(side="left")
    for k, txt in (("gzip", T("Also save a compressed copy (.xml.gz) — smaller, most IPTV apps can read it")),
                   ("net_names", T("Network names (“NBC (WDIV)” instead of “WDIVDT”) for channels you haven't renamed")),
                   ("utf8", T("UTF-8 text (recommended: accents and symbols come out right)")),
                   ("name_first", T("Channel name first (“FOX 2” rather than “2 FOX”)")),
                   ("utc", T("Times in UTC (only if your app shows the wrong times)")),
                   ("tag_new", T("Add “ [NEW]” to the titles of new episodes")),
                   ("tag_live", T("Add “ [LIVE]” to the titles of live shows"))):
        ttk.Checkbutton(g1, text=txt, variable=V[k], command=save_settings, style="Card.TCheckbutton").pack(anchor="w", pady=3)
    outv.trace_add("write", save_settings)

    g2 = section(T("Add ready-made EPGTalk guides (optional, free)"))
    ex_side = {}

    def pick_pill_text(key):
        picked, total = pick_summary(key)
        if picked is None:
            return T("all %d channels") % total if total else T("all channels")
        return T("%d of %d channels") % (picked, total) if total else T("%d channels") % picked

    def ex_refresh():
        for k_, (pl, bt) in ex_side.items():
            pl.pack_forget()
            bt.pack_forget()
            if exv[k_].get():
                key = pick_key_extra(k_)
                picked, _ = pick_summary(key)
                pl.configure(text=" %s " % pick_pill_text(key), bg=P["accent_soft"] if picked is not None else P["tile_off"],
                             fg=P["accent_text"] if picked is not None else P["muted"])
                bt.pack(side="right")
                pl.pack(side="right", padx=(0, 10))
    for k, txt, _ in EXTRAS:
        er = tk.Frame(g2, bg=P["card"])
        er.pack(fill="x", pady=2)
        ttk.Checkbutton(er, text=T(txt), variable=exv[k], command=lambda: (save_settings(), ex_refresh()),
                        style="Card.TCheckbutton").pack(side="left")
        ex_side[k] = (pill(er, "", P["tile_off"], P["muted"]),
                      ttk.Button(er, text=T("Channels"), command=lambda k=k: edit_pick(pick_key_extra(k))))
    ex_tip = tk.Frame(g2, bg=P["accent_soft"])
    ex_tip.pack(fill="x", pady=(10, 2))
    tk.Frame(ex_tip, bg=P["accent"], width=3).pack(side="left", fill="y")
    tk.Label(ex_tip, text=T("Tip: click “Channels” to keep just what you watch — like your own teams, or a few Pluto channels. "
                            "A smaller guide loads much faster on a Firestick."),
             bg=P["accent_soft"], fg=P["text"], font=F["small"], anchor="w", justify="left", wraplength=760).pack(
        side="left", fill="x", padx=10, pady=6)
    ex_refresh()

    gm = section(T("More guides (any XMLTV address)"))
    gm_list = tk.Frame(gm, bg=P["card"])
    gm_list.pack(fill="x")

    def gm_fill():
        for w in gm_list.winfo_children():
            w.destroy()
        for g in p.get("more_guides", []):
            r_ = tk.Frame(gm_list, bg=P["card"])
            r_.pack(fill="x", pady=2)
            tk.Label(r_, text=g.get("name") or guide_name(g["url"]), bg=P["card"], fg=P["text"], font=F["mid"], anchor="w").pack(side="left")
            if g.get("channels"):
                tk.Label(r_, text="✔ " + T("%d channels") % g["channels"], bg=P["card"], fg=P["ok"], font=F["small"]).pack(side="left", padx=10)
            ttk.Button(r_, text=T("Remove"), style="Chip.TButton", command=lambda g=g: gm_remove(g)).pack(side="right")
            key = pick_key_more(g["url"])
            ttk.Button(r_, text=T("Channels"), style="Chip.TButton", command=lambda key=key: edit_pick(key)).pack(side="right", padx=6)
            picked, _ = pick_summary(key)
            pill(r_, pick_pill_text(key), P["accent_soft"] if picked is not None else P["tile_off"],
                 P["accent_text"] if picked is not None else P["muted"]).pack(side="right", padx=(0, 4))
        if not p.get("more_guides"):
            tk.Label(gm_list, text=T("Add any XMLTV guide from the internet: it's downloaded with every build and merged into yours."),
                     bg=P["card"], fg=P["muted"], font=F["small"], anchor="w", justify="left").pack(fill="x")

    def gm_remove(g):
        forget_pick(pick_key_more(g.get("url", "")))
        p["more_guides"] = [x for x in p.get("more_guides", []) if x is not g]
        mark_changed()
        gm_fill()

    gm_row = tk.Frame(gm, bg=P["card"])
    gm_row.pack(fill="x", pady=(8, 0))
    gm_ent = ttk.Entry(gm_row)
    gm_ent.pack(side="left", fill="x", expand=True)
    gm_note = tk.Label(gm, text="", bg=P["card"], fg=P["muted"], font=F["small"], anchor="w")
    gm_note.pack(fill="x", pady=(4, 0))

    def gm_add():
        url = gm_ent.get().strip()
        if not re.match(r"https?://", url):
            gm_note.configure(text=T("Paste a guide address that starts with http:// or https://"), fg=P["err"])
            return
        if any(g["url"] == url for g in p.get("more_guides", [])):
            gm_note.configure(text=T("That guide is already in the list."), fg=P["warn"])
            return
        gm_note.configure(text=T("Checking the guide…"), fg=P["muted"])
        gm_btn.state(["disabled"])

        def go():
            dst = fetch_guide(url, max_age=0)
            return len(engine().read_include(dst)[0])

        def done(n):
            gm_btn.state(["!disabled"])
            if not n:
                gm_note.configure(text=T("That guide has no channels."), fg=P["err"])
                return
            p.setdefault("more_guides", []).append({"url": url, "name": guide_name(url), "channels": n, "on": True})
            mark_changed()
            gm_ent.delete(0, "end")
            gm_note.configure(text="✔ " + T("Added: %d channels. It's merged in from your next build.") % n, fg=P["ok"])
            gm_fill()

        def fail(m):
            gm_btn.state(["!disabled"])
            gm_note.configure(text="✖ " + T("Couldn't load that guide: %s") % m, fg=P["err"])
        work(go, done, fail)
    gm_btn = ttk.Button(gm_row, text="+ " + T("Add guide"), style="Accent.TButton", command=gm_add)
    gm_btn.pack(side="left", padx=(8, 0))
    gm_ent.bind("<Return>", lambda e: gm_add())
    gm_fill()

    g3 = section(T("Schedules Direct account (only if you use one)"))
    r3 = tk.Frame(g3, bg=P["card"])
    r3.pack(fill="x")
    ttk.Label(r3, text=T("Username"), style="Card.TLabel").pack(side="left")
    ue = ttk.Entry(r3, width=22)
    ue.insert(0, login_user())
    ue.pack(side="left", padx=(6, 16))
    ttk.Label(r3, text=T("Password"), style="Card.TLabel").pack(side="left")
    pe = ttk.Entry(r3, width=18, show="•")
    pe.pack(side="left", padx=6)
    sdst = ttk.Label(g3, style="CardMuted.TLabel",
                     text=(T("Saved on this computer only.") if has_login() else T("Not set.")))
    sdst.pack(anchor="w", pady=(10, 0))

    def save_sd():
        if not ue.get().strip() or not pe.get():
            messagebox.showinfo(APP, T("Type your username and password."), parent=root)
            return
        save_login(ue.get(), pe.get())
        pe.delete(0, "end")
        sdst.configure(text=T("Saved. Checking with Schedules Direct…"))
        work(lambda: len(sd_client("us").account_lineups),
             lambda n: sdst.configure(text="✔ " + T("Login works. %d lineup(s) on your account. Saved on this computer only.") % n),
             lambda m: sdst.configure(text="✖ " + m))
    ttk.Button(r3, text=T("Save and test"), command=save_sd).pack(side="left", padx=10)

    g4 = section(T("Look, language and clock"))
    clockv = tk.StringVar(value=p.get("clock", "12"))

    def radio_row(parent, label, var, opts, cmd):
        r = tk.Frame(parent, bg=P["card"])
        r.pack(fill="x", pady=4)
        tk.Label(r, text=label, bg=P["card"], fg=P["text"], width=14, anchor="w").pack(side="left")
        for txt, val in opts:
            ttk.Radiobutton(r, text=txt, variable=var, value=val, style="Card.TRadiobutton",
                            command=lambda val=val: cmd(val)).pack(side="left", padx=(0, 16))
    radio_row(g4, T("Language"), langv, (("English", "en"), ("Español", "es")), lambda v: restart_with("lang", v))
    radio_row(g4, T("Look"), themev, ((T("Light"), "light"), (T("Dark"), "dark")), lambda v: restart_with("theme", v))
    radio_row(g4, T("Text size"), tsize, ((T("Normal"), 1.0), (T("Large"), 1.25), (T("Extra large"), 1.5)), set_text)

    def set_clock(v):
        p["clock"] = v
        save_profile(p)
        side_status()
        prev_rows.clear()
        st0 = parse_time(timev.get()) or p.get("schedule_time", "04:30")
        timev.set(clock(dt.datetime.combine(dt.date.today(), dt.time(*[int(x) for x in st0.split(":")])), p))
        sched_refresh()
    radio_row(g4, T("Clock"), clockv, ((T("12-hour (9:45 PM)"), "12"), (T("24-hour (21:45)"), "24")), set_clock)

    gbk = section(T("Running in the background"))
    cmv = tk.StringVar(value=p.get("close_mode", "background"))

    def set_cm():
        p["close_mode"] = cmv.get()
        save_profile(p)
    for v_, t_ in (("background", T("When I close the window: keep sharing my guide in the background")),
                   ("quit", T("When I close the window: quit the app"))):
        ttk.Radiobutton(gbk, text=t_, variable=cmv, value=v_, command=set_cm, style="Card.TRadiobutton").pack(anchor="w", pady=2)
    asv = tk.BooleanVar(value=autostart_is_on())

    def set_as():
        want = asv.get()
        work(lambda: autostart_set(want), lambda _: flash(T("Starts with your computer.") if want else T("Doesn't start with your computer.")),
             lambda m: (asv.set(not want), messagebox.showerror(APP, m, parent=root)))
    ttk.Checkbutton(gbk, text=T("Start with my computer (in the background)"), variable=asv, command=set_as,
                    style="Card.TCheckbutton").pack(anchor="w", pady=(8, 2))
    tk.Label(gbk, text=T("In the background your TV box can load the guide any time, even with the window closed. "
                         "The app only stays open in the background while sharing is on."),
             bg=P["card"], fg=P["muted"], font=F["small"], anchor="w", justify="left", wraplength=760).pack(fill="x", pady=(6, 0))

    g5 = section(T("This app"))
    r5 = tk.Frame(g5, bg=P["card"])
    r5.pack(fill="x")
    ttk.Button(r5, text=T("Back up my settings…"), command=do_backup).pack(side="left")
    ttk.Button(r5, text=T("Restore from a backup…"), command=do_restore).pack(side="left", padx=8)
    tk.Label(g5, text=T("A backup keeps your providers, channels, your own names and settings in one file — "
                        "to keep it safe or move to a new computer."), bg=P["card"], fg=P["muted"], font=F["small"],
             anchor="w", justify="left", wraplength=760).pack(fill="x", pady=(8, 10))
    updv = tk.BooleanVar(value=bool(p.get("check_updates", True)))

    def set_upd():
        p["check_updates"] = updv.get()
        save_profile(p)
    ttk.Checkbutton(g5, text=T("Tell me when a new version is available (checks EPGTalk.com once a day)"), variable=updv,
                    command=set_upd, style="Card.TCheckbutton").pack(anchor="w", pady=3)
    r6 = tk.Frame(g5, bg=P["card"])
    r6.pack(fill="x", pady=(8, 0))
    if INSTALLED:
        tk.Label(r6, text=T("Installed — open it from your apps menu (search for “EPGTalk”). Your guide is saved in: %s") % GUIDE_DIR,
                 bg=P["card"], fg=P["muted"], font=F["small"], anchor="w", justify="left", wraplength=760).pack(fill="x")
    else:
        ttk.Button(r6, text=T("Add to my apps menu"), command=add_shortcut).pack(side="left")
        tk.Label(r6, text="  " + T("Start the builder like any other app."), bg=P["card"], fg=P["muted"], font=F["small"]).pack(side="left")
    tk.Label(g5, text="%s %s · %s" % (APP, VERSION, T("Made by aCiDjEsUs, a Hamtramck kid · EPGTalk.com")), bg=P["card"],
             fg=P["muted"], font=F["small"], anchor="w").pack(fill="x", pady=(12, 0))

    # ---------------- new version notice ----------------
    update_info = [None]

    def update_badge():
        up = update_info[0]
        if up and p.get("update_skip") != up.get("version"):
            upd_lbl.configure(text="✨ " + T("New version %s") % up.get("version") + "\n" + T("Click to see what's new"))
            upd_box.pack(fill="x", padx=12, pady=(0, 8), before=sbox)
            for w in (upd_box, upd_lbl):
                w.bind("<Button-1>", lambda e: show("home"))
        else:
            upd_box.pack_forget()

    def check_updates_bg(max_age=20 * 3600):
        def done(info):
            update_info[0] = info
            update_badge()
            if current_page[0] == "home":
                home_refresh()
        work(lambda: check_update(p, max_age), done, lambda m: None)

    def check_updates_later():                       # still running (e.g. sharing in the background): look again
        check_updates_bg()
        root.after(6 * 3600 * 1000, check_updates_later)

    # ---------------- one-click update ----------------
    def update_now(up):
        plan = update_plan(up)
        if not plan:
            webbrowser.open(up.get("page") or "https://epgtalk.com")
            return
        if building[0]:
            messagebox.showinfo(APP, T("Please wait until the guide is built, then update."), parent=root)
            return
        kind, url, sha = plan
        d = dialog(T("Updating"), "520x220")
        fr_ = tk.Frame(d, bg=P["bg"])
        fr_.pack(fill="both", expand=True, padx=22, pady=18)
        tk.Label(fr_, text=T("Updating to version %s…") % up.get("version"), bg=P["bg"], fg=P["text"], font=F["h"], anchor="w").pack(fill="x")
        pb_ = ttk.Progressbar(fr_, mode="determinate", maximum=100)
        pb_.pack(fill="x", pady=(14, 6))
        msg_ = tk.Label(fr_, text=T("Downloading…"), bg=P["bg"], fg=P["muted"], font=F["small"], anchor="w", justify="left", wraplength=470)
        msg_.pack(fill="x")
        tk.Label(fr_, text=T("Your providers and settings stay as they are."), bg=P["bg"], fg=P["muted"], font=F["small"],
                 anchor="w").pack(fill="x", pady=(4, 0))
        stop_ = threading.Event()
        cb_ = ttk.Button(fr_, text=T("Cancel"), command=lambda: (stop_.set(), d.destroy()))
        cb_.pack(anchor="e", pady=(12, 0))

        def prog(got, total):
            def upd():
                if d.winfo_exists():
                    if total:
                        pb_["value"] = got * 100.0 / total
                    msg_.configure(text=T("Downloading %s of %s MB…") % ("%.1f" % (got / 1e6), "%.1f" % (total / 1e6) if total else "?"))
            ui(upd)

        def go():
            path = update_download(url, sha, prog, stop_)
            ui(lambda: d.winfo_exists() and (msg_.configure(text=T("Installing… your computer may ask for your password.") if kind == "linux"
                                                                 else T("Installing… the app opens again by itself.")),
                                               cb_.state(["disabled"])))
            return update_install(kind, path)

        def done(res):
            if res == "restart":
                on_close()
            elif d.winfo_exists():
                msg_.configure(text=T("The installer is open: follow it, then start the app again."))

        def fail(m):
            if d.winfo_exists():
                cb_.state(["!disabled"])
                cb_.configure(text=T("Close"))
                msg_.configure(text="✖ " + T("The update didn't finish: %s") % m, fg=P["err"])
        work(go, done, fail)

    # ---------------- setup wizard (first start, or Help -> Setup wizard) ----------------
    def wizard():
        d = dialog(T("Set up your guide"), "780x580")
        p["wizard_seen"] = True
        save_profile(p)
        W = {"step": 0, "found": [], "item": None, "cc": "us", "zip": ""}
        names = [T("Welcome"), T("Where you live"), T("Provider"), T("Channels"), T("Your TV")]
        outer = tk.Frame(d, bg=P["bg"])
        outer.pack(fill="both", expand=True, padx=28, pady=20)
        dots = tk.Frame(outer, bg=P["bg"])
        dots.pack(fill="x")
        body = tk.Frame(outer, bg=P["bg"])
        body.pack(fill="both", expand=True, pady=(22, 0))
        navw = tk.Frame(outer, bg=P["bg"])
        navw.pack(fill="x", side="bottom", before=body, pady=(12, 0))
        backb = ttk.Button(navw, text=T("Back"), command=lambda: goto(W["step"] - 1))
        backb.pack(side="left")
        nextb = ttk.Button(navw, text=T("Next") + "  →", style="Accent.TButton", command=lambda: PAGES[W["step"]][1]())
        nextb.pack(side="right")
        skip = tk.Label(navw, text=T("Skip, I know my way around"), bg=P["bg"], fg=P["muted"], font=F["small"], cursor="hand2")
        skip.pack(side="right", padx=16)
        skip.bind("<Button-1>", lambda e: d.destroy())

        def draw_dots():
            for w in dots.winfo_children():
                w.destroy()
            for i, nm in enumerate(names):
                if i:
                    tk.Frame(dots, bg=P["border_strong"], height=1, width=22).pack(side="left", padx=6)
                c = tk.Canvas(dots, width=22, height=22, bg=P["bg"], highlightthickness=0)
                c.pack(side="left")
                on = i <= W["step"]
                c.create_oval(1, 1, 21, 21, fill=P["accent"] if on else P["border"], outline=P["accent"] if on else P["border_strong"])
                c.create_text(11, 11, text="✓" if i < W["step"] else str(i + 1), fill=P["on_accent"] if on else P["muted"], font=F["small"])
                tk.Label(dots, text=nm, bg=P["bg"], fg=P["text"] if i == W["step"] else P["muted"],
                         font=F["bold"] if i == W["step"] else F["small"]).pack(side="left", padx=(6, 0))

        def clear():
            for w in body.winfo_children():
                w.destroy()

        def heading(t, sub):
            tk.Label(body, text=t, bg=P["bg"], fg=P["text"], font=F["title"], anchor="w").pack(fill="x")
            tk.Label(body, text=sub, bg=P["bg"], fg=P["muted"], font=F["mid"], anchor="w", justify="left",
                     wraplength=700).pack(fill="x", pady=(4, 16))

        def note(t, col=None):
            lb = tk.Label(body, text=t, bg=P["bg"], fg=col or P["muted"], font=F["small"], anchor="w", justify="left", wraplength=700)
            lb.pack(fill="x", pady=(10, 0))
            return lb

        def goto(i):
            W["step"] = max(0, i)
            draw_dots()
            clear()
            nextb.configure(text=T("Next") + "  →")
            nextb.state(["!disabled"])
            backb.state(["disabled"] if W["step"] in (0, 4) else ["!disabled"])
            if W["step"] == 4:
                skip.pack_forget()
            elif not skip.winfo_ismapped():
                skip.pack(side="right", padx=16)
            PAGES[W["step"]][0]()

        # 1 - welcome
        def p_welcome():
            heading(T("Welcome to EPGTalk Guide Builder"),
                    T("In a few steps you'll have your own TV guide for your IPTV app, with listings and channel logos."))
            for n_, t_ in ((1, T("Tell us where you watch TV")), (2, T("Pick your TV provider and channels")),
                           (3, T("Get the address to type into your TV box"))):
                r_ = tk.Frame(body, bg=P["bg"])
                r_.pack(fill="x", pady=5)
                tk.Label(r_, text=str(n_), bg=P["accent_soft"], fg=P["accent_text"], font=F["bold"], width=3).pack(side="left")
                tk.Label(r_, text="  " + t_, bg=P["bg"], fg=P["text"], font=F["mid"]).pack(side="left")
            note(T("Free · made by aCiDjEsUs, a Hamtramck kid · EPGTalk.com"))
            nextb.configure(text=T("Let's start") + "  →")

        # 2 - where you live
        def p_where():
            heading(T("Where do you watch TV?"), T("Your zip / postal code finds the TV providers in your area. Nothing else is needed."))
            r_ = tk.Frame(body, bg=P["bg"])
            r_.pack(fill="x")
            tk.Label(r_, text=T("Country"), bg=P["bg"], fg=P["text"], font=F["mid"]).pack(side="left")
            W["country"] = ttk.Combobox(r_, state="readonly", width=18, values=[T(n_) for _, n_ in GN_COUNTRIES])
            W["country"].current([c for c, _ in GN_COUNTRIES].index(W["cc"]) if W["cc"] in [c for c, _ in GN_COUNTRIES] else 0)
            W["country"].pack(side="left", padx=(8, 20))
            tk.Label(r_, text=T("Zip / postal code"), bg=P["bg"], fg=P["text"], font=F["mid"]).pack(side="left")
            W["zipe"] = ttk.Entry(r_, width=12)
            W["zipe"].insert(0, W["zip"])
            W["zipe"].pack(side="left", padx=8)
            W["zipe"].focus_set()
            W["zipe"].bind("<Return>", lambda e: n_where())
            W["msg"] = note(T("Have a paid Schedules Direct account? Skip the wizard and add it under Providers."))

        def n_where():
            z = W["zipe"].get().strip()
            if not z:
                W["msg"].configure(text=T("Type your zip / postal code first."), fg=P["err"])
                return
            W["cc"], W["zip"] = GN_COUNTRIES[max(0, W["country"].current())][0], z
            W["msg"].configure(text=T("Looking for TV providers…"), fg=P["muted"])
            nextb.state(["disabled"])

            def done(res):
                if not d.winfo_exists():
                    return
                nextb.state(["!disabled"])
                if not res:
                    W["msg"].configure(text=T("Nothing found — check the zip / postal code and country."), fg=P["err"])
                    return
                W["found"] = res
                goto(2)

            def fail(m):
                if d.winfo_exists():
                    nextb.state(["!disabled"])
                    W["msg"].configure(text=T("Problem:") + " " + m, fg=P["err"])
            work(lambda: gn_providers(W["cc"], z), done, fail)

        # 3 - provider
        def p_provider():
            heading(T("Which one is yours?"), T("Pick your cable, satellite or streaming provider. Antenna or HDHomeRun? "
                                                "Pick “Local Over the Air Broadcast”."))
            lf_ = tk.Frame(body, bg=P["bg"])
            lf_.pack(fill="both", expand=True)
            W["lb"] = listbox(lf_)
            sb_ = ttk.Scrollbar(lf_, command=W["lb"].yview)
            W["lb"].configure(yscrollcommand=sb_.set)
            W["lb"].pack(side="left", fill="both", expand=True)
            sb_.pack(side="left", fill="y")
            for n_, _ in W["found"]:
                W["lb"].insert("end", "   " + n_)
            W["lb"].bind("<Double-1>", lambda e: n_provider())
            W["msg"] = note("")

        def n_provider():
            sel = W["lb"].curselection()
            if not sel:
                W["msg"].configure(text=T("Pick a provider from the list first."), fg=P["err"])
                return
            n_, lu = W["found"][sel[0]]
            if W["item"] is not None:                          # came back and picked another one
                p["lineups"] = [x for x in p["lineups"] if x["id"] != W["item"]["id"]]
                for f_ in lineup_files(W["item"]["id"]) + (tweak_file(W["item"]["id"]),):
                    try:
                        os.remove(f_)
                    except OSError:
                        pass
            lid = new_id()
            write_dat(lineup_files(lid)[0], lu)
            it = {"id": lid, "name": n_, "source": "gracenote", "country": W["cc"], "postal": W["zip"], "enabled": True}
            p["lineups"].append(it)
            W["item"] = it
            mark_changed()
            refresh_lineups()
            goto(3)

        # 4 - channels
        def p_channels():
            heading(T("Which channels?"), T("You can change this any time under Providers → Channels."))
            W["ch"] = tk.StringVar(value=W.get("chv", "all"))
            for v_, t_, sub_ in (("all", T("All channels"), T("Everything your provider has.")),
                                 ("main", T("Main stations only"), T("Leaves out the extra sub-channels (like 2.2, 4.3). Good for an antenna.")),
                                 ("pick", T("Let me pick them myself"), T("Opens the channel list with logos, to tick your favourites."))):
                fr_ = tk.Frame(body, bg=P["bg"])
                fr_.pack(fill="x", pady=4)
                ttk.Radiobutton(fr_, text=t_, variable=W["ch"], value=v_).pack(anchor="w")
                tk.Label(fr_, text=sub_, bg=P["bg"], fg=P["muted"], font=F["small"], anchor="w").pack(fill="x", padx=(28, 0))
            W["msg"] = note("")

        def n_channels():
            v = W["chv"] = W["ch"].get()
            it = W["item"]
            if v == "all":
                for f_ in lineup_files(it["id"])[1:]:
                    try:
                        os.remove(f_)
                    except OSError:
                        pass
                goto(4)
            elif v == "pick":
                d.grab_release()
                before = set(str(w) for w in root.winfo_children())
                edit_channels(it)
                new = [w for w in root.winfo_children() if str(w) not in before and isinstance(w, tk.Toplevel)]
                if new:
                    d.wait_window(new[-1])
                if d.winfo_exists():
                    modal(d)
                    goto(4)
            else:
                W["msg"].configure(text=T("Reading the channel list…"), fg=P["muted"])
                nextb.state(["disabled"])

                def go():
                    lu = read_dat(lineup_files(it["id"])[0])[0]
                    rows = channel_rows(it, lu, lambda lid: False)
                    keep = {i for i, r in enumerate(rows) if "." not in r["num"] or r["num"].endswith(".1")}
                    dat_, chl_, ren_ = lineup_files(it["id"])
                    save_channel_files(rows, keep, {}, chl_, ren_)
                    return len(keep)

                def done(n_):
                    if d.winfo_exists():
                        mark_changed()
                        refresh_lineups()
                        goto(4)

                def fail(m):
                    if d.winfo_exists():
                        nextb.state(["!disabled"])
                        W["msg"].configure(text=T("Problem:") + " " + m, fg=P["err"])
                work(go, done, fail)

        # 5 - build + your TV
        def p_tv():
            heading(T("Making your guide…"), T("This takes a few seconds."))
            pb_ = ttk.Progressbar(body, mode="indeterminate")
            pb_.pack(fill="x")
            pb_.start(12)
            nextb.configure(text=T("Finish"))
            nextb.state(["disabled"])
            start_build()
            d.lift()

            def wait():
                if not d.winfo_exists():
                    return
                if building[0]:
                    d.after(400, wait)
                    return
                clear()
                nextb.state(["!disabled"])
                lb_ = p.get("last_build") or {}
                if not guide_exists():
                    heading(T("The guide didn't finish"), T("Open “Build guide” to see what happened, or try again later."))
                    return
                heading("✔ " + T("Your guide is ready"), T("%s channels · %s shows. Now let your TV box load it from this computer:")
                        % (lb_.get("channels", "?"), "{:,}".format(lb_.get("programs", 0))))
                c_ = card(body)
                c_.pack(fill="x")
                inner = c_.body
                if not server.httpd:
                    share_toggle()
                if server.httpd:
                    tk.Label(inner, text=T("Type this address into your TV box:"), bg=P["card"], fg=P["muted"], font=F["small"],
                             anchor="w").pack(fill="x", padx=6, pady=(10, 2))
                    u_ = share_url()
                    rr = tk.Frame(inner, bg=P["card"])
                    rr.pack(fill="x", padx=6, pady=(0, 6))
                    tk.Label(rr, text=u_, bg=P["card"], fg=P["accent"], font=F["url"], anchor="w").pack(side="left")
                    ttk.Button(rr, text=T("Copy"), command=lambda: copy_text(u_)).pack(side="right")
                    tk.Label(inner, text=T("TiviMate: Settings → EPG → Add EPG source. Other apps: look for “EPG” or “XMLTV URL”."),
                             bg=P["card"], fg=P["text"], font=F["small"], anchor="w", justify="left", wraplength=660).pack(fill="x", padx=6, pady=(0, 10))
                W["daily"] = tk.BooleanVar(value=True)
                ttk.Checkbutton(body, text=T("Make a fresh guide every day at 4:30 AM (the computer must be on)"),
                                variable=W["daily"]).pack(anchor="w", pady=(14, 0))
                note(T("You can close the window: the guide keeps being shared in the background."))
            d.after(600, wait)

        def n_tv():
            if W.get("daily") is not None and W["daily"].get() and not sched_cache[0]:
                p["schedule_time"] = "04:30"
                save_profile(p)
                work(lambda: schedule_on("04:30"), lambda _: sched_refresh(), lambda m: None)
            d.destroy()
            show("home")

        PAGES = [(p_welcome, lambda: goto(1)), (p_where, n_where), (p_provider, n_provider), (p_channels, n_channels), (p_tv, n_tv)]
        goto(0)

    m_help.insert_command(0, label=T("Setup wizard…"), command=lambda: wizard())

    # ---------------- toast messages, closing, start ----------------
    toast = tk.Label(main, text="", bg=P["text"], fg=P["bg"], font=F["mid"], padx=16, pady=9)
    tid = [None]

    def flash(msg):
        toast.configure(text=msg)
        toast.place(relx=0.5, rely=1.0, y=-18, anchor="s")
        if tid[0]:
            root.after_cancel(tid[0])
        tid[0] = root.after(3500, toast.place_forget)

    def on_close(save=True):
        if save:
            try:
                try:
                    mx = root.state() == "zoomed" if IS_WIN else bool(root.attributes("-zoomed"))
                except tk.TclError:
                    mx = False
                p["window_max"] = mx
                if not mx:
                    p["window"] = root.geometry()
                p.pop("geometry", None)                 # older versions' value (placed wrong on Windows)
                save_settings()
            except Exception:
                pass
        if building[0]:
            stop_build()
        server.stop()
        try:
            if rsock is not None:
                rsock.close()
            with open(INSTANCE, encoding="utf-8") as fh:
                if json.load(fh).get("token") == rtoken:
                    os.remove(INSTANCE)
        except Exception:
            pass
        if tray_running() and (not result["restart"] or result.get("tray_too")):
            try:
                _WIN["tray"].terminate()
                _WIN["tray"].wait(timeout=3)
            except Exception:
                pass
            _WIN["tray"] = None
        try:
            logos.pool.shutdown(wait=False)
        except Exception:
            pass
        for aid in (pump_id[0], tid[0]):
            if aid:
                try:
                    root.after_cancel(aid)
                except Exception:
                    pass
        shapes_save()
        if result["restart"]:
            root.quit()                                # leave the window up: it's filled again in the new look
        else:
            _WIN["root"] = None
            root.destroy()
    # ---------------- one window, the tray icon, and running in the background ----------------
    import socket
    import secrets
    rtoken = secrets.token_hex(16)
    rsock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    hidden = [bool(background)]
    try:
        rsock.bind(("127.0.0.1", 0))                    # this computer only
        rsock.listen(5)
        with open(INSTANCE + ".tmp", "w", encoding="utf-8") as fh:
            json.dump({"port": rsock.getsockname()[1], "token": rtoken, "pid": os.getpid()}, fh)
        os.replace(INSTANCE + ".tmp", INSTANCE)
    except OSError:
        rsock = None

    def bring_back():
        hidden[0] = False
        try:
            root.deiconify()
            root.lift()
            root.attributes("-topmost", True)
            root.after(300, lambda: root.attributes("-topmost", False))
            root.focus_force()
        except tk.TclError:
            return
        if current_page[0] == "home":
            home_refresh()

    def remote_handle(c):
        try:
            c.settimeout(3)
            line = b""
            while not line.endswith(b"\n") and len(line) < 512:
                chunk = c.recv(256)
                if not chunk:
                    break
                line += chunk
            tok, _, cmd = line.decode("utf-8", "replace").strip().partition(" ")
            if tok != rtoken:
                return
            if cmd == "status":
                reply = json.dumps({"share": server.httpd is not None, "state": state(), "shown": not hidden[0]})
            else:
                reply = "ok"
                if cmd == "show":
                    ui(bring_back)
                elif cmd == "build":
                    ui(start_build)
                elif cmd == "copy":
                    ui(lambda: copy_text(share_url()) if server.httpd else None)
                elif cmd == "quit":
                    ui(lambda: on_close())
            c.sendall((reply + "\n").encode())
        except Exception:
            pass
        finally:
            try:
                c.close()
            except Exception:
                pass

    def remote_loop():
        while rsock is not None:
            try:
                c, _ = rsock.accept()
            except OSError:
                return
            threading.Thread(target=remote_handle, args=(c,), daemon=True).start()
    if rsock is not None:
        threading.Thread(target=remote_loop, daemon=True).start()

    def tray_running():
        return _WIN["tray"] is not None and _WIN["tray"].poll() is None

    def tray_start():
        if tray_running() or p.get("tray", True) is False or rsock is None:
            return                                     # one icon only: a look switch keeps the one that's there
        try:
            _WIN["tray"] = subprocess.Popen(run_args("--tray", str(os.getpid())), stdin=subprocess.DEVNULL,
                                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                            creationflags=0x08000000 if IS_WIN else 0)
        except OSError:
            _WIN["tray"] = None

    def on_window_close():
        if p.get("close_mode", "background") == "background" and server.httpd:
            if not p.get("bg_told"):
                p["bg_told"] = True
                save_profile(p)
                where = T("click the EPGTalk icon next to the clock, or open the app from your apps menu") if tray_running() \
                    else T("open the app again from your apps menu")
                messagebox.showinfo(APP, T("Your guide keeps being shared in the background, so your TV box can still load it.\n\n"
                                           "To open the window again: %s.\nTo quit completely: File → Quit.") % where, parent=root)
            try:
                p["window"] = root.geometry() if root.state() == "normal" else p.get("window")
                save_profile(p)
            except Exception:
                pass
            hidden[0] = True
            root.withdraw()
        else:
            on_close()
    root.protocol("WM_DELETE_WINDOW", on_window_close)
    root.bind_all("<F5>", lambda e: (preview(force=True) if current_page[0] == "now" else refresh_lineups() if current_page[0] == "prov"
                                     else home_refresh() if current_page[0] == "home" else None))
    if p.get("share"):
        try:
            server.start(share_files, int(p.get("share_port", 8765)))
        except Exception:
            pass
    side_status()
    share_refresh()
    show("home")
    sched_refresh()
    if not p["lineups"] and not p.get("wizard_seen") and not background:
        root.after(900, wizard)                      # first start: the setup wizard
    root.after(1500, tray_start)
    check_updates_bg(3 * 3600)                       # on opening: if the last look was over 3 hours ago
    root.after(6 * 3600 * 1000, check_updates_later)
    if not os.path.exists(ENGINE):
        messagebox.showerror(APP, T("%s was not found next to this program.\nPut both files in the same folder.") % os.path.basename(ENGINE),
                             parent=root)
    root.after(5000, shapes_save)                     # remember the rounded pictures for the next start
    if reuse:
        root.update_idletasks()
    root.mainloop()
    return "restart" if result["restart"] else None


ICON_PNG = (  # 48x48 app icon (the EPGTalk TV), base64 PNG
    "iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAI9UlEQVR42u2aa3BV1RXHf3ufx30lIQkmxIIQUqnKQxzHtiqV0Wql"
    "teogFGhtffQhKDq+qo5TtWOpFhUfjE4rKk4t4iB1qOMUFLGAVtAiENMKoqCYgIDmAUm4SS73nLNXP5wLMZRwcy8kU2fcMyfnQ/ZZ"
    "e/33Wuu/11r7KjdWIXyJh+ZLPuz8P1Vg6fBtApAcDakUaAsQCEz47jsACsRAsjlc2C0A2+k5CKXA9yC9J5QVLQKl8wKhco8BBRKA"
    "tgkmTYN+/bAWPgF76sF2s4NQCvw0lJQTTJkGLS1YLzwBxgdl5QwidwtYGpItBFffQzD9phDPkJHYt08KwWVVILSef9tjmPPPDafH"
    "CrHm3AkFJRAEvRzEEv6RyhPBB5oCpPy4cGdz8H8pPw6aAvAJZSF5hUEeLCRgR7CefRC1aSOgkUEDkdFnQXszWIcxqmVDewsyagwy"
    "8GugNGrTRqxnHwQ70lcxkPHjdAq0hTnlTPyH/4pqaca+6jxU/Q6IxENm6rJVFqQ7kGMq8J9ajpSUYt88GV29KiQEN5o7k+V9DoiA"
    "GwPHRb/zCva9NyFDBuD/di7YFgR+V5dSGarVCv+uuUhlBfYfbkavWQJuJJQl+dGoZTkFd+dHpRIuGi1Cvb8aVDHm0gmIeyz6jUXg"
    "xjuV0ja078a/cTYy5WL0449jzZ8JBQMylso/GTgCAF+MiRh67TLMcachky9B1SdRNSsgVhhSY1sDZvy1BLfejlr6Os7MaeHZwZFn"
    "Meqo5EJag7cPKeyHP2cZUlmFM/0S1LqVIeOcfAbenL+jdu3Ennoeqnl36DrG9CGAw9GkSIZhWpETT8V78mVUMol9+ViUtw9v3iqk"
    "rAxn2kWo/7wFiWIIvOwyjwoAbYXCjJ/9fLCd0F3OvwL/4SdRK1ejfA8z7mzs265HL54DifIwjch2bGi7M/jzBqA1tO0N3wVFoZIq"
    "CwjLhmQjwfT7CS6/JhSz8Bns2TdAon/PNkIByb3h3ETRYV2tewBKQ8dezBnnY34yHSkb0kPWzaQTxiDlQ0CBqt+eAX64VEMRpnOC"
    "YFCN29ALn0SvWgLxwm5BHBqAtqC9BXPWhfj3L4AYYdqQa7h7mbfTsxCToHN54wApsO+4Er18EcT7HdKdurGAApPG++Ny5NTR6KVL"
    "sF58PJP7SY+YFaU6g1QyZ4Y6tLsEIhgjDC8spD0w1Cab0eOnYi6agNq0GWfqWJCMvIOC2z7kVnhppLQcqaiEDsH6y0zUh2+BLsoa"
    "VDkm5mEyiuLpkaOY6EbpAH6/ZQuz5v4Ofc54TNlgpLQC9dn2kHpzS6c1BCpcyi6FWAzM0SuhLaVoT6f5ZeVQpgw/GZNKUWhbPHDa"
    "mbxcu52NaQ+t1RHWA/u/N0EYSEfh8Dk4RxoacRHfY1/gYZkAF2FAJMJGEVSWND2vZM6yLGzb7vJorTMBqLv9Xyc7h3OU1jiOwwsN"
    "9ewLAmKRKG4sTvWe3bzTvAdl21kNnnNFJgIdyT3AFwtxARXHjcVJJfcC6a4mVDGi8RjGBGhtk0p1QNB+wLxrOxr59vI2pp9wIrs9"
    "j8c2b6JtwKCMZDk6AJQCI4LjWFwz/deUlJRkAAmJRIKlr7zKGyuXMfnSnzJy1EgC38eybZoaG3ht2Qre37CBaKKQVLKFqmHDmDBx"
    "PKNGjUBbFrVb63j+xZe4et3aMEX3PRytu2xDt8ONVUiXJ36suE5/cQacJCxuFd4UcU74jkSsYrFjFVJYPFg2fbxDUkZk++ctsvXT"
    "RmlNGbnxlrsFkAUvLBERkQ8/2SnvfVgrSU9kV+NeOW/cREG5Mu6Hk6Vu125Jicjqte/J4lfflB0NrfL22g3iOP0lUTBIInapOENP"
    "E1Z4wrIOcQaNFtcuDXU7SN88XEhoaW5h584IZ3xrDJ/vrAMVIRpPAAU0NTaR9n1uu+V2Xlo0j+tuvIPHHrmHSVMmsXrVP5n10CxK"
    "Soq44mdXs/C5eYCPEy1hxIjhaMfFMyan4sbOnTgU2tJEolHuvOs3JJN7icVizJ37DBtq/oXtZAI3wx77WaS9vYOTRozmG8MGs3Ll"
    "Wyx8bgGxRCmDhwzEGENTUyOWZeH5ATm0B/JrbIkIltZ8/4JxiAgFiTiLFy9lAx62bZNMCTPuncGMe2cwdOhgGprbWTB/PqUlxTga"
    "mpp2owgoH1DG0tdeIRaL0JZsZ9z3fsBHH9US1ZqgtwCICFpp0uk0Y04fS/2uOsBFOxGgAM/zsS2oXlfN1q0f09LayvLXVvJezRq+"
    "efrZtHYEfP34KtxYAXV12/jRJVN4ePYsjh92PCaPMyYvCxgxKKU457tn01DfQDweZ/v2T/l39RpEDFEH5s17luWv/g1IgHaJJMqo"
    "eXc9K/7xOhMuOpdZD93Po7Mfpbb2YzzPJxaL/s950Wsx4DgOBQUJnnr6CUSgKAp/emo+1059g2g0ikZRXFyMZRUSLyzF8zwEgzHC"
    "DdfdgJhH+PmvruCyKy8j8AOMCVi/rpq2tja0ZSHZaoZ8AIiEyntpj19ceRWRSATfDxARHNuivqERJ9Kf++6bxdNz/8yWLR+h7Cjp"
    "dBrJsIrtRNmx8zMmTfwxo085maqqSowR6uq28cGmD/B8H8dxkJTXOxZQSmGMoWZd9UFptYDl4LoRNn+wmc3mfSw3imXZB5QPN8Hg"
    "RiIgQs36d6lZ/86BgsGJ7p/fBzEQTSQOGdwiQjQWzQCVLsofmJcJ1GgicYBiw29NOD+XHmuPARwk9HBsYYz0qOjJyjg9BGJnFSCE"
    "rULLDh91FNPp7mpxyw7XlOxg7O6UV54HQRpcAyVlsOVt8OJA0LsA0EAHFJ8CEQWtfqYNo3oIQAQcF/bsQm9ag6m6AP/6h9Bvjv2C"
    "7r11sZlRUhvMmIuhyEKvXYeq/xSiiUMWU910JTSkU8jASvwHFiHDK8ECFH03PFBbtmHfOhlVtxkisRwA7PfFfe1IaTnmwkuRgVUg"
    "fXQrqwxqxyfoJc+jGndBNB7eIeTVmfPSkE7S91fKJuxgO+5h63A7C9eF/U73mM47rN52owNrqM5GwhGdAyIhpf2fji/9Tw2+AvAV"
    "gCMc/wXwvfDIcMBCyAAAAABJRU5ErkJggg==")


# Spanish text for the window (View → Español). Keys are the English text.
ES.update({
    "You can close the window: sharing keeps running in the background (File → Quit stops it).":
        "Puedes cerrar la ventana: se sigue compartiendo en segundo plano (Archivo → Salir lo detiene).",
    "You can close the window: the guide keeps being shared in the background.": "Puedes cerrar la ventana: la guía se sigue compartiendo en segundo plano.",
    "Update now": "Actualizar ahora", "What's new": "Novedades", "Updating": "Actualizando", "Updating to version %s…": "Actualizando a la versión %s…",
    "Downloading…": "Descargando…", "Downloading %s of %s MB…": "Descargando %s de %s MB…",
    "Your providers and settings stay as they are.": "Tus proveedores y tu configuración se quedan igual.",
    "Installing… your computer may ask for your password.": "Instalando… tu computadora puede pedirte tu contraseña.",
    "Installing… the app opens again by itself.": "Instalando… la app se abre de nuevo sola.",
    "The installer is open: follow it, then start the app again.": "El instalador está abierto: síguelo y luego abre la app otra vez.",
    "The update didn't finish: %s": "La actualización no terminó: %s",
    "Please wait until the guide is built, then update.": "Espera a que la guía esté lista y luego actualiza.",
    "the download didn't match the published file, so it was not installed": "la descarga no coincide con el archivo publicado, así que no se instaló",
    "the package was not installed (%s)": "el paquete no se instaló (%s)",
    "Sharing on": "Compartiendo", "Sharing off": "Sin compartir", "guide ready": "guía lista", "changes not built yet": "cambios sin crear",
    "the last update failed": "la última actualización falló", "no guide yet": "aún no hay guía", "Open": "Abrir", "Build now": "Crear ahora",
    "Copy the TV address": "Copiar la dirección para la TV", "Quit": "Salir",
    "click the EPGTalk icon next to the clock, or open the app from your apps menu": "haz clic en el ícono de EPGTalk junto al reloj, o abre la app desde tu menú de aplicaciones",
    "open the app again from your apps menu": "abre la app otra vez desde tu menú de aplicaciones",
    "Your guide keeps being shared in the background, so your TV box can still load it.\n\nTo open the window again: %s.\nTo quit completely: File → Quit.":
        "Tu guía se sigue compartiendo en segundo plano, así tu TV box puede seguir cargándola.\n\nPara abrir la ventana otra vez: %s.\nPara salir del todo: Archivo → Salir.",
    "Running in the background": "Funcionando en segundo plano",
    "When I close the window: keep sharing my guide in the background": "Al cerrar la ventana: seguir compartiendo mi guía en segundo plano",
    "When I close the window: quit the app": "Al cerrar la ventana: salir de la app",
    "Start with my computer (in the background)": "Iniciar con mi computadora (en segundo plano)",
    "Starts with your computer.": "Se inicia con tu computadora.", "Doesn't start with your computer.": "No se inicia con tu computadora.",
    "In the background your TV box can load the guide any time, even with the window closed. The app only stays open in the background while sharing is on.":
        "En segundo plano tu TV box puede cargar la guía en cualquier momento, aunque la ventana esté cerrada. La app solo sigue abierta en segundo plano mientras compartes.",
    "TV guide": "Guía de TV", "Now": "Ahora", "Tonight": "Esta noche", "Tomorrow": "Mañana", "Today": "Hoy", "Yesterday": "Ayer",
    "Monday": "Lunes", "Tuesday": "Martes", "Wednesday": "Miércoles", "Thursday": "Jueves", "Friday": "Viernes",
    "Saturday": "Sábado", "Sunday": "Domingo", "Find a show…": "Buscar un programa…", "Show": "Programa", "NEW": "NUEVO",
    "LIVE": "EN VIVO", "Close": "Cerrar", "No shows found for “%s”": "No se encontraron programas para “%s”",
    "%s channels · click a show for details · Shift + mouse wheel moves through time":
        "%s canales · haz clic en un programa para ver detalles · Shift + rueda del ratón para moverte en el tiempo",
    "Set up your guide": "Configura tu guía", "Welcome": "Bienvenida", "Where you live": "Dónde vives", "Provider": "Proveedor",
    "Channels": "Canales", "Your TV": "Tu TV", "Back": "Atrás", "Next": "Siguiente", "Skip, I know my way around": "Saltar, ya sé usarlo",
    "Welcome to EPGTalk Guide Builder": "Bienvenido a EPGTalk Guide Builder",
    "In a few steps you'll have your own TV guide for your IPTV app, with listings and channel logos.":
        "En unos pasos tendrás tu propia guía de TV para tu app IPTV, con programación y logos de canales.",
    "Tell us where you watch TV": "Dinos dónde ves TV", "Pick your TV provider and channels": "Elige tu proveedor de TV y tus canales",
    "Get the address to type into your TV box": "Obtén la dirección para escribir en tu TV box",
    "Free · made by aCiDjEsUs, a Hamtramck kid · EPGTalk.com": "Gratis · hecho por aCiDjEsUs, un chico de Hamtramck · EPGTalk.com",
    "Let's start": "Empecemos", "Where do you watch TV?": "¿Dónde ves TV?",
    "Your zip / postal code finds the TV providers in your area. Nothing else is needed.":
        "Tu código postal encuentra los proveedores de TV de tu zona. No se necesita nada más.",
    "Have a paid Schedules Direct account? Skip the wizard and add it under Providers.":
        "¿Tienes una cuenta paga de Schedules Direct? Salta el asistente y agrégala en Proveedores.",
    "Looking for TV providers…": "Buscando proveedores de TV…", "Which one is yours?": "¿Cuál es el tuyo?",
    "Pick your cable, satellite or streaming provider. Antenna or HDHomeRun? Pick “Local Over the Air Broadcast”.":
        "Elige tu proveedor de cable, satélite o streaming. ¿Antena o HDHomeRun? Elige “Local Over the Air Broadcast”.",
    "Which channels?": "¿Qué canales?", "You can change this any time under Providers → Channels.":
        "Puedes cambiarlo cuando quieras en Proveedores → Canales.",
    "All channels": "Todos los canales", "Everything your provider has.": "Todo lo que tiene tu proveedor.",
    "Main stations only": "Solo las estaciones principales",
    "Leaves out the extra sub-channels (like 2.2, 4.3). Good for an antenna.": "Deja fuera los subcanales extra (como 2.2, 4.3). Bueno para antena.",
    "Let me pick them myself": "Quiero elegirlos yo", "Opens the channel list with logos, to tick your favourites.":
        "Abre la lista de canales con logos, para marcar tus favoritos.",
    "Reading the channel list…": "Leyendo la lista de canales…", "Making your guide…": "Creando tu guía…",
    "This takes a few seconds.": "Esto tarda unos segundos.", "Finish": "Terminar", "The guide didn't finish": "La guía no terminó",
    "Open “Build guide” to see what happened, or try again later.": "Abre “Crear guía” para ver qué pasó, o inténtalo más tarde.",
    "%s channels · %s shows. Now let your TV box load it from this computer:": "%s canales · %s programas. Ahora deja que tu TV box la cargue desde esta computadora:",
    "Type this address into your TV box:": "Escribe esta dirección en tu TV box:",
    "TiviMate: Settings → EPG → Add EPG source. Other apps: look for “EPG” or “XMLTV URL”.":
        "TiviMate: Ajustes → EPG → Agregar fuente EPG. Otras apps: busca “EPG” o “XMLTV URL”.",
    "Make a fresh guide every day at 4:30 AM (the computer must be on)": "Crear una guía nueva cada día a las 4:30 AM (la computadora debe estar encendida)",
    "Keep this app open (minimized is fine) so your TV box can load the guide.": "Deja esta app abierta (minimizada está bien) para que tu TV box pueda cargar la guía.",
    "Setup wizard…": "Asistente de configuración…",
    "Your playlist": "Tu lista", "Load a file…": "Cargar un archivo…", "Load from a web address…": "Cargar desde una dirección web…",
    "Save fixed playlist": "Guardar lista corregida",
    "Load your IPTV playlist: each channel is matched to your guide, so your app shows the guide on every channel. The playlist stays on this computer.":
        "Carga tu lista IPTV: cada canal se une a tu guía, para que tu app muestre la guía en todos los canales. La lista se queda en esta computadora.",
    "Matched": "Unido", "Check these": "Revisa estos", "No guide": "Sin guía", "YOUR PLAYLIST": "TU LISTA", "GUIDE CHANNEL": "CANAL DE LA GUÍA",
    "Accept the suggestions shown": "Aceptar las sugerencias mostradas", "Pick a guide channel…": "Elegir un canal de la guía…",
    "No guide for these": "Sin guía para estos", "Make it again with every build": "Hacerla de nuevo en cada creación",
    "Add channel numbers (tvg-chno)": "Agregar números de canal (tvg-chno)", "Share it on the TV address too": "Compartirla también en la dirección para la TV",
    "Check": "Revisar", "matched": "unidos", "check these": "por revisar", "no guide": "sin guía",
    "Build your guide first: the playlist is matched to the channels in it.": "Primero crea tu guía: la lista se une a sus canales.",
    "Reading your playlist…": "Leyendo tu lista…", "%s · %s live channels": "%s · %s canales en vivo",
    "%s movies and series skipped": "%s películas y series omitidas", "Couldn't read the playlist: %s": "No se pudo leer la lista: %s",
    "Choose your IPTV playlist": "Elige tu lista IPTV", "Playlist": "Lista", "Load from a web address": "Cargar desde una dirección web",
    "Your playlist's web address (from your IPTV provider)": "La dirección web de tu lista (de tu proveedor IPTV)",
    "It usually contains your IPTV login, so it's hidden here, kept on this computer only and never shown, logged or sent anywhere else.":
        "Normalmente contiene tu usuario IPTV, así que aquí se oculta, se guarda solo en esta computadora y nunca se muestra, registra ni envía a otro lugar.",
    "Paste an address that starts with http:// or https://": "Pega una dirección que empiece con http:// o https://",
    "from %s": "de %s", "the web": "internet", "Load": "Cargar",
    "Select one or more channels in the list first.": "Primero selecciona uno o más canales de la lista.",
    "There are no suggestions in the list right now.": "Ahora no hay sugerencias en la lista.", "Accepted %d suggestions.": "Se aceptaron %d sugerencias.",
    "Pick a guide channel": "Elige un canal de la guía", "Pick a channel from the list first.": "Primero elige un canal de la lista.",
    "Use this channel": "Usar este canal", "No guide for this": "Sin guía para este", "Load your playlist first.": "Primero carga tu lista.",
    "Couldn't save the playlist:": "No se pudo guardar la lista:", "Saved: %d of %d live channels have a guide.": "Guardada: %d de %d canales en vivo tienen guía.",
    "Saved as %s": "Guardada como %s", "Load your playlist with the buttons at the top right.": "Carga tu lista con los botones de arriba a la derecha.",
    "Your fixed playlist: %s": "Tu lista corregida: %s", "Your playlist was not updated: %s": "Tu lista no se actualizó: %s",
    "Playlist updated: %d of %d live channels have a guide": "Lista actualizada: %d de %d canales en vivo tienen guía",
    "this is not an IPTV playlist (.m3u)": "esto no es una lista IPTV (.m3u)",
    "Channel settings": "Ajustes del canal", "Channel settings…": "Ajustes del canal…", "Channel number": "Número de canal",
    "empty = the provider's number (%s)": "vacío = el número del proveedor (%s)", "No shift": "Sin cambio",
    "Time shift": "Cambio de hora", "e.g. +3 h for a West Coast feed": "p. ej. +3 h para una señal de la costa oeste",
    "More guides (any XMLTV address)": "Más guías (cualquier dirección XMLTV)", "Remove": "Quitar", "%d channels": "%d canales",
    "Add any XMLTV guide from the internet: it's downloaded with every build and merged into yours.":
        "Agrega cualquier guía XMLTV de internet: se descarga en cada creación y se une a la tuya.",
    "Paste a guide address that starts with http:// or https://": "Pega una dirección de guía que empiece con http:// o https://",
    "That guide is already in the list.": "Esa guía ya está en la lista.", "Checking the guide…": "Revisando la guía…",
    "That guide has no channels.": "Esa guía no tiene canales.",
    "Added: %d channels. It's merged in from your next build.": "Agregada: %d canales. Se une a partir de tu próxima creación.",
    "Couldn't load that guide: %s": "No se pudo cargar esa guía: %s", "Add guide": "Agregar guía", "Guide": "Guía",
    "this address is not an XMLTV guide": "esta dirección no es una guía XMLTV",
    "Ready": "Lista", "Not built": "Sin crear", "Failed": "Falló", "No guide": "Sin guía", "Off": "Apagada",
    "STATUS": "ESTADO", "CHANNELS": "CANALES", "NEXT UPDATE": "PRÓXIMA ACTUALIZACIÓN", "LIVE": "EN VIVO",
    'today': 'hoy',
    '%s at %s': '%s a las %s',
    'Your TV providers': 'Tus proveedores de TV',
    'Their channels are combined into one guide, top to bottom.': 'Sus canales se combinan en una sola guía, de arriba hacia abajo.',
    'Find a channel': 'Buscar un canal',
    'Build your guide': 'Crea tu guía',
    'Downloads the listings for your providers and makes one guide file. Shortcut: Ctrl+B.': 'Descarga la programación de tus proveedores y crea un solo archivo de guía. Atajo: Ctrl+B.',
    "What's on now": 'Qué hay ahora',
    "A quick look inside your guide file — what's on right now on each channel.": 'Un vistazo rápido a tu archivo de guía: qué se transmite ahora mismo en cada canal.',
    'Use it on your TV': 'Úsala en tu TV',
    'Let your TV box (Firestick, Android TV, TiviMate…) load the guide straight from this computer over your home network — no copying files.': 'Deja que tu dispositivo de TV (Firestick, Android TV, TiviMate…) cargue la guía directamente desde esta computadora por tu red de casa, sin copiar archivos.',
    'Daily update': 'Actualización diaria',
    'Settings': 'Configuración',
    'How your guide file is made. Changes are saved straight away.': 'Cómo se crea tu archivo de guía. Los cambios se guardan al instante.',
    'Your guide file': 'Tu archivo de guía',
    'Add ready-made EPGTalk guides (optional, free)': 'Agregar guías listas de EPGTalk (opcional, gratis)',
    'Schedules Direct account (only if you use one)': 'Cuenta de Schedules Direct (solo si usas una)',
    'Look, language and clock': 'Apariencia, idioma y reloj',
    'Language': 'Idioma',
    'Look': 'Apariencia',
    'Text size': 'Tamaño del texto',
    'Clock': 'Reloj',
    'This app': 'Esta aplicación',
    'Nothing to build yet: add a TV provider first.': 'Aún no hay nada que crear: primero agrega un proveedor de TV.',
    'Stopped.': 'Detenido.',
    'Putting it all together': 'Juntando todo',
    'Nothing was downloaded, so the guide was not changed.': 'No se descargó nada, así que la guía no cambió.',
    'see the log': 'ver el registro',
    'yesterday': 'ayer',
    'Home': 'Inicio',
    'Providers': 'Proveedores',
    'Build guide': 'Crear guía',
    'Use on your TV': 'Úsala en tu TV',
    'Open my guide folder': 'Abrir la carpeta de mi guía',
    'Open the settings folder': 'Abrir la carpeta de configuración',
    'Open the log': 'Abrir el registro',
    'Back up my settings…': 'Respaldar mi configuración…',
    'Restore settings from a backup…': 'Restaurar la configuración desde un respaldo…',
    'Quit': 'Salir',
    'File': 'Archivo',
    'Normal text': 'Texto normal',
    'Large text': 'Texto grande',
    'Extra large text': 'Texto extra grande',
    'Light look': 'Apariencia clara',
    'Dark look': 'Apariencia oscura',
    'View': 'Ver',
    'How to use (step by step)': 'Cómo usarla (paso a paso)',
    'About': 'Acerca de',
    'Help': 'Ayuda',
    'Add a TV provider': 'Agregar un proveedor de TV',
    'Import old mc2xml files': 'Importar archivos de mc2xml',
    'Edit provider': 'Editar proveedor',
    'Stop': 'Detener',
    'The details of each build show here.': 'Aquí aparecen los detalles de cada creación.',
    'CHANNEL': 'CANAL',
    'ON NOW': 'AHORA',
    'TIME': 'HORARIO',
    'UP NEXT': 'A CONTINUACIÓN',
    'Turn on daily update': 'Activar la actualización diaria',
    'Turn off': 'Desactivar',
    'Also save a compressed copy (.xml.gz) — smaller, most IPTV apps can read it': 'Guardar también una copia comprimida (.xml.gz): más pequeña, la mayoría de las apps IPTV la leen',
    "Network names (“NBC (WDIV)” instead of “WDIVDT”) for channels you haven't renamed": 'Nombres de cadena (“NBC (WDIV)” en vez de “WDIVDT”) para los canales que no renombraste',
    'UTF-8 text (recommended: accents and symbols come out right)': 'Texto UTF-8 (recomendado: los acentos y símbolos se ven bien)',
    'Channel name first (“FOX 2” rather than “2 FOX”)': 'Nombre del canal primero (“FOX 2” en vez de “2 FOX”)',
    'Times in UTC (only if your app shows the wrong times)': 'Horarios en UTC (solo si tu app muestra horas equivocadas)',
    'Add “ [NEW]” to the titles of new episodes': 'Agregar “ [NEW]” al título de los episodios nuevos',
    'Add “ [LIVE]” to the titles of live shows': 'Agregar “ [LIVE]” al título de los programas en vivo',
    'Guide ready: %s  (%d channels, %d shows, %.1f MB)': 'Guía lista: %s  (%d canales, %d programas, %.1f MB)',
    'This is not an EPGTalk Guide Builder backup.': 'Este no es un respaldo de EPGTalk Guide Builder.',
    'Add to my apps menu': 'Agregar a mi menú de aplicaciones',
    'mc2xml and install guide': 'Guía de mc2xml e instalación',
    'Back up my settings': 'Respaldar mi configuración',
    'Also include your Schedules Direct login?\n\nOnly say yes if you keep this backup file private.': '¿Incluir también tu usuario de Schedules Direct?\n\nDi que sí solo si guardas este respaldo en privado.',
    'Restore settings from a backup': 'Restaurar la configuración desde un respaldo',
    'Replace your current providers, channels and settings with this backup?\n\nA copy of your current setup is saved first, just in case.': '¿Reemplazar tus proveedores, canales y configuración actuales con este respaldo?\n\nPrimero se guarda una copia de lo que tienes ahora, por si acaso.',
    'Restored. The app opens again with your restored setup.\n\nYour previous setup was saved as:\n%s': 'Restaurado. La aplicación se abre de nuevo con tu configuración restaurada.\n\nTu configuración anterior se guardó como:\n%s',
    'You changed providers, channels or settings since then.': 'Cambiaste proveedores, canales o configuración desde entonces.',
    'tomorrow': 'mañana',
    'Automatic daily update: off': 'Actualización diaria automática: desactivada',
    'free listings': 'programación gratis',
    'Switched off · not in the guide': 'Desactivado · no está en la guía',
    'Find providers': 'Buscar proveedores',
    'Choose an mc2xml lineup file (.dat)': 'Elige un archivo de lineup de mc2xml (.dat)',
    'Channels': 'Canales',
    'All': 'Todos',
    'Picked': 'Elegidos',
    'Main stations': 'Canales principales',
    'Sub-channels': 'Subcanales',
    'Click the box to pick a channel (or select rows and press the space bar). Click “✎ Rename” — or double-click a channel — to give it your own name.': 'Haz clic en la casilla para elegir un canal (o selecciona varias filas y presiona la barra espaciadora). Haz clic en “✎ Renombrar”, o doble clic en un canal, para ponerle tu propio nombre.',
    'NUMBER': 'NÚMERO',
    'CALL SIGN': 'INDICATIVO',
    'YOUR NAME': 'TU NOMBRE',
    'Save channels': 'Guardar canales',
    'Rename channel': 'Renombrar canal',
    'Build my guide': 'Crear mi guía',
    'Shows': 'Programas',
    'File size': 'Tamaño',
    'Built in': 'Creada en',
    'Copied: %s': 'Copiado: %s',
    'Add a TV provider first.': 'Primero agrega un proveedor de TV.',
    'Starting…': 'Empezando…',
    'Building your guide…': 'Creando tu guía…',
    'This takes a few seconds per provider.': 'Esto toma unos segundos por proveedor.',
    'Stopping…': 'Deteniendo…',
    'Reading…': 'Leyendo…',
    'Build a fresh guide automatically once a day — even when this window is closed (the computer must be on).': 'Crea una guía nueva automáticamente una vez al día, incluso con esta ventana cerrada (la computadora debe estar encendida).',
    'Uses Windows Task Scheduler.': 'Usa el Programador de tareas de Windows.',
    'Uses cron.': 'Usa cron.',
    'No build yet.': 'Todavía no se ha creado ninguna.',
    'Results of automatic builds are in the log (File → Open the log). Every build has several days of listings, so once a day is plenty.': 'Los resultados de las creaciones automáticas están en el registro (Archivo → Abrir el registro). Cada guía trae varios días de programación, así que una vez al día es suficiente.',
    'Type a time like 4:30 AM or 18:00.': 'Escribe una hora como 4:30 AM o 18:00.',
    'Saved on this computer only.': 'Guardado solo en esta computadora.',
    'Not set.': 'Sin configurar.',
    'Type your username and password.': 'Escribe tu usuario y contraseña.',
    'Saved. Checking with Schedules Direct…': 'Guardado. Verificando con Schedules Direct…',
    'Light': 'Clara',
    'Dark': 'Oscura',
    'Normal': 'Normal',
    'Large': 'Grande',
    'Extra large': 'Extra grande',
    '12-hour (9:45 PM)': '12 horas (9:45 PM)',
    '24-hour (21:45)': '24 horas (21:45)',
    '%s was not found next to this program.\nPut both files in the same folder.': 'No se encontró %s junto a este programa.\nPon ambos archivos en la misma carpeta.',
    'Provider %d of %d: %s': 'Proveedor %d de %d: %s',
    'Adding %s': 'Agregando %s',
    'added': 'agregado',
    'Also saved: %s': 'También se guardó: %s',
    'Not included this time: %s': 'No se incluyó esta vez: %s',
    'made by aCiDjEsUs': 'hecho por aCiDjEsUs',
    'Open Home for details': 'Abre Inicio para ver los detalles',
    'Backup saved: %s': 'Respaldo guardado: %s',
    'Everything about your guide, at a glance.': 'Todo sobre tu guía, de un vistazo.',
    'Good morning': 'Buenos días',
    'Updates bring fixes and new features.': 'Las actualizaciones traen arreglos y funciones nuevas.',
    'Your guide is ready': 'Tu guía está lista',
    'Changes not built yet': 'Cambios sin crear todavía',
    'The last automatic update failed': 'La última actualización automática falló',
    'No guide yet': 'Todavía no hay guía',
    'Built %s · %s channels · %s shows': 'Creada %s · %s canales · %s programas',
    'Start by adding your TV provider.': 'Empieza agregando tu proveedor de TV.',
    'Press “Build my guide” to make your guide file.': 'Presiona “Crear mi guía” para crear tu archivo de guía.',
    'Next automatic update: %s %s': 'Próxima actualización automática: %s %s',
    'Type your zip / postal code first.': 'Primero escribe tu código postal.',
    'Searching…': 'Buscando…',
    'Pick a provider from the list first.': 'Primero elige un proveedor de la lista.',
    'Added: %s\n\nPick its channels now? (Otherwise every channel is included.)': 'Agregado: %s\n\n¿Elegir sus canales ahora? (Si no, se incluyen todos los canales.)',
    'Its channel file (.chl)? (Cancel = all channels)': '¿Su archivo de canales (.chl)? (Cancelar = todos los canales)',
    'Its rename file (.ren)? (Cancel = none)': '¿Su archivo de nombres (.ren)? (Cancelar = ninguno)',
    'Free listings need the zip / postal code.': 'La programación gratis necesita el código postal.',
    'Imported %s.': 'Importado: %s.',
    'Remove %s from your providers?': '¿Quitar %s de tus proveedores?',
    'Loading the channel list…': 'Cargando la lista de canales…',
    'Rename…': 'Renombrar…',
    'Saved %d channels for %s.': 'Se guardaron %d canales de %s.',
    'Open the folder': 'Abrir la carpeta',
    'Copy the file path': 'Copiar la ruta del archivo',
    'Steps': 'Pasos',
    'Guide built %s.': 'Guía creada %s.',
    'Not finished': 'Sin terminar',
    'Look at the red lines in the details below.': 'Mira las líneas rojas en los detalles de abajo.',
    'Put it all together': 'Juntar todo',
    'Refresh': 'Actualizar',
    'Find': 'Buscar',
    'No guide yet — build it first.': 'Todavía no hay guía: créala primero.',
    'Copy the address': 'Copiar la dirección',
    'How to add it on your TV box': 'Cómo agregarla en tu dispositivo de TV',
    'Sharing is ON': 'Compartir está ACTIVADO',
    'Sharing is off': 'Compartir está desactivado',
    'Every day at': 'Todos los días a las',
    'Last build: %s · %s channels · %s shows': 'Última creación: %s · %s canales · %s programas',
    'Save the guide as': 'Guardar la guía como',
    'Browse…': 'Examinar…',
    'Days of listings': 'Días de programación',
    '7 is a good choice; more days = bigger file': '7 es una buena opción; más días = archivo más grande',
    'Username': 'Usuario',
    'Password': 'Contraseña',
    'Save and test': 'Guardar y probar',
    'Restore from a backup…': 'Restaurar desde un respaldo…',
    'A backup keeps your providers, channels, your own names and settings in one file — to keep it safe or move to a new computer.': 'Un respaldo guarda tus proveedores, canales, tus propios nombres y la configuración en un solo archivo, para tenerlos seguros o pasarlos a otra computadora.',
    'Tell me when a new version is available (checks EPGTalk.com once a day)': 'Avísame cuando haya una versión nueva (revisa EPGTalk.com una vez al día)',
    'did not finish (see the lines above)': 'no terminó (mira las líneas de arriba)',
    'Automatic update failed': 'Falló la actualización automática',
    'Backup': 'Respaldo',
    'Could not save the backup:': 'No se pudo guardar el respaldo:',
    'Could not restore:': 'No se pudo restaurar:',
    'Good afternoon': 'Buenas tardes',
    'Good evening': 'Buenas noches',
    'Reason: %s': 'Motivo: %s',
    'Not included: %s. The rest of your guide was updated.': 'No se incluyó: %s. El resto de tu guía sí se actualizó.',
    'New version %s is available': 'Ya está disponible la versión %s',
    'Download': 'Descargar',
    'Later': 'Más tarde',
    'On now': 'Ahora',
    'See all': 'Ver todo',
    'Reading your guide…': 'Leyendo tu guía…',
    'Add a provider': 'Agregar un proveedor',
    'Channels…': 'Canales…',
    'Edit name / zip code…': 'Editar nombre / código postal…',
    'Remove…': 'Quitar…',
    'Choose': 'Elegir',
    'Cancel': 'Cancelar',
    'Where should the listings come from?': '¿De dónde debe venir la programación?',
    'Free listings (Gracenote) — United States, Canada, Mexico': 'Programación gratis (Gracenote): Estados Unidos, Canadá, México',
    'My Schedules Direct account (paid, more countries)': 'Mi cuenta de Schedules Direct (de pago, más países)',
    'Country': 'País',
    'Zip / postal code': 'Código postal',
    'Type your zip / postal code and press “Find providers”. For an antenna or HDHomeRun, pick “Local Over the Air Broadcast”.': 'Escribe tu código postal y presiona “Buscar proveedores”. Para antena o HDHomeRun, elige “Local Over the Air Broadcast”.',
    'Add this provider': 'Agregar este proveedor',
    'mc2xml lineup': 'Lineup de mc2xml',
    'All files': 'Todos los archivos',
    'Did this lineup use Schedules Direct (mc2xml -J)?': '¿Este lineup usaba Schedules Direct (mc2xml -J)?',
    'No — free listings (Gracenote)': 'No: programación gratis (Gracenote)',
    'Yes — my Schedules Direct account': 'Sí: mi cuenta de Schedules Direct',
    "The zip code you used with -g. (Schedules Direct users can leave it empty if the lineup is on their account.) Your original files are not changed: copies are made in this program's folder.": 'El código postal que usabas con -g. (Los usuarios de Schedules Direct pueden dejarlo vacío si el lineup está en su cuenta.) Tus archivos originales no se modifican: se hacen copias en la carpeta de este programa.',
    'Import': 'Importar',
    'Name shown in the list': 'Nombre que se muestra en la lista',
    'Save': 'Guardar',
    'Untick all shown': 'Desmarcar los mostrados',
    'Tick all shown': 'Marcar los mostrados',
    '%d of %d picked': '%d de %d elegidos',
    'Remove my name': 'Quitar mi nombre',
    'Untick': 'Desmarcar',
    'Tick': 'Marcar',
    'Which lineup is it?': '¿Cuál lineup es?',
    "All channels are picked (no channel list yet). Untick what you don't want — or “Untick all shown” and then tick your favourites.": 'Todos los canales están elegidos (aún no hay lista de canales). Desmarca los que no quieras, o usa “Desmarcar los mostrados” y luego marca tus favoritos.',
    'No channels are picked. Save anyway?': 'No hay canales elegidos. ¿Guardar de todos modos?',
    'Hide details': 'Ocultar detalles',
    'Show details': 'Mostrar detalles',
    'under 1 s': '< 1 s',
    'It takes a few seconds per provider. Your guide will be saved as: %s': 'Toma unos segundos por proveedor. Tu guía se guardará como: %s',
    "Your changes aren't in the guide yet — press “Build my guide”": 'Tus cambios aún no están en la guía: presiona “Crear mi guía”',
    'Last build: %s': 'Última creación: %s',
    'Done': 'Listo',
    '.gz copy saved too': 'también se guardó la copia .gz',
    'Not included this time: %s (see the details below)': 'No se incluyó esta vez: %s (mira los detalles abajo)',
    "Some picked channels aren't in their lineup any more — open “Channels” for: %s": 'Algunos canales elegidos ya no están en su lineup: abre “Canales” de: %s',
    'The guide was not built': 'La guía no se creó',
    '%d channels · %s shows · file from %s': '%d canales · %s programas · archivo de %s',
    'Keep this window open (minimized is fine) while your TV box updates its guide.': 'Deja esta ventana abierta (minimizada está bien) mientras tu dispositivo de TV actualiza la guía.',
    'TiviMate: Settings → EPG → Add EPG source → paste or type the address above.\nIPTV Smarters and most other apps: look for “EPG” / “TV guide” / “XMLTV URL” in the playlist settings and enter the address.\nTip: give this computer a fixed address in your router, so the address never changes.': 'TiviMate: Configuración → EPG → Agregar fuente EPG → pega o escribe la dirección de arriba.\nIPTV Smarters y la mayoría de las apps: busca “EPG” / “Guía de TV” / “URL XMLTV” en la configuración de la lista y escribe la dirección.\nConsejo: dale a esta computadora una dirección fija en tu router, así la dirección nunca cambia.',
    '(for example 4:30 AM)': '(por ejemplo 4:30 AM)',
    '(for example 04:30)': '(por ejemplo 04:30)',
    'Last automatic update: %s — %s': 'Última actualización automática: %s: %s',
    'XMLTV guide': 'Guía XMLTV',
    "Click to see what's new": 'Haz clic para ver las novedades',
    'needs your Schedules Direct login (Settings)': 'necesita tu usuario de Schedules Direct (Configuración)',
    'could not start the engine': 'no se pudo iniciar el motor',
    'Press “Build guide”': 'Presiona “Crear guía”',
    'Add a provider, then build': 'Agrega un proveedor y luego crea la guía',
    'Made by aCiDjEsUs, a Hamtramck kid · EPGTalk.com': 'Hecho por aCiDjEsUs, un chico de Hamtramck · EPGTalk.com',
    'Free, for the community.': 'Gratis, para la comunidad.',
    'Builds your own XMLTV guide with mc2xml (EPGTalk edition).': 'Crea tu propia guía XMLTV con mc2xml (edición EPGTalk).',
    'Listings: Gracenote (free) or your Schedules Direct account.': 'Programación: Gracenote (gratis) o tu cuenta de Schedules Direct.',
    'Shortcuts: Ctrl+B build · F5 refresh': 'Atajos: Ctrl+B crear · F5 actualizar',
    'Could not add the shortcut:': 'No se pudo agregar el acceso directo:',
    "The automatic update %s didn't finish": 'La actualización automática de %s no terminó',
    'Build now': 'Crear ahora',
    'Dismiss': 'Descartar',
    'The automatic update %s left something out': 'A la actualización automática de %s le faltó algo',
    'Your TV box loads it from': 'Tu dispositivo de TV la carga desde',
    'Copy': 'Copiar',
    'Turn on sharing': 'Activar compartir',
    'Your channels show up here once your guide is built.': 'Tus canales aparecen aquí cuando tu guía esté creada.',
    'Add your first TV provider': 'Agrega tu primer proveedor de TV',
    'Type your zip code and pick your cable, satellite or antenna lineup.\nUsed mc2xml before? Import your old .dat / .chl / .ren files instead.': 'Escribe tu código postal y elige tu lineup de cable, satélite o antena.\n¿Usabas mc2xml? Mejor importa tus archivos .dat / .chl / .ren.',
    'all channels': 'todos los canales',
    'Move up': 'Subir',
    'Move down': 'Bajar',
    "Lineups already on your Schedules Direct account are listed first (no zip code needed). Adding a new lineup uses one of your account's daily lineup changes (max 4 lineups per account).": 'Los lineups que ya están en tu cuenta de Schedules Direct aparecen primero (no hace falta código postal). Agregar un lineup nuevo usa uno de los cambios diarios de tu cuenta (máximo 4 lineups por cuenta).',
    'Nothing found — check the zip / postal code and country.': 'No se encontró nada: revisa el código postal y el país.',
    "%s is not on your Schedules Direct account yet.\n\nAdd it? This uses one of your account's daily lineup changes.": '%s todavía no está en tu cuenta de Schedules Direct.\n\n¿Agregarlo? Esto usa uno de los cambios diarios de lineup de tu cuenta.',
    'mc2xml channels': 'Canales de mc2xml',
    'mc2xml renames': 'Nombres de mc2xml',
    'Channels: %s\nRenames: %s': 'Canales: %s\nNombres: %s',
    'Rename': 'Renombrar',
    'Show this channel as': 'Mostrar este canal como',
    'Leave it empty to use the normal name.': 'Déjalo vacío para usar el nombre normal.',
    'OK': 'Aceptar',
    "“%s” wasn't found by name (providers rename lineups). Please pick it:": 'No se encontró “%s” por nombre (los proveedores cambian el nombre de sus lineups). Elígelo, por favor:',
    '%s channels · %s shows': '%s canales · %s programas',
    'Could not start sharing:': 'No se pudo activar compartir:',
    'Daily update is off': 'La actualización diaria está desactivada',
    'Daily update set for %s.': 'Actualización diaria programada para las %s.',
    'Could not set the daily update:': 'No se pudo programar la actualización diaria:',
    'Installed — open it from your apps menu (search for “EPGTalk”). Your guide is saved in: %s': 'Instalada: ábrela desde tu menú de aplicaciones (busca “EPGTalk”). Tu guía se guarda en: %s',
    'Start the builder like any other app.': 'Abre el creador como cualquier otra aplicación.',
    'Last built %s': 'Última creación %s',
    'Guide ready': 'Guía lista',
    'Built %s\n%s channels': 'Creada %s\n%s canales',
    'Open folder': 'Abrir carpeta',
    'Sharing on': 'Compartiendo',
    'Let your TV box load the guide straight from this computer — no copying files.': 'Deja que tu dispositivo de TV cargue la guía directamente desde esta computadora, sin copiar archivos.',
    'Problem:': 'Problema:',
    'Add a provider first.': 'Primero agrega un proveedor.',
    'Could not read the guide:': 'No se pudo leer la guía:',
    'Build your guide first.': 'Primero crea tu guía.',
    'Windows may ask once whether to allow network access — choose “Private networks”.': 'Windows puede preguntar una vez si permites el acceso a la red: elige “Redes privadas”.',
    'Daily update is ON (%s)': 'La actualización diaria está ACTIVADA (%s)',
    'Daily update is ON': 'La actualización diaria está ACTIVADA',
    'problem (see Home)': 'problema (mira Inicio)',
    'Could not check:': 'No se pudo revisar:',
    'Login works. %d lineup(s) on your account. Saved on this computer only.': 'El usuario funciona. %d lineup(s) en tu cuenta. Guardado solo en esta computadora.',
    'Build again': 'Crear de nuevo',
    '… and %d more channels': '… y %d canales más',
    '%d channel': '%d canal',
    '%d channels': '%d canales',
    'Enter your login in Settings first.': 'Primero escribe tu usuario en Configuración.',
    'none': 'ninguno',
    'no listing right now': 'sin programación ahora',
    'New version %s': 'Nueva versión %s',
    'on your account': 'en tu cuenta',
    'United States': 'Estados Unidos',
    'Canada': 'Canadá',
    'Mexico': 'México',
    'United Kingdom': 'Reino Unido',
    'Ireland': 'Irlanda',
    'Germany': 'Alemania',
    'France': 'Francia',
    'Spain': 'España',
    'Italy': 'Italia',
    'Netherlands': 'Países Bajos',
    'Poland': 'Polonia',
    'Australia': 'Australia',
    'New Zealand': 'Nueva Zelanda',
    'Brazil': 'Brasil',
    'Argentina': 'Argentina',
    'Colombia': 'Colombia',
    'Chile': 'Chile',
    'Peru': 'Perú',
    'Puerto Rico': 'Puerto Rico',
    'Jan': 'ene',
    'Feb': 'feb',
    'Mar': 'mar',
    'Apr': 'abr',
    'May': 'may',
    'Jun': 'jun',
    'Jul': 'jul',
    'Aug': 'ago',
    'Sep': 'sep',
    'Oct': 'oct',
    'Nov': 'nov',
    'Dec': 'dic',
    'Added to your Start menu and your desktop.': 'Se agregó a tu menú Inicio y a tu escritorio.',
    'Added to your apps menu (search for “EPGTalk”).': 'Se agregó a tu menú de aplicaciones (busca “EPGTalk”).',
    'EPGTalk Sports: a channel for every team (small)': 'EPGTalk Deportes: un canal para cada equipo (pequeño)',
    'EPGTalk Free TV: Pluto, Samsung TV Plus, Plex, Tubi (about 7 MB)': 'EPGTalk TV Gratis: Pluto, Samsung TV Plus, Plex, Tubi (unos 7 MB)',
    'EPGTalk US Local: 140+ local markets (about 2 MB)': 'EPGTalk Locales EE.UU.: más de 140 mercados locales (unos 2 MB)',
    'EPGTalk Combined: US + UK + Canada + Mexico, 48 h (about 5 MB)': 'EPGTalk Combinada: EE.UU. + Reino Unido + Canadá + México, 48 h (unos 5 MB)',
    'made by aCiDjEsUs · EPGTalk.com': 'hecho por aCiDjEsUs · EPGTalk.com',
})


ES.update({                                                 # 1.4.0: pick channels from guides (window)
    "all %d channels": "los %d canales",
    "%d of %d channels": "%d de %d canales",
    "Tip: click “Channels” to keep just what you watch — like your own teams, or a few Pluto channels. A smaller guide loads "
    "much faster on a Firestick.": "Consejo: pulsa “Canales” para quedarte solo con lo que ves, como tus equipos o unos canales de "
                                  "Pluto. Una guía más chica carga mucho más rápido en un Firestick.",
    "Search looks at every name a channel has. Click “✎ Rename” — or double-click a channel — to give it your own name or number.":
        "La búsqueda mira todos los nombres de cada canal. Pulsa “✎ Renombrar” (o doble clic en un canal) para ponerle tu propio "
        "nombre o número.",
    "LEAGUE": "LIGA", "SERVICE": "SERVICIO", "NETWORK": "CADENA", "GROUP": "GRUPO", "FULL NAME": "NOMBRE COMPLETO",
    "Add new channels automatically": "Agregar canales nuevos automáticamente",
    "Off: only the channels you picked. On: new channels added to this guide later come in too.":
        "Apagado: solo los canales que elegiste. Encendido: también entran los canales nuevos que se agreguen a esta guía.",
    "about %s instead of %s": "unos %s en vez de %s",
    "empty = no channel number": "vacío = sin número de canal",
    "changed “Add new channels automatically”": "cambiaste “Agregar canales nuevos automáticamente”",
    "Soccer": "Fútbol", "More": "Más", "NCAA Football": "Fútbol americano NCAA", "NCAA Basketball": "Básquetbol NCAA",
})


ES.update({                                                 # 1.4.0: pick channels from guides (core)
    "%d of %d channels (your picks)": "%d de %d canales (tu selección)",
    "not in this guide any more: %s": "ya no están en esta guía: %s",
    "That guide isn't in your list any more.": "Esa guía ya no está en tu lista.",
})


ES.update({                                                 # 1.3.4: bug hunt
    "today's update didn't work, so its last good listings (%s) are used":
        "la actualización de hoy no funcionó, así que se usa su última programación buena (%s)",
    "Kept the last good listings for: %s": "Se mantuvo la última programación buena de: %s",
    "Today's update didn't work for %s, so their last good listings are in your guide (see the details below)":
        "La actualización de hoy no funcionó para %s, así que tu guía tiene su última programación buena (mira los detalles abajo)",
    "Today's update didn't work for %s, so their last good listings are in your guide.":
        "La actualización de hoy no funcionó para %s, así que tu guía tiene su última programación buena.",
})


ES.update({                                                 # 1.3.3: channels and lineups
    "Tip: TiviMate shows the channel names from your playlist. The names you give here show in Plex, Jellyfin, Emby, "
    "Channels DVR and this app's TV guide, and they help match your channels.":
        "Consejo: TiviMate muestra los nombres de canal de tu lista. Los nombres que pongas aquí se ven en Plex, Jellyfin, Emby, "
        "Channels DVR y la guía de TV de esta app, y ayudan a unir tus canales.",
    "1 change not saved yet": "1 cambio sin guardar",
    "%d changes not saved yet": "%d cambios sin guardar",
    "renamed 1 channel": "renombraste 1 canal",
    "renamed %d channels": "renombraste %d canales",
    "picked %d more": "marcaste %d más",
    "unticked %d": "desmarcaste %d",
    "changed the number or time shift of %d": "cambiaste el número o el horario de %d",
    "and": "y",
    "Save your changes?": "¿Guardar tus cambios?",
    "You %s. If you don't save, these changes are lost.": "%s. Si no guardas, estos cambios se pierden.",
    "Don't save": "No guardar",
    "Keep editing": "Seguir editando",
    "“%s” isn't on your Schedules Direct account": "“%s” no está en tu cuenta de Schedules Direct",
    "“%s” wasn't found by name": "No se encontró “%s” por su nombre",
    "It may have been removed from the account. Pick the lineup this provider should use — these are the lineups on your "
    "account right now:": "Quizás se quitó de la cuenta. Elige la programación que debe usar este proveedor; estas son las que "
                          "tienes en tu cuenta ahora:",
    "Your Schedules Direct account has no lineups right now. Search by zip / postal code, or remove this provider.":
        "Tu cuenta de Schedules Direct no tiene programaciones ahora. Busca por código postal o quita este proveedor.",
    "Providers rename their lineups now and then. Please pick it:": "Los proveedores cambian el nombre de sus programaciones a veces. Elígela:",
    "Search all lineups by zip / postal code instead…": "Buscar todas las programaciones por código postal…",
    "Want %s back? Remove this provider, then add it again with the free listings (Gracenote) — it doesn't use one of your "
    "4 Schedules Direct lineups.": "¿Quieres %s otra vez? Quita este proveedor y agrégalo de nuevo con la programación gratis "
                                   "(Gracenote): no usa una de tus 4 programaciones de Schedules Direct.",
    "Use this lineup": "Usar esta programación",
    "Remove this provider": "Quitar este proveedor",
    "Removed %s.": "Se quitó %s.",
    "Removed.": "Quitado.",
    "No lineup chosen.": "No se eligió ninguna programación.",
})


ES.update({                                                 # 1.3.2: on your NAS
    "Set it up in your app (Plex, TiviMate, xTeVe…)": "Configúrala en tu app (Plex, TiviMate, xTeVe…)",
    "Run it 24/7 on your NAS…": "Úsala 24/7 en tu NAS…",
    "Run it 24/7 on your NAS": "Úsala 24/7 en tu NAS",
    "Step by step for your app — Plex, Jellyfin, Emby, Channels DVR, Kodi, xTeVe / Threadfin →":
        "Paso a paso para tu app: Plex, Jellyfin, Emby, Channels DVR, Kodi, xTeVe / Threadfin →",
    "Don't want to leave this computer on? The Guide Builder can live on your NAS, Raspberry Pi or home server — it updates your "
    "guide every day by itself, and you manage it from any browser, even your phone.":
        "¿No quieres dejar esta computadora encendida? Guide Builder puede vivir en tu NAS, Raspberry Pi o servidor de casa: "
        "actualiza tu guía sola todos los días, y la manejas desde cualquier navegador, hasta tu teléfono.",
    "any Docker": "cualquier Docker",
    "Move to my NAS…": "Pasar a mi NAS…",
    "Move to my NAS": "Pasar a mi NAS",
    "How to set it up": "Cómo instalarla",
    "Your providers, channels, names and numbers go to the Guide Builder on your NAS in one go.":
        "Tus proveedores, canales, nombres y números pasan a Guide Builder en tu NAS de una vez.",
    "Your NAS address": "La dirección de tu NAS",
    "Check": "Revisar",
    "For example 192.168.1.50:8765 — the address you open the NAS page with.":
        "Por ejemplo 192.168.1.50:8765: la dirección con la que abres la página del NAS.",
    "NAS password (only if you set one there)": "Contraseña del NAS (solo si pusiste una)",
    "Also send my Schedules Direct login and playlist address": "Enviar también mi usuario de Schedules Direct y mi lista",
    "Stop the daily update and sharing on this computer": "Detener la actualización diaria y el compartir aquí",
    "Your NAS does it from now on. You can turn them back on any time.":
        "Tu NAS lo hace de ahora en adelante. Puedes volver a activarlos cuando quieras.",
    "Not on your NAS yet? Set it up first →": "¿Aún no está en tu NAS? Instálala primero →",
    "No NAS handy? Save a backup file instead…": "¿Sin NAS a la mano? Guarda un archivo de respaldo…",
    "Looking…": "Buscando…",
    "Found Guide Builder %s on your NAS": "Se encontró Guide Builder %s en tu NAS",
    "it asks for a password": "pide contraseña",
    "Type your NAS address first.": "Primero escribe la dirección de tu NAS.",
    "That doesn't look like an address (for example 192.168.1.50:8765).": "Eso no parece una dirección (por ejemplo 192.168.1.50:8765).",
    "No Guide Builder answered at %s. Is it running on your NAS, and is the address right?":
        "Ningún Guide Builder respondió en %s. ¿Está funcionando en tu NAS y la dirección es correcta?",
    "Your NAS asks for a password — type it in the box.": "Tu NAS pide contraseña: escríbela en la casilla.",
    "Packing up your providers and channels…": "Empacando tus proveedores y canales…",
    "Sending them to your NAS…": "Enviándolos a tu NAS…",
    "Building your guide on the NAS…": "Creando tu guía en el NAS…",
    "Your NAS has it now!": "¡Tu NAS ya la tiene!",
    "%d providers moved.": "Se pasaron %d proveedores.",
    "1 provider moved.": "Se pasó 1 proveedor.",
    "About %d channels.": "Unos %d canales.",
    "The daily update and sharing on this computer are off.": "La actualización diaria y el compartir en esta computadora están apagados.",
    "This computer keeps sharing too, until you turn it off.": "Esta computadora también sigue compartiendo, hasta que lo apagues.",
    "Your NAS is building the guide now (a minute or two).": "Tu NAS está creando la guía ahora (uno o dos minutos).",
    "Change the address in TiviMate (or your app) to:": "Cambia la dirección en TiviMate (o tu app) a:",
    "Open my NAS page": "Abrir la página de mi NAS",
})


if __name__ == "__main__":
    if "--run" in sys.argv[1:]:
        sys.exit(headless())
    if "--tray" in sys.argv[1:]:
        sys.exit(tray_main())
    if sys.stdout is None:                                     # pythonw: no console
        sys.stdout = open(os.devnull, "w")
        sys.stderr = open(os.devnull, "w")
    try:
        import tkinter  # noqa: F401
    except ImportError:
        print("This program needs Tkinter. On Ubuntu / Debian / Mint run:  sudo apt install python3-tk")
        sys.exit(1)
    bg = "--background" in sys.argv[1:]
    if instance_send("ping" if bg else "show") is not None:   # already open: bring it to the front instead
        sys.exit(0)
    while gui(background=bg) == "restart":                   # switched light/dark look or language
        bg = False
