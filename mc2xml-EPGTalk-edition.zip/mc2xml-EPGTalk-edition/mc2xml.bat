@echo off
rem mc2xml launcher - runs mc2xml.py with the same options as the old mc2xml.exe
rem Inside your own .bat files call it as:  call mc2xml.bat -c us -g 12345 ...
setlocal
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
where py >nul 2>nul
if %ERRORLEVEL%==0 (py -3 "%~dp0mc2xml.py" %*) else (python "%~dp0mc2xml.py" %*)
exit /b %ERRORLEVEL%
