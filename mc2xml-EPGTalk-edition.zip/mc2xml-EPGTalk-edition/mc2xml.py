#!/usr/bin/env python3
"""mc2xml - EPGTalk edition
Made by aCiDjEsUs - https://epgtalk.com

Drop-in replacement for the mc2xml command line used by the EPG scripts.
Downloads TV listings from Gracenote (tvlistings.gracenote.com) or, when -J is
given, from Schedules Direct, and writes an XMLTV file.

Supported options (same letters as the original):
  -J user:pass   use Schedules Direct with this account
  -J @file       ... reading "user:pass" from a file (keep it chmod 600)
  -c <cc>        country code (us, ca, gb, mx, ... or 3-letter)
  -g <code>      postal / zip code
  -D <file>      dat file (lineup selection), default mc2xml.dat
  -C <file>      channel file (call signs or channel numbers to keep), default mc2xml.chl
  -R <file>      rename file (KEY:New Name), default mc2xml.ren
  -o <file>      output file, default xmltv.xml
  -I <file>      include (merge) an existing XMLTV file into the output (repeatable)
  -d <hours>     listings duration in hours (default 168)
  -s <[+/-]hrs>  listings start offset in hours
  -i <#>         add # to all channel numbers
  -a             append " [NEW]" to titles of new programs
  -A             append " [LIVE]" to titles of live programs
  -F             output channel "name" first (rather than "number name")
  -U             output UTF-8 (default ISO-8859-1)
  -u             output times in UTC (default local time)
  -f             force re-download (ignore cache)
  -L, -1         (accepted for compatibility)
  --movie-details=<hours>  (accepted for compatibility)
  --threads=<n>  download threads (default 3)
  --lineup       list lineups for -c/-g and choose one again
  --add-lineup   Schedules Direct: allow adding the lineup to your account in unattended runs (cron).
                 Without it, a lineup that isn't on the account stops with a message instead of
                 quietly using one of the account's daily lineup changes
  --network-names  name channels by network ("FOX Entertainment") instead of call sign,
                 unless they are renamed in the .ren file
"""

import argparse
import concurrent.futures as cf
import difflib
import datetime as dt
import gzip
import hashlib
import html
import json
import os
import re
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

VERSION = "2.1.2-py"
CREDIT = "made by aCiDjEsUs - EPGTalk.com"
UA = ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/128.0 Safari/537.36")
SD_UA = "mc2xml-py/" + VERSION
SD_BASE = "https://json.schedulesdirect.org/20141201"
GN_BASE = "https://tvlistings.gracenote.com"
CHUNK = 6 * 3600

COUNTRIES = {
    "us": "USA", "ca": "CAN", "gb": "GBR", "uk": "GBR", "mx": "MEX",
    "de": "DEU", "fr": "FRA", "es": "ESP", "it": "ITA", "nl": "NLD",
    "br": "BRA", "ar": "ARG", "au": "AUS", "nz": "NZL", "ie": "IRL",
    "pr": "PRI", "co": "COL", "cl": "CHL", "pe": "PER", "pl": "POL",
}


class Fatal(Exception):
    pass


def log(label, msg):
    print("%s: %s" % (_dots(label), msg), flush=True)


def _dots(label):
    # "Reading ....." style labels, 13 columns wide
    label = label + " "
    return label + "." * max(0, 13 - len(label))


def esc(s):
    return html.escape(str(s), quote=True).replace("&#x27;", "&apos;")


# --------------------------------------------------------------------------- #
# HTTP
# --------------------------------------------------------------------------- #

class Http:
    def __init__(self):
        self.bytes = 0

    def request(self, url, data=None, headers=None, method=None, tries=4):
        hdrs = {"User-Agent": UA, "Accept-Encoding": "gzip"}
        hdrs.update(headers or {})
        body = None
        if data is not None:
            body = data if isinstance(data, bytes) else json.dumps(data).encode()
            hdrs.setdefault("Content-Type", "application/json")
        last = None
        for attempt in range(tries):
            try:
                req = urllib.request.Request(url, data=body, headers=hdrs, method=method)
                with urllib.request.urlopen(req, timeout=60) as r:
                    raw = r.read()
                    self.bytes += len(raw)
                    if r.headers.get("Content-Encoding") == "gzip" or raw[:2] == b"\x1f\x8b":
                        raw = gzip.decompress(raw)
                    return raw
            except urllib.error.HTTPError as e:
                payload = e.read()
                if e.code in (400, 401, 403, 404):
                    # Schedules Direct returns JSON error bodies with useful codes
                    if payload[:2] == b"\x1f\x8b":
                        payload = gzip.decompress(payload)
                    raise Fatal("HTTP %d from %s: %s" % (e.code, url.split("?")[0],
                                                          payload[:300].decode("utf-8", "replace")))
                last = e
            except (urllib.error.URLError, TimeoutError, ConnectionError, OSError) as e:
                last = e
            time.sleep(2 ** attempt)
        raise Fatal("download failed: %s (%s)" % (url.split("?")[0], last))

    def json(self, *a, **kw):
        return json.loads(self.request(*a, **kw).decode("utf-8"))


# --------------------------------------------------------------------------- #
# Helpers for config files
# --------------------------------------------------------------------------- #

def read_lines(path):
    with open(path, "r", encoding="utf-8-sig", errors="replace") as f:
        return [l.strip() for l in f.read().splitlines()]


def load_chl(path):
    if not path or not os.path.exists(path):
        return None
    log("Reading", path)
    keys = set()
    for l in read_lines(path):
        l = re.sub("[\ufeff\u200b\u200c\u200d\u00a0]", "", l).strip()
        if l and not l.startswith("#"):
            keys.add(l.upper())
    return keys


def load_ren(path):
    ren = {}
    if not path or not os.path.exists(path):
        return ren
    log("Reading", path)
    for l in read_lines(path):
        if not l or l.startswith("#") or ":" not in l:
            continue
        k, v = l.split(":", 1)
        k = k.strip().upper()
        if k and k not in ren:          # first entry wins (matches original)
            ren[k] = html.unescape(v.strip())
    return ren


def load_dat(path):
    """Returns (dict or None, legacy_lineup_name or None)."""
    if not os.path.exists(path):
        return None, None
    log("Reading", path)
    with open(path, "rb") as f:
        raw = f.read()
    try:
        txt = raw.decode("utf-8")
    except UnicodeDecodeError:
        txt = raw.decode("latin-1")
    if txt.lstrip().startswith("{"):
        try:
            return json.loads(txt), None
        except ValueError:
            pass
    # original (encrypted) .dat: first line is the lineup display name in plain text
    first = txt.splitlines()[0].strip() if txt else ""
    return None, html.unescape(first) or None


def save_dat(path, d):
    log("Writing", path)
    if os.path.exists(path):
        with open(path, "rb") as f:
            head = f.read(1)
        if head != b"{" and not os.path.exists(path + ".orig"):
            os.replace(path, path + ".orig")   # keep the original mc2xml .dat once
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, indent=1, ensure_ascii=False)
        f.write("\n")
    os.replace(tmp, path)


def choose(options, label):
    """options: list of (display_name, value). Interactive pick."""
    print()
    for i, (name, _) in enumerate(options, 1):
        print("  %3d) %s" % (i, name))
    print()
    if not sys.stdin.isatty():
        raise Fatal("no lineup selected; run once interactively (or with --lineup) to pick a %s" % label)
    while True:
        a = input("Select %s [1-%d]: " % (label, len(options))).strip()
        if a.isdigit() and 1 <= int(a) <= len(options):
            return options[int(a) - 1]


def norm(s):
    return re.sub(r"\s+", " ", html.unescape(s or "")).strip().lower()


BRAND_ALIASES = [("comcast", "xfinity"), ("time warner cable", "spectrum"), ("bright house", "spectrum"),
                 ("charter", "spectrum"), ("u-verse", "u-verse")]


def match_lineup(opts, legacy_name):
    """Find a lineup by the name stored in an original .dat. Exact match first, then
    tolerate provider renames (e.g. Comcast -> Xfinity) within the same location."""
    want = norm(legacy_name)
    for name, d in opts:
        if norm(name) == want:
            return d

    def canon(n):
        n = norm(n)
        for a, b in BRAND_ALIASES:
            n = n.replace(a, b)
        return n

    def loc(n):
        m = re.search(r"\(([^()]*)\)\s*$", n)
        return m.group(1) if m else ""

    want_c = canon(legacy_name)
    best, best_r = None, 0.0
    for name, d in opts:
        c = canon(name)
        if c == want_c:
            return d
        if loc(c) != loc(want_c):
            continue
        r = difflib.SequenceMatcher(None, c, want_c).ratio()
        if r > best_r:
            best, best_r = (name, d), r
    if best and best_r >= 0.8:
        log("Matched", "'%s' -> '%s'" % (html.unescape(legacy_name), best[0]))
        return best[1]
    return None


# --------------------------------------------------------------------------- #
# Time helpers
# --------------------------------------------------------------------------- #

def parse_utc(s):
    s = s.replace("Z", "+00:00")
    return dt.datetime.fromisoformat(s).astimezone(dt.timezone.utc)


def fmt_time(t, utc):
    if utc:
        return t.astimezone(dt.timezone.utc).strftime("%Y%m%d%H%M%S +0000")
    return t.astimezone().strftime("%Y%m%d%H%M%S %z")


def iso(t):
    return t.astimezone(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S UTC")


# --------------------------------------------------------------------------- #
# Data model shared by both sources
# --------------------------------------------------------------------------- #

class Channel:
    def __init__(self, cid, number, callsign, names, icon=None, icon_wh=None):
        self.id = cid
        self.number = number
        self.callsign = callsign
        self.names = names          # extra names (station name, affiliate)
        self.icon = icon
        self.icon_wh = icon_wh


class Programme:
    __slots__ = ("channel", "start", "stop", "xml")

    def __init__(self, channel, start, stop, xml):
        self.channel, self.start, self.stop, self.xml = channel, start, stop, xml


def episode_nums(prog_id, season, episode, common):
    out = []
    try:
        s = int(season) if season not in (None, "", "0") else None
    except ValueError:
        s = None
    try:
        e = int(episode) if episode not in (None, "", "0") else None
    except ValueError:
        e = None
    if common and s and e:
        out.append(("common", "S%02dE%02d" % (s, e)))
    if prog_id:
        out.append(("dd_progid", "%s.%s" % (prog_id[:10], prog_id[10:14])))
    if e:
        out.append(("xmltv_ns", "%s.%d." % ("" if s is None else s - 1, e - 1)))
    return out


# --------------------------------------------------------------------------- #
# Gracenote
# --------------------------------------------------------------------------- #

class Gracenote:
    avail = None
    source = "gracenote.com"
    source_name = "Gracenote"

    def __init__(self, http, args, country):
        self.http, self.args, self.country = http, args, country

    def providers(self):
        url = "%s/gapzap_webapi/api/Providers/getPostalCodeProviders/%s/%s/gapzap/en-us" % (
            GN_BASE, self.country, urllib.parse.quote(self.args.g))
        d = self.http.json(url)
        out = []
        for p in d.get("Providers", []):
            name = p["name"] + (" (%s)" % p["location"] if p.get("location") else "")
            out.append((name, {
                "source": "gracenote", "lineup_name": name, "country": self.country,
                "postal": self.args.g, "lineupId": p["lineupId"],
                "headendId": p["headendId"], "device": p.get("device") or "-",
            }))
        return out

    def resolve(self, dat, legacy_name):
        if dat and dat.get("source") == "gracenote" and not self.args.lineup:
            return dat
        log("Connecting", "tvlistings.gracenote.com")
        opts = self.providers()
        if not opts:
            raise Fatal("no lineups found for %s %s" % (self.country, self.args.g))
        if legacy_name and not self.args.lineup:
            d = match_lineup(opts, legacy_name)
            if d:
                return d
            log("Warning", "lineup '%s' not found for %s" % (legacy_name, self.args.g))
        return choose(opts, "lineup")[1]

    def clean_cache(self):
        if not os.path.isdir("cache"):
            return
        n = 0
        cutoff = time.time() - 24 * 3600
        for fn in os.listdir("cache"):
            path = os.path.join("cache", fn)
            try:
                if fn.endswith((".js.gz", ".tmp")) and os.path.getmtime(path) < cutoff:
                    os.remove(path)
                    n += 1
            except OSError:
                pass
        if n:
            log("Cleaning cache", "Deleted %d" % n)

    def chunk(self, lu, t):
        cache_dir = "cache"
        os.makedirs(cache_dir, exist_ok=True)
        fn = os.path.join(cache_dir, "%s-%s-%d.js.gz" % (lu["postal"], lu["lineupId"], t))
        if not self.args.f and os.path.exists(fn) and time.time() - os.path.getmtime(fn) < 4 * 3600:
            with gzip.open(fn, "rb") as f:
                return json.loads(f.read().decode("utf-8"))
        q = {
            "lineupId": lu["lineupId"], "timespan": "6", "headendId": lu["headendId"],
            "country": lu["country"], "timezone": "", "device": lu["device"],
            "postalCode": lu["postal"], "isOverride": "true", "time": str(t),
            "pref": "16,128", "userId": "-", "aid": "orbebb", "languagecode": "en-us",
        }
        raw = self.http.request("%s/api/grid?%s" % (GN_BASE, urllib.parse.urlencode(q)))
        d = json.loads(raw.decode("utf-8"))
        with gzip.open(fn + ".tmp", "wb") as f:
            f.write(raw)
        os.replace(fn + ".tmp", fn)
        return d

    def fetch(self, lu, start, stop, chl, ren):
        self.clean_cache()
        t0 = int(start.timestamp()) // CHUNK * CHUNK
        times = list(range(t0, int(stop.timestamp()), CHUNK))
        log("Preparing", "%d hours, %d threads" % (self.args.d, self.args.threads))
        sys.stdout.write(_dots("Downloading") + ": gracenote.com (%d) " % len(times))
        sys.stdout.flush()
        results = {}
        with cf.ThreadPoolExecutor(self.args.threads) as ex:
            futs = {ex.submit(self.chunk, lu, t): t for t in times}
            for f in cf.as_completed(futs):
                results[futs[f]] = f.result()
                sys.stdout.write("-")
                sys.stdout.flush()
        print()
        return self.build([results[t] for t in sorted(results)], start, stop, chl, ren)

    def build(self, chunks, start, stop, chl, ren):
        a = self.args
        chans, order, events = {}, [], []
        for d in chunks:
            for c in d.get("channels", []):
                num = c.get("channelNo") or ""
                if a.i:
                    num = add_num(num, a.i)
                cs = c.get("callSign") or ""
                cid = "I%s.%s.%s" % (num, c.get("channelId"), self.source)
                keys = (cs.upper(), num.upper(), (c.get("channelNo") or "").upper(), cid.upper())
                self.avail.update(keys)
                if chl is not None and not chl.intersection(keys):
                    continue
                if cid not in chans:
                    icon = c.get("thumbnail") or ""
                    if icon:
                        icon = "https:" + icon.split("?")[0] if icon.startswith("//") else icon.split("?")[0]
                        icon = icon.replace("zap2it.tmsimg.com", "zpmc.tmsimg.com")
                    aff = network_label(c.get("affiliateName") or "", cs) if a.network_names else ""
                    chans[cid] = Channel(cid, num, cs, [aff] if aff else [], icon or None)
                    order.append(cid)
                for e in c.get("events", []):
                    events.append((cid, e))

        # first "New" airing date per program -> date / previously-shown on repeats
        first_new = {}
        seen = set()
        uniq = []
        for cid, e in events:
            key = (cid, e["startTime"])
            if key in seen:
                continue
            seen.add(key)
            uniq.append((cid, e))
            if e.get("thumbnail"):
                POSTERS.add(e["program"].get("id"), e["thumbnail"])
            if "New" in (e.get("flag") or []):
                pid = e["program"].get("id")
                day = parse_utc(e["startTime"]).strftime("%Y%m%d")
                if pid and (pid not in first_new or day < first_new[pid]):
                    first_new[pid] = day

        progs = []
        for cid, e in uniq:
            st, en = parse_utc(e["startTime"]), parse_utc(e["endTime"])
            if en <= start or st >= stop:
                continue
            progs.append(Programme(cid, st, en, self.prog_xml(cid, e, st, en, first_new)))
        return [chans[c] for c in order], progs

    def prog_xml(self, cid, e, st, en, first_new):
        a = self.args
        p = e.get("program") or {}
        flags = e.get("flag") or []
        tags = e.get("tags") or []
        pid = p.get("id") or p.get("tmsId") or ""
        title = p.get("title") or ""
        if a.a and "New" in flags:
            title += " [NEW]"
        elif a.A and "Live" in flags:
            title += " [LIVE]"
        L = ['\t<programme start="%s" stop="%s" channel="%s">' % (
            fmt_time(st, a.u), fmt_time(en, a.u), esc(cid))]
        L.append('\t\t<title lang="en">%s</title>' % esc(title))
        if p.get("episodeTitle"):
            L.append('\t\t<sub-title lang="en">%s</sub-title>' % esc(p["episodeTitle"]))
        if p.get("shortDesc"):
            L.append('\t\t<desc lang="en">%s</desc>' % esc(p["shortDesc"]))
        date = None
        if pid.startswith("MV") and p.get("releaseYear"):
            date = str(p["releaseYear"])
        elif pid in first_new:
            date = first_new[pid]
        if date:
            L.append("\t\t<date>%s</date>" % date)
        cats = []
        for f in e.get("filter") or []:
            c = GN_FILTERS.get(f) or f.replace("filter-", "").replace("-", " ").title()
            if c not in cats:
                cats.append(c)
        if pid.startswith("MV") and "Movie" not in cats:
            cats.insert(0, "Movie")
        if pid[:2] in ("EP", "SH") and "Series" not in cats:
            cats.append("Series")
        for c in cats:
            L.append('\t\t<category lang="en">%s</category>' % esc(c))
        if e.get("duration"):
            L.append('\t\t<length units="minutes">%s</length>' % esc(e["duration"]))
        if e.get("thumbnail"):
            L.append('\t\t<icon src="%s" />' % esc(gn_poster(e["thumbnail"])))
        if pid:
            L.append("\t\t<url>%s</url>" % esc(
                "%s//overview-affiliates.html?programSeriesId=%s&tmsId=%s" % (
                    GN_BASE, e.get("seriesId") or p.get("seriesId") or "", pid)))
        for sysname, val in episode_nums(pid, p.get("season"), p.get("episode"), True):
            L.append('\t\t<episode-num system="%s">%s</episode-num>' % (sysname, esc(val)))
        if "Stereo" in tags:
            L.append("\t\t<audio>\n\t\t\t<stereo>stereo</stereo>\n\t\t</audio>")
        if "New" in flags:
            L.append("\t\t<new />")
        elif pid in first_new:
            L.append('\t\t<previously-shown start="%s000000" />' % first_new[pid])
        else:
            L.append("\t\t<previously-shown />")
        if "Premiere" in flags:
            L.append("\t\t<premiere />")
        if "CC" in tags:
            L.append('\t\t<subtitles type="teletext" />')
        if e.get("rating"):
            L.append("\t\t<rating>\n\t\t\t<value>%s</value>\n\t\t</rating>" % esc(e["rating"]))
        L.append("\t</programme>")
        return "\n".join(L)


GN_FILTERS = {
    "filter-movie": "Movie", "filter-movies": "Movie", "filter-news": "News",
    "filter-sports": "Sports", "filter-talk": "Talk", "filter-kids": "Children",
    "filter-family": "Family",
}


def add_num(num, n):
    m = re.match(r"^(\d+)(.*)$", num or "")
    return "%d%s" % (int(m.group(1)) + n, m.group(2)) if m else num


# --------------------------------------------------------------------------- #
# Schedules Direct
# --------------------------------------------------------------------------- #

class SchedulesDirect:
    avail = None
    source = "schedulesdirect.org"
    source_name = "Schedules Direct"

    def __init__(self, http, args, country):
        self.http, self.args, self.country = http, args, country
        self.token = None
        user, pw = split_login(args.J)
        self.user, self.pw = user, pw
        self.cache = os.path.join(os.environ.get("MC2XML_CACHE") or os.path.expanduser("~/.cache/mc2xml"), "sd")
        os.makedirs(self.cache, mode=0o700, exist_ok=True)
        self.lineup_modified = {}

    def call(self, path, data=None, method=None):
        hdrs = {"User-Agent": SD_UA}
        if self.token:
            hdrs["token"] = self.token
        return self.http.json(SD_BASE + path, data=data, headers=hdrs, method=method)

    def login(self):
        log("Connecting", "schedulesdirect.org")
        # tokens are valid ~24h; reuse one instead of logging in on every run
        tok_file = os.path.join(self.cache, "token-%s.json" % hashlib.sha1(self.user.encode()).hexdigest()[:12])
        st = None
        try:
            with open(tok_file) as f:
                tk = json.load(f)
        except (OSError, ValueError):
            tk = None
        if tk and tk.get("expires", 0) - time.time() > 3600 and not self.args.f:
            self.token = tk.get("token")
            try:
                st = self.call("/status")
                if st.get("code", 0) != 0:
                    st = None
            except Fatal:
                st = None
        if st is None:
            self.token = None
            r = self.call("/token", {"username": self.user,
                                     "password": hashlib.sha1(self.pw.encode()).hexdigest()})
            if r.get("code", 0) != 0 or not r.get("token"):
                raise Fatal("Schedules Direct login failed: %s" % r.get("message", r))
            self.token = r["token"]
            expires = r.get("tokenExpires") or time.time() + 20 * 3600
            fd = os.open(tok_file + ".tmp", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w") as f:
                json.dump({"token": self.token, "expires": expires}, f)
            os.replace(tok_file + ".tmp", tok_file)
            st = self.call("/status")
        acct = st.get("account", {})
        log("Account status", "Expires %s" % acct.get("expires", "?"))
        log("Account status", "%d/%d lineups" % (len(st.get("lineups", [])), acct.get("maxLineups", 0)))
        exp = acct.get("expires")
        if exp:
            try:
                if parse_utc(exp) < dt.datetime.now(dt.timezone.utc):
                    raise Fatal("Schedules Direct account expired on %s" % exp)
            except ValueError:
                pass
        self.account_lineups = {l["lineup"] for l in st.get("lineups", []) if not l.get("isDeleted")}
        self.lineup_modified = {l["lineup"]: l.get("modified") for l in st.get("lineups", [])}

    def headends(self):
        q = urllib.parse.urlencode({"country": self.country, "postalcode": self.args.g})
        out = []
        for h in self.call("/headends?" + q):
            for l in h.get("lineups", []):
                name = "%s (%s)" % (l["name"], h.get("location", ""))
                out.append((name, {"source": "sd", "lineup_name": name, "lineup": l["lineup"],
                                   "country": self.country, "postal": self.args.g}))
        return out

    def account_options(self):
        """Lineups already on the account, named like an original mc2xml .dat ("Name (Location)")."""
        out = []
        try:
            for l in self.call("/lineups").get("lineups", []):
                if l.get("isDeleted"):
                    continue
                name = "%s (%s)" % (l.get("name", ""), l.get("location", ""))
                out.append((name, {"source": "sd", "lineup_name": name, "lineup": l["lineup"],
                                   "country": self.country, "postal": self.args.g or ""}))
        except Fatal:
            pass
        return out

    def resolve(self, dat, legacy_name):
        self.login()
        picked = False                                  # True when the user chose it from the list just now
        if dat and dat.get("source") == "sd" and not self.args.lineup:
            lu = dat
        else:
            lu = None
            if legacy_name and not self.args.lineup:
                # 1) an original mc2xml .dat: look on the account first - no zip code needed, no changes
                lu = match_lineup(self.account_options(), legacy_name)
                if lu:
                    log("Found", "%s on your Schedules Direct account" % lu["lineup"])
            if not lu:
                if not self.args.g:
                    raise Fatal("lineup '%s' is not on your Schedules Direct account - add -g <zip/postal code> to search for it, "
                                "or run once with --lineup to pick it" % html.unescape(legacy_name or "?"))
                opts = self.headends()
                guessed = False
                if legacy_name and not self.args.lineup:
                    # prefer a lineup already on the account when names repeat
                    hits = [d for n, d in opts if norm(n) == norm(legacy_name)]
                    hits.sort(key=lambda d: d["lineup"] not in self.account_lineups)
                    if hits:
                        lu = hits[0]
                    else:
                        lu = match_lineup(opts, legacy_name)
                        guessed = lu is not None
                    if not lu:
                        log("Warning", "lineup '%s' not found for %s" % (legacy_name, self.args.g))
                if lu and guessed and lu["lineup"] not in self.account_lineups:
                    # never spend one of the account's daily lineup changes on a guess
                    if not sys.stdin.isatty():
                        raise Fatal("'%s' looks like %s, which is not on your Schedules Direct account yet - "
                                    "run once by hand with --lineup to choose it" % (html.unescape(legacy_name), lu["lineup"]))
                    if input("Add %s to your Schedules Direct account? [y/N]: " % lu["lineup"]).strip().lower() not in ("y", "yes"):
                        lu = None
                    else:
                        picked = True
            if not lu:
                lu = choose(opts, "lineup")[1]
                picked = True
        if lu["lineup"] not in self.account_lineups and not picked:
            # Never add a lineup to the account unattended (daily builds, the Guide Builder): it uses one of the
            # account's daily lineup changes and can bring back a lineup you removed on the Schedules Direct website.
            name = html.unescape(lu.get("lineup_name") or lu["lineup"])
            if self.args.add_lineup:
                pass
            elif sys.stdin.isatty():
                if input("%s is not on your Schedules Direct account. Add it? (uses one of the account's daily lineup changes) "
                         "[y/N]: " % name).strip().lower() not in ("y", "yes"):
                    raise Fatal("%s was not added to your Schedules Direct account" % name)
            else:
                raise Fatal("%s isn't on your Schedules Direct account anymore - add it again in the Guide Builder "
                            "(Providers -> Channels) or on schedulesdirect.org, or run once with --add-lineup" % name)
        if lu["lineup"] not in self.account_lineups:
            log("Adding", "%s to your Schedules Direct account (uses one of the account's daily lineup changes)" % lu["lineup"])
            r = self.call("/lineups/" + lu["lineup"], method="PUT")
            if r.get("code", 0) != 0:
                raise Fatal("could not add lineup: %s" % r.get("message", r))
        return lu

    def cpath(self, *parts):
        return os.path.join(self.cache, *parts)

    def clean_cache(self):
        """Drop schedules for past days and programs not used for 3 weeks."""
        old_day = (dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=2)).date().isoformat()
        n = 0
        sdir = self.cpath("schedules")
        if os.path.isdir(sdir):
            for fn in os.listdir(sdir):
                day = fn.split("_")[-1][:10]
                if day < old_day:
                    try:
                        os.remove(os.path.join(sdir, fn))
                        n += 1
                    except OSError:
                        pass
        cutoff = time.time() - 21 * 86400
        pdir = self.cpath("programs")
        if os.path.isdir(pdir):
            for sub in os.listdir(pdir):
                d = os.path.join(pdir, sub)
                for fn in os.listdir(d):
                    f = os.path.join(d, fn)
                    try:
                        if os.path.getmtime(f) < cutoff:
                            os.remove(f)
                            n += 1
                    except OSError:
                        pass
        if n:
            log("Cleaning cache", "Deleted %d" % n)

    def fetch(self, lu, start, stop, chl, ren):
        a = self.args
        self.clean_cache()
        lid = lu["lineup"]
        mod = self.lineup_modified.get(lid)
        m = None if a.f else jread(self.cpath("lineups", lid + ".json.gz"))
        if not m or not mod or m.get("_modified") != mod:
            m = self.call("/lineups/" + lid)
            m["_modified"] = mod
            jwrite(self.cpath("lineups", lid + ".json.gz"), m)
        stations = {s["stationID"]: s for s in m.get("stations", [])}
        chans, sids = [], []
        seen = set()
        for e in m.get("map", []):
            sid = e["stationID"]
            num = e.get("channel") or e.get("virtualChannel")
            if not num and e.get("atscMajor") is not None:
                num = "%s.%s" % (e["atscMajor"], e.get("atscMinor", 0))
            if not num:
                num = str(e.get("uhfVhf") or e.get("logicalChannelNumber") or "")
            num = num.lstrip("0") or num
            if a.i:
                num = add_num(num, a.i)
            st = stations.get(sid, {})
            cs = st.get("callsign") or ""
            cid = "I%s.%s.%s" % (num, sid, self.source)
            keys = (cs.upper(), num.upper(), sid, cid.upper())
            self.avail.update(keys)
            if chl is not None and not chl.intersection(keys):
                continue
            if cid in seen:
                continue
            seen.add(cid)
            extra = []
            for n in (st.get("name"), st.get("affiliate")):
                if n and n not in extra:
                    extra.append(n)
            icon, wh = pick_logo(st)
            chans.append(Channel(cid, num, cs, extra, icon, wh))
            sids.append((sid, cid))

        if not chans:
            raise Fatal("no channels matched the channel file")
        log("Preparing", "%d stations, %d hours, %d threads" % (len(set(s for s, _ in sids)), a.d, a.threads))

        days = []
        d0 = start.astimezone(dt.timezone.utc).date()
        while dt.datetime.combine(d0, dt.time(), dt.timezone.utc) < stop:
            days.append(d0.isoformat())
            d0 += dt.timedelta(days=1)
        uniq_sids = sorted(set(s for s, _ in sids))
        batches = [uniq_sids[i:i + 500] for i in range(0, len(uniq_sids), 500)]

        # 1) ask which station/day schedules changed (md5), use cached copies for the rest
        md5s = {}
        if not a.f:
            try:
                with cf.ThreadPoolExecutor(a.threads) as ex:
                    for r in ex.map(lambda b: self.call("/schedules/md5", [{"stationID": s, "date": days} for s in b]), batches):
                        if isinstance(r, dict):
                            md5s.update(r)
            except Fatal as e:
                log("Warning", "schedule md5 check failed, downloading everything (%s)" % e)
                md5s = {}
        scheds, need = [], {}
        for sid in uniq_sids:
            for d in days:
                info = (md5s.get(sid) or {}).get(d) if md5s else None
                if md5s and (not info or info.get("code", 0) != 0):
                    continue            # Schedules Direct has no data for that day
                c = jread(self.cpath("schedules", "%s_%s.json.gz" % (sid, d))) if info else None
                if c and c.get("metadata", {}).get("md5") == info.get("md5"):
                    scheds.append(c)
                else:
                    need.setdefault(sid, []).append(d)
        need_total = sum(len(v) for v in need.values())
        nb = [sorted(need)[i:i + 500] for i in range(0, len(need), 500)]
        sys.stdout.write(_dots("Downloading") + ": schedules (%d of %d changed) " % (
            need_total, len(uniq_sids) * len(days)))
        with cf.ThreadPoolExecutor(a.threads) as ex:
            for r in ex.map(lambda b: self.call("/schedules", [{"stationID": s, "date": need[s]} for s in b]), nb):
                for x in r:
                    if isinstance(x, dict) and "programs" in x:
                        scheds.append(x)
                        day = (x.get("metadata") or {}).get("startDate")
                        if day:
                            jwrite(self.cpath("schedules", "%s_%s.json.gz" % (x["stationID"], day)), x)
                sys.stdout.write(".")
                sys.stdout.flush()
        print()

        airings = {}
        pmd5 = {}
        for s in scheds:
            for p in s["programs"]:
                t = parse_utc(p["airDateTime"])
                e = t + dt.timedelta(seconds=int(p.get("duration", 0)))
                if e <= start or t >= stop:
                    continue
                airings.setdefault(s["stationID"], {})[p["airDateTime"]] = (t, e, p)
                pmd5[p["programID"]] = p.get("md5")

        # 2) programs: only download ones that are new or whose md5 changed
        programs, pids = {}, []
        for pid in sorted(pmd5):
            f = self.cpath("programs", pid[:6], pid + ".json.gz")
            c = None if a.f else jread(f)
            if c and pmd5[pid] and c.get("md5") == pmd5[pid]:
                programs[pid] = c
                try:
                    os.utime(f)
                except OSError:
                    pass
            else:
                pids.append(pid)
        log("Preparing", "%d programs (%d cached), %d threads" % (len(pmd5), len(programs), a.threads + 1))
        pbatches = [pids[i:i + 5000] for i in range(0, len(pids), 5000)]
        sys.stdout.write(_dots("Downloading") + ": programs (%d) " % len(pids))
        with cf.ThreadPoolExecutor(a.threads + 1) as ex:
            for r in ex.map(lambda b: self.call("/programs", b), pbatches):
                for x in r:
                    if isinstance(x, dict) and x.get("programID"):
                        programs[x["programID"]] = x
                        jwrite(self.cpath("programs", x["programID"][:6], x["programID"] + ".json.gz"), x)
                sys.stdout.write(".")
                sys.stdout.flush()
        print()

        progs = []
        for sid, cid in sids:
            for key in sorted(airings.get(sid, {})):
                t, e, sp = airings[sid][key]
                prog = programs.get(sp["programID"], {})
                progs.append(Programme(cid, t, e, self.prog_xml(cid, t, e, sp, prog)))
        return chans, progs

    def prog_xml(self, cid, st, en, s, p):
        a = self.args
        pid = s["programID"]
        is_movie = pid.startswith("MV") or p.get("entityType") == "Movie"
        title = ((p.get("titles") or [{}])[0]).get("title120") or ""
        if a.a and s.get("new"):
            title += " [NEW]"
        elif a.A and s.get("liveTapeDelay") == "Live":
            title += " [LIVE]"
        L = ['\t<programme start="%s" stop="%s" channel="%s">' % (
            fmt_time(st, a.u), fmt_time(en, a.u), esc(cid))]
        L.append('\t\t<title lang="en">%s</title>' % esc(title))
        if p.get("episodeTitle150"):
            L.append('\t\t<sub-title lang="en">%s</sub-title>' % esc(p["episodeTitle150"]))
        desc = None
        ds = p.get("descriptions") or {}
        for k in ("description1000", "description100"):
            if ds.get(k):
                desc = ds[k][0].get("description")
                if desc:
                    break
        if desc:
            L.append('\t\t<desc lang="en">%s</desc>' % esc(desc))
        credits = sd_credits(p)
        if credits:
            L.append("\t\t<credits>")
            for role, name in credits:
                L.append("\t\t\t<%s>%s</%s>" % (role, esc(name), role))
            L.append("\t\t</credits>")
        oad = (p.get("originalAirDate") or "").replace("-", "")
        movie = p.get("movie") or {}
        if is_movie and movie.get("year"):
            L.append("\t\t<date>%s</date>" % esc(movie["year"]))
        elif oad:
            L.append("\t\t<date>%s</date>" % oad)
        cats = []
        if is_movie:
            cats.append("Movie")
        for g in p.get("genres") or []:
            if g not in cats:
                cats.append(g)
        for c in cats:
            L.append('\t\t<category lang="en">%s</category>' % esc(c))
        L.append('\t\t<length units="seconds">%d</length>' % int(s.get("duration", 0)))
        poster = POSTERS.get(pid)
        if poster:
            L.append('\t\t<icon src="%s" />' % esc(poster))
        meta = {}
        for m in p.get("metadata") or []:
            if "Gracenote" in m:
                meta = m["Gracenote"]
        for sysname, val in episode_nums(pid, meta.get("season"), meta.get("episode"), False):
            L.append('\t\t<episode-num system="%s">%s</episode-num>' % (sysname, esc(val)))
        vp = [v.lower() for v in s.get("videoProperties") or []]
        if any(v.startswith("hd") or v == "uhdtv" for v in vp):
            L.append("\t\t<video>\n\t\t\t<aspect>16:9</aspect>\n\t\t\t<quality>HDTV</quality>\n\t\t</video>")
        ap = [x.lower() for x in s.get("audioProperties") or []]
        stereo = None
        if any("dolby" in x or x.startswith("dd") for x in ap):
            stereo = "dolby digital"
        elif "surround" in ap:
            stereo = "surround"
        elif "stereo" in ap:
            stereo = "stereo"
        elif "mono" in ap:
            stereo = "mono"
        if stereo:
            L.append("\t\t<audio>\n\t\t\t<stereo>%s</stereo>\n\t\t</audio>" % stereo)
        if s.get("new"):
            L.append("\t\t<new />")
        elif oad and not is_movie:
            L.append('\t\t<previously-shown start="%s000000" />' % oad)
        elif not is_movie:
            L.append("\t\t<previously-shown />")
        if s.get("premiere") or "Premiere" in (s.get("isPremiereOrFinale") or ""):
            L.append("\t\t<premiere />")
        if "cc" in ap:
            L.append('\t\t<subtitles type="teletext" />')
        ratings = {}
        for r in (s.get("ratings") or []) + (p.get("contentRating") or []):
            body, code = r.get("body"), r.get("code")
            if body and code:
                ratings.setdefault(body, code)
        for body in sorted(ratings):
            L.append('\t\t<rating system="%s">\n\t\t\t<value>%s</value>\n\t\t</rating>' % (
                esc(body), esc(ratings[body])))
        for adv in p.get("contentAdvisory") or []:
            L.append('\t\t<rating system="advisory">\n\t\t\t<value>%s</value>\n\t\t</rating>' % esc(adv))
        qr = movie.get("qualityRating") or []
        if qr and qr[0].get("rating"):
            L.append("\t\t<star-rating>\n\t\t\t<value>%s/%s</value>\n\t\t</star-rating>" % (
                esc(qr[0]["rating"]), esc(qr[0].get("maxRating", "4"))))
        L.append("\t</programme>")
        return "\n".join(L)


CREDIT_ORDER = ["director", "actor", "writer", "adapter", "producer", "composer",
                "editor", "presenter", "commentator", "guest"]


def credit_role(role):
    r = (role or "").lower()
    if r == "director":
        return "director"
    if r == "writer":
        return "writer"
    if "producer" in r:
        return "producer"
    if r in ("host", "anchor", "presenter", "co-host", "narrator", "correspondent"):
        return "presenter"
    if r in ("commentator", "analyst", "play-by-play"):
        return "commentator"
    if "guest" in r:
        return "guest"
    return "actor"


def sd_credits(p):
    out = {k: [] for k in CREDIT_ORDER}
    for grp in ("cast", "crew"):
        for c in sorted(p.get(grp) or [], key=lambda c: c.get("billingOrder", "99")):
            name = c.get("name")
            if not name:
                continue
            role = credit_role(c.get("role"))
            if name not in out[role]:
                out[role].append(name)
    return [(r, n) for r in CREDIT_ORDER for n in out[r]]


def pick_logo(st):
    logos = st.get("stationLogo") or []
    for want in ("dark", "white", "light", "gray"):
        for l in logos:
            if l.get("category") == want and l.get("URL"):
                return l["URL"], (l.get("width"), l.get("height"))
    if logos and logos[0].get("URL"):
        return logos[0]["URL"], (logos[0].get("width"), logos[0].get("height"))
    lg = st.get("logo") or {}
    if lg.get("URL"):
        return lg["URL"], (lg.get("width"), lg.get("height"))
    return None, None


IMG_HOST = "https://zpmc.tmsimg.com"     # zap2it.tmsimg.com no longer resolves


def gn_poster(thumb):
    return "%s/assets/%s.jpg?w=360" % (IMG_HOST, thumb)


def poster_key(pid):
    """Series-level key shared by Gracenote and Schedules Direct ids (both are TMS ids)."""
    if not pid:
        return None
    return ("SH" + pid[2:10]) if pid[:2] in ("EP", "SH") else pid[:10]


class Posters:
    """Public Gracenote poster per series/movie, learned from Gracenote listings and reused
    for Schedules Direct programs (SD's own images need a login, so they can't be linked)."""
    def __init__(self):
        root = os.environ.get("MC2XML_CACHE") or os.path.expanduser("~/.cache/mc2xml")
        self.path = os.path.join(root, "posters.json.gz")
        self.new = {}
        self.data = jread(self.path) or {}

    def get(self, pid):
        v = self.data.get(poster_key(pid) or "")
        return gn_poster(v[0]) if v else None

    def add(self, pid, thumb):
        k = poster_key(pid)
        if k and thumb:
            self.new[k] = [thumb, int(time.time())]

    def save(self):
        if not self.new:
            return
        cur = jread(self.path) or {}          # merge with other runs' updates
        cur.update(self.new)
        cutoff = time.time() - 120 * 86400
        cur = {k: v for k, v in cur.items() if v[1] >= cutoff}
        jwrite(self.path, cur)


def jread(path):
    try:
        with gzip.open(path, "rb") as f:
            return json.loads(f.read().decode("utf-8"))
    except (OSError, ValueError, EOFError):
        return None


def jwrite(path, obj):
    os.makedirs(os.path.dirname(path), mode=0o700, exist_ok=True)
    tmp = "%s.%d.%d.tmp" % (path, os.getpid(), threading.get_ident())
    with gzip.open(tmp, "wb", compresslevel=5) as f:
        f.write(json.dumps(obj, ensure_ascii=False).encode("utf-8"))
    os.replace(tmp, path)


def split_login(s):
    if s.startswith("@"):
        path = os.path.expanduser(os.path.expandvars(s[1:]))
        try:
            with open(path, encoding="utf-8") as f:
                s = f.read().strip().splitlines()[0].strip()
        except (OSError, IndexError):
            raise Fatal("cannot read Schedules Direct login file %s" % path)
        try:
            if os.stat(path).st_mode & 0o077:
                log("Warning", "%s is readable by other users; run: chmod 600 %s" % (path, path))
        except OSError:
            pass
    for sep in (":", "/"):
        if sep in s:
            u, p = s.split(sep, 1)
            return u, p
    raise Fatal("-J expects user:password")


# --------------------------------------------------------------------------- #
# Output
# --------------------------------------------------------------------------- #

WORDS = set("""movies movie news kids west western westerns comedy catchy weather sports sport network channel television
classic classics family life living home food travel history science nature music country gospel faith mystery crime true
drama action cinema plus more world shop shopping live local grit bounce laff court heroes icons start story reality outdoors
outdoor binge rewind retro antenna decades defy dabl cozi buzzr charge comet quest nosey bark doctor daystar jewelry america
american entertainment broadcasting company service system the and of tv star stars hits gold good great real fun game games
shows show room create world worldwide cartoons cartoon toons junior learn learning weather business finance spanish latino
noticias deportes cine canal first merit""".split())
SMALL = {"de", "la", "el", "fe", "del", "los", "las", "the", "and", "of"}          # always "De", "La"...
BRANDS = {"estrellatv": "EstrellaTV", "metv": "MeTV", "metv+": "MeTV+", "shop lc": "ShopLC", "hot 97": "HOT 97"}


def nice_name(s):
    """"FOX ENTERTAINMENT" -> "FOX Entertainment", "MOVIES!" -> "Movies!". Short brand names in capitals
    (ESPN, HGTV, CNBC, FOX) stay as they are; only ordinary words are softened."""
    s = re.sub(r"\s+", " ", s or "").strip()
    if not s or not s.isupper():
        return s
    if s.lower() in BRANDS:
        return BRANDS[s.lower()]

    def fix(m):
        w = m.group(0)
        if w.lower() in SMALL:
            return w.capitalize()
        if len(w) <= 3 or (len(w) <= 5 and w.lower() not in WORDS):
            return BRANDS.get(w.lower(), w)
        return BRANDS.get(w.lower(), w.capitalize())
    return re.sub(r"[^\W\d_]+", fix, s)


BIG_NETWORKS = {"national broadcasting company": "NBC", "american broadcasting company": "ABC",
                "columbia broadcasting system": "CBS", "cbs": "CBS", "cbs television network": "CBS", "fox entertainment": "FOX",
                "ion: independent television": "ION", "ion": "ION", "me tv network": "MeTV", "metv": "MeTV",
                "canadian broadcasting corporation": "CBC", "cbc": "CBC", "ctv": "CTV", "global": "Global",
                "societe radio-canada": "ICI Radio-Canada", "tva": "TVA",
                "fox broadcasting company": "FOX", "public broadcasting service": "PBS",
                "the cw television network": "The CW", "the cw": "The CW", "cw": "The CW",
                "telemundo": "Telemundo", "univision": "Univision", "unimas": "UniMás",
                "ion television": "ION", "mynetworktv": "MyNetworkTV", "my network tv": "MyNetworkTV"}


def network_label(aff, callsign):
    """Name for --network-names: "NBC (WDIV)" for the big networks (every city has its own NBC),
    otherwise the network's own name ("Movies!", "Catchy Comedy"). "" = keep the call sign."""
    a = re.sub(r"\s+", " ", aff or "").strip()
    if not a or a.lower() in ("independent", "ind"):
        return ""
    big = BIG_NETWORKS.get(a.lower())
    if big:
        root = re.sub(r"(DT|LD|CD|LP|TV)\d*$", "", (callsign or "").upper()) or callsign
        return "%s (%s)" % (big, root) if root else big
    return nice_name(a)


def channel_xml(c, ren, name_first, network_names=False, num=None):
    name = ren.get(c.id.upper()) or ren.get(c.callsign.upper()) or ren.get(c.number.upper()) or \
        (c.names[0] if network_names and c.names else "") or c.callsign or c.number   # (the id: when call sign and number repeat)
    number = num or c.number                     # your own channel number (Guide Builder) or the lineup's
    L = ['\t<channel id="%s">' % esc(c.id)]
    first = [name, "%s %s" % (number, name)] if name_first else ["%s %s" % (number, name), name]
    names = []
    for n in first + [number] + c.names:
        if n and n not in names:
            names.append(n)
    for n in names:
        L.append("\t\t<display-name>%s</display-name>" % esc(n))
    if c.icon:
        if c.icon_wh and c.icon_wh[0] and c.icon_wh[1]:
            L.append('\t\t<icon src="%s" width="%s" height="%s" />' % (esc(c.icon), c.icon_wh[0], c.icon_wh[1]))
        else:
            L.append('\t\t<icon src="%s" />' % esc(c.icon))
    L.append("\t</channel>")
    return "\n".join(L)


def load_tweaks(path):
    """{KEY: {"num": str, "shift": hours}} - KEY is a call sign, channel number or channel id."""
    if not path or not os.path.exists(path):
        return {}
    log("Reading", path)
    try:
        with open(path, encoding="utf-8") as f:
            raw = json.load(f)
        return {str(k).upper(): v for k, v in raw.items() if isinstance(v, dict)}
    except (OSError, ValueError) as e:
        log("Warning", "could not read %s: %s" % (path, e))
        return {}


RE_TIME = re.compile(r'\b(start|stop)="(\d{14})( ?[+-]\d{4})?"')


def shift_times(xml, hours):
    """Moves a programme's start/stop by some hours (e.g. +3 for a West Coast feed)."""
    def mv(m):
        t = dt.datetime.strptime(m.group(2), "%Y%m%d%H%M%S") + dt.timedelta(hours=hours)
        return '%s="%s%s"' % (m.group(1), t.strftime("%Y%m%d%H%M%S"), m.group(3) or "")
    return RE_TIME.sub(mv, xml, count=2)


RE_CHAN = re.compile(r'^[ \t]*<channel id="([^"]*)".*?</channel>', re.S | re.M)
RE_PROG = re.compile(r'^[ \t]*<programme [^>]*channel="([^"]*)".*?</programme>', re.S | re.M)


def read_include(path):
    log("Reading", path)
    with open(path, "rb") as f:
        raw = f.read()
    m = re.search(rb'encoding="([^"]+)"', raw[:200])
    enc = m.group(1).decode() if m else "utf-8"
    txt = raw.decode(enc, errors="replace")
    chans = [(m.group(1), m.group(0).strip("\n")) for m in RE_CHAN.finditer(txt)]
    progs = [(m.group(1), m.group(0).strip("\n")) for m in RE_PROG.finditer(txt)]
    return chans, progs


def write_output(path, source_name, chan_xml, prog_xml, utf8):
    enc = "UTF-8" if utf8 else "ISO-8859-1"
    parts = ['<?xml version="1.0" encoding="%s"?>' % enc,
             '<!DOCTYPE tv SYSTEM "xmltv.dtd">', "",
             '<tv source-info-name="%s" generator-info-name="mc2xml (EPGTalk edition by aCiDjEsUs)" generator-info-url="https://epgtalk.com">' % esc(source_name)]
    parts.extend(chan_xml)
    parts.extend(prog_xml)
    parts.append("</tv>\n")
    data = "\n".join(parts)
    data = data.encode("utf-8") if utf8 else data.encode("iso-8859-1", "xmlcharrefreplace")
    log("Writing", path)
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(data)
    os.replace(tmp, path)
    return len(data)


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #

def parse_args(argv):
    ap = argparse.ArgumentParser(prog="mc2xml", add_help=False, allow_abbrev=False)
    ap.add_argument("-h", "-?", "--help", dest="h", action="store_true")
    ap.add_argument("-J")
    ap.add_argument("-c", default="us")
    ap.add_argument("-g", default="")
    ap.add_argument("-D", default="mc2xml.dat")
    ap.add_argument("-C", default="mc2xml.chl")
    ap.add_argument("-R", default="mc2xml.ren")
    ap.add_argument("-o", default="xmltv.xml")
    ap.add_argument("-I", action="append", default=[])
    ap.add_argument("-d", type=int, default=168)
    ap.add_argument("-s", type=int, default=0)
    ap.add_argument("-i", type=int, default=0)
    for flag in ("a", "A", "F", "U", "u", "f", "L", "T", "1"):
        ap.add_argument("-" + flag, action="store_true")
    ap.add_argument("--movie-details", type=int, default=0)
    ap.add_argument("--threads", type=int, default=3)
    ap.add_argument("--lineup", action="store_true")
    ap.add_argument("--network-names", dest="network_names", action="store_true")
    ap.add_argument("--add-lineup", action="store_true")     # allow adding a lineup to the SD account unattended
    ap.add_argument("--tweaks", default="")                 # JSON: {"KEY": {"num": "2", "shift": 3}} (Guide Builder)
    return ap.parse_args(argv)


POSTERS = None


def main(argv):
    global POSTERS
    a = parse_args(argv)
    POSTERS = Posters()
    if a.h:
        print(__doc__)
        return 0
    t_start = time.time()
    log("Loading", "mc2xml %s EPGTalk edition, %s" % (VERSION, CREDIT))
    cc = a.c.lower()
    country = COUNTRIES.get(cc, cc.upper())
    http = Http()

    dat, legacy = load_dat(a.D)
    if not a.g and dat:
        a.g = dat.get("postal", "")
    if not a.g and not a.J:                       # Schedules Direct can use the lineups on the account
        raise Fatal("postal code required (-g)")
    src = SchedulesDirect(http, a, country) if a.J else Gracenote(http, a, country)
    lu = src.resolve(dat, legacy)
    chl = load_chl(a.C)

    now = dt.datetime.now(dt.timezone.utc).replace(minute=0, second=0, microsecond=0)
    start = now + dt.timedelta(hours=a.s)
    stop = start + dt.timedelta(hours=a.d)
    src.avail = set()
    chans, progs = src.fetch(lu, start, stop, chl, None)
    if chl:
        missing = sorted(chl - src.avail)
        if missing:
            shown = ", ".join(missing[:20]) + (", ... (+%d more)" % (len(missing) - 20) if len(missing) > 20 else "")
            log("Not found", "%d of %d %s entries are not in this lineup: %s" % (
                len(missing), len(chl), os.path.basename(a.C), shown))
    log("Downloaded", "%d bytes in %ds" % (http.bytes, time.time() - t_start))
    log("Parsing", lu["lineup_name"])
    if not progs:
        raise Fatal("no programs downloaded")
    log("Start time", iso(min(p.start for p in progs)))
    log("End time", iso(max(p.stop for p in progs)))

    ren = load_ren(a.R)
    tw = load_tweaks(a.tweaks)
    tw_of = {}
    for c in chans:
        t = tw.get(c.callsign.upper()) or tw.get(c.number.upper()) or tw.get(c.id.upper())
        if t:
            tw_of[c.id] = t
    chan_xml = [channel_xml(c, ren, a.F, a.network_names, str(tw_of.get(c.id, {}).get("num") or "").strip() or None)
                for c in chans]
    for p in progs:
        h = tw_of.get(p.channel, {}).get("shift")
        if h:
            p.xml = shift_times(p.xml, float(h))
    prog_xml = [p.xml for p in sorted(progs, key=lambda p: (chans_index(chans, p.channel), p.start))]
    ids = {c.id for c in chans}
    for inc in a.I:
        if not os.path.exists(inc):
            raise Fatal("include file not found: %s" % inc)
        ic, ip = read_include(inc)
        chan_xml += [x for cid, x in ic if cid not in ids]
        prog_xml += [x for cid, x in ip if cid not in ids]
        ids |= {cid for cid, _ in ic}

    size = write_output(a.o, src.source_name, chan_xml, prog_xml, a.U)
    save_dat(a.D, lu)
    POSTERS.save()
    log("Completed", "%d bytes in %ds, %d channels, %d programs scheduled." % (
        size, time.time() - t_start, len(chan_xml), len(prog_xml)))
    return 0


_idx_cache = {}


def chans_index(chans, cid):
    if not _idx_cache:
        for i, c in enumerate(chans):
            _idx_cache[c.id] = i
    return _idx_cache.get(cid, 0)


if __name__ == "__main__":
    if os.environ.get("PYTHONIOENCODING"):              # output read by the Guide Builder (also as mc2xml.exe)
        try:
            sys.stdout.reconfigure(encoding=os.environ["PYTHONIOENCODING"], errors="replace")
        except Exception:
            pass
    try:
        sys.exit(main(sys.argv[1:]))
    except Fatal as e:
        log("Error", str(e))
        sys.exit(1)
    except KeyboardInterrupt:
        sys.exit(130)
