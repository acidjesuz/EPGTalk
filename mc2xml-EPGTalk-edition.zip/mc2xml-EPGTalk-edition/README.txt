mc2xml - EPGTalk edition
Made by aCiDjEsUs - EPGTalk.com
=========================================================

>> For the full step-by-step guide, open GUIDE.html in any web browser. <<

NEW: EPGTalk Guide Builder - the same thing in a WINDOW (no commands):
  Windows: EASIEST: run EPGTalk-Builder-Setup.exe (no Python needed)
           or with Python 3 installed: double-click  EPGTalk-Builder.pyw
           mc2xml users: the new mc2xml.exe (portable zip) replaces the old one,
           your batch files stay exactly the same.
  Linux:   EASIEST: double-click epgtalk-builder_1.4.0_all.deb -> Install
           (Ubuntu / Mint / Debian; it then sits in your apps menu)
           or from this zip: sudo apt install python3-tk  then  ./epgtalk-builder
  Add your provider by zip code (or import your old .dat/.chl/.ren), tick your
  channels, press Build. It can also set up the daily update for you.
  Also: "Use on your TV" shares the guide on your home network (your TV box
  loads it by address), light/dark look, large text, Add to my apps menu.

The original mc2xml has a built-in expiry date - that's why it stopped.
This is the drop-in replacement that runs EPGTalk every day: same options,
uses your existing .dat / .chl / .ren files, -I merging works, no expiry,
no RunAsDate. Windows, Linux and Mac.

FIRST: back up your mc2xml folder (copy it somewhere safe).

WINDOWS
-------
1. Install Python 3 from python.org/downloads
   -> on the first screen tick "Add python.exe to PATH".
2. Copy mc2xml.py and mc2xml.bat into your mc2xml folder.
3. Test one lineup in Command Prompt (inside that folder):
     mc2xml.bat -c us -g 12345 -D mylineup.dat -C mylineup.chl -R mylineup.ren -d 24 -U -F -o test.xml
4. In your own .bat files change   mc2xml.exe ...   to   call mc2xml.bat ...
   (keep the word "call" - without it Windows stops after the first line)

LINUX / MAC
-----------
1. Check Python:  python3 --version     (Ubuntu/Debian: sudo apt install python3)
2. In your mc2xml folder move the old program away:   mv mc2xml mc2xml.old
3. Copy mc2xml and mc2xml.py into that folder, then:  chmod +x mc2xml
4. Test:  ./mc2xml -c us -g 12345 -D mylineup.dat -C mylineup.chl -R mylineup.ren -d 24 -U -F -o test.xml
5. Your scripts and cron stay exactly the same.

GOOD TO KNOW
------------
- First run converts each .dat to the new format; the original is kept as .dat.orig
- Merge: each run adds the previous file with  -I previous.xml  -o next.xml
- Antenna / HDHomeRun locals: lineup "Local Over the Air Broadcast" for your zip
- Lineup renamed or missing? Run once by hand with  --lineup  and pick it.
- "Not found ..." lines = old channels in your .chl, nothing breaks.
- Listings: Gracenote (USA, Canada, Mexico) or Schedules Direct with -J. Personal use.
- Schedules Direct: old .dat files are matched to lineups already on your
  account (no zip code needed, nothing changed). It never removes lineups and
  asks before adding one. "Exceeded lineup changes" = SD's daily limit: wait 24h.

Stuck? Send me the last few lines it prints.
Free ready-made guides any time at EPGTalk.com

   mc2xml EPGTalk edition - made by aCiDjEsUs - EPGTalk.com
